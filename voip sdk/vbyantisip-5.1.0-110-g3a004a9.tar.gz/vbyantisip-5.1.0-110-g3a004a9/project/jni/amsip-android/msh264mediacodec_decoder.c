/*
  amsip is a SIP library for softphone (SIP -rfc3261-)
  Copyright (C) 2010-2012 Aymeric MOIZARD - <amoizard@gmail.com>
*/

#include <string.h>
#include <jni.h>

#include <math.h>

#include <mediastreamer2/msfilter.h>
#include <mediastreamer2/rfc3984.h>
#include <mediastreamer2/msvideo.h>
#include <mediastreamer2/msticker.h>

#if defined(__cplusplus)
#define B64_NO_NAMESPACE
#endif
#include <ortp/b64.h>

#define ENABLE_FILTER_STATISTICS

#ifdef __cplusplus
extern "C" {
#endif

#include <libavcodec/avcodec.h>
#include <libswscale/swscale.h>

#if LIBAVUTIL_VERSION_INT >= AV_VERSION_INT(51,13,0)
#include <libavutil/opt.h>
#endif

#ifdef __cplusplus
}
#endif


extern JavaVM *jvm;

static pthread_key_t key;
static pthread_once_t once_control = PTHREAD_ONCE_INIT;

static void dec_close(MSFilter *f, JNIEnv *env);

typedef struct _H264MediaCodecDecState{
  JNIEnv* jenv;
  jobject* jobj; /* global ref on H264MediaCodecDecoder */

  jbyteArray jdata_h264;
  int jdata_h264_size;
  jbyteArray jdata_nv12;
  int jdata_nv12_size;
  int width;
  int height;
  int stride;
  int slice_height;
  int codec_format;
  int crop_left;
  int crop_top;
  int crop_right;
  int crop_bottom;
  int color_format;

  mblk_t *data_nv12;
  mblk_t *yuv_msg;

  mblk_t *sps,*pps;
  Rfc3984Context unpacker;
  MSPicture outbuf;
  struct MSScalerContext *sws_ctx;

  unsigned int packet_num;
  uint8_t *bitstream;
  int bitstream_size;
  int mStat_incoming_image;
  uint64_t last_vfu_request;
  MSFilterFps *stats;
  RtpSession *rtp_session;
}H264MediaCodecDecState;

static void dec_init(MSFilter *f){
  H264MediaCodecDecState *d=ms_new0(H264MediaCodecDecState,1);
  d->jobj=NULL;
  d->jenv=NULL;

  d->color_format=-1;
  d->codec_format=-1;
  d->yuv_msg=NULL;
  d->sps=NULL;
  d->pps=NULL;

  d->sws_ctx=NULL;
  rfc3984_init(&d->unpacker);
  d->packet_num=0;

  d->outbuf.w=0;
  d->outbuf.h=0;
  d->bitstream_size=65536;
  d->bitstream=(uint8_t*)ms_malloc0(d->bitstream_size);
  d->mStat_incoming_image=0;
  d->stats=NULL;
  d->last_vfu_request=0;
#ifdef ENABLE_FILTER_STATISTICS
  d->stats=ms_fps_init(2000);
#endif
  f->data=d;
}

static void dec_uninit(MSFilter *f){
  H264MediaCodecDecState *d=(H264MediaCodecDecState*)f->data;
  JNIEnv* env;
  if ((*jvm)->GetEnv(jvm, (void**)&env, JNI_VERSION_1_4) != JNI_OK) {
    ms_error("H264MediaCodecDec: GetVm failed!");
    return;
  }
  if (d->jdata_h264!=NULL)
    (*env)->DeleteGlobalRef(env, d->jdata_h264);
  if (d->jdata_nv12!=NULL)
    (*env)->DeleteGlobalRef(env, d->jdata_nv12);

  if (d->data_nv12) freemsg(d->data_nv12);
  
  rfc3984_uninit(&d->unpacker);
  dec_close(f, env);
  if (d->sws_ctx!=NULL)	ms_video_scalercontext_free(d->sws_ctx);
  if (d->yuv_msg) freemsg(d->yuv_msg);
  if (d->sps) freemsg(d->sps);
  if (d->pps) freemsg(d->pps);
  ms_free(d->bitstream);
  if (d->stats) ms_free(d->stats);
  ms_free(d);
}

static MSPixFmt ffmpeg_pix_fmt_to_ms(int fmt){
  switch(fmt){
  case PIX_FMT_YUV420P:
    return MS_YUV420P;
  case PIX_FMT_YUYV422:
    return MS_YUYV;     /* same as MS_YUY2 */
  case PIX_FMT_RGB24:
    return MS_RGB24;
  case PIX_FMT_BGR24:
    return MS_RGB24_REV;
  case PIX_FMT_UYVY422:
    return MS_UYVY;
  case PIX_FMT_RGBA:
    return MS_RGBA;
  case PIX_FMT_NV21:
    return MS_NV21;
  case PIX_FMT_NV12:
    return MS_NV12;
  case PIX_FMT_ABGR:
    return MS_ABGR;
  case PIX_FMT_ARGB:
    return MS_ARGB;
  case PIX_FMT_RGB565:
    return MS_RGB565;
  case PIX_FMT_BGRA:
    return MS_BGRA;
  case PIX_FMT_YUVJ420P:
    return MS_YUV420P; /* default */
  default:
    ms_error("format not supported.");
    return MS_YUV420P; /* default */
  }
  return MS_YUV420P; /* default */
}

static mblk_t *get_as_yuvmsg(MSFilter *f, H264MediaCodecDecState *s, MSPicture *orig){

  if (s->outbuf.w!=orig->w || s->outbuf.h!=orig->h){
    if (s->sws_ctx!=NULL){
      ms_video_scalercontext_free(s->sws_ctx);
      s->sws_ctx=NULL;
      freemsg(s->yuv_msg);
      s->yuv_msg=NULL;
    }

    ms_message("H264MediaCodecDec: Getting yuv picture of %ix%i",orig->w,orig->h);
    s->yuv_msg=yuv_buf_alloc(&s->outbuf,orig->w,orig->h);
    s->outbuf.w=orig->w;
    s->outbuf.h=orig->h;

    s->sws_ctx=ms_video_scalercontext_init(orig->w,orig->h,s->color_format,
      orig->w,orig->h,MS_YUV420P,MS_YUVFAST,
      NULL, NULL, NULL);
  }
  if (ms_video_scalercontext_convert(s->sws_ctx,orig->planes,orig->strides, 0,
    orig->h, s->outbuf.planes, s->outbuf.strides)<0){
      ms_error("H264MediaCodecDec: error in ms_video_scalercontext_convert().");
  }
  return dupmsg(s->yuv_msg);
}

static void update_sps(H264MediaCodecDecState *d, mblk_t *sps){
  if (d->sps)
    freemsg(d->sps);
  d->sps=NULL;
  if (sps)
    d->sps=dupb(sps);
}

static void update_pps(H264MediaCodecDecState *d, mblk_t *pps){
  if (d->pps)
    freemsg(d->pps);
  d->pps=NULL;
  if (pps)
    d->pps=dupb(pps);
}

static bool_t check_sps_pps_change(H264MediaCodecDecState *d, mblk_t *sps, mblk_t *pps){
  bool_t ret1=FALSE,ret2=FALSE;
  if (d->sps){
    if (sps){
      ret1=(msgdsize(sps)!=msgdsize(d->sps)) || (memcmp(d->sps->b_rptr,sps->b_rptr,msgdsize(sps))!=0);
      if (ret1) {
        update_sps(d,sps);
        ms_message("H264MediaCodecDec: SPS changed !");
        update_pps(d,NULL);
      }
    }
  }else if (sps) {
    ms_message("H264MediaCodecDec: Receiving first SPS");
    update_sps(d,sps);
  }
  if (d->pps){
    if (pps){
      ret2=(msgdsize(pps)!=msgdsize(d->pps)) || (memcmp(d->pps->b_rptr,pps->b_rptr,msgdsize(pps))!=0);
      if (ret2) {
        update_pps(d,pps);
        ms_message("H264MediaCodecDec: PPS changed ! %i,%i",msgdsize(pps),msgdsize(d->pps));
      }
    }
  }else if (pps) {
    ms_message("H264MediaCodecDec: Receiving first PPS");
    update_pps(d,pps);
  }
  return ret1 || ret2;
}

static void enlarge_bitstream(H264MediaCodecDecState *d, int new_size){
  d->bitstream_size=new_size;
  d->bitstream=(uint8_t*)ms_realloc(d->bitstream,d->bitstream_size);
}

static int nalusToFrame(H264MediaCodecDecState *d, MSQueue *naluq, bool_t *new_sps, bool_t *new_sps_pps){
  mblk_t *im;
  uint8_t *dst=d->bitstream,*src,*end;
  int nal_len;
  bool_t start_picture=TRUE;
  uint8_t nalu_type;
  *new_sps=0;
  *new_sps_pps=0;
  end=d->bitstream+d->bitstream_size;
  while((im=ms_queue_get(naluq))!=NULL){
    src=im->b_rptr;
    nal_len=(int)(im->b_wptr-src);
    if (dst+nal_len+100>end){
      int pos=(int)(dst-d->bitstream);
      enlarge_bitstream(d, d->bitstream_size+nal_len+100);
      dst=d->bitstream+pos;
      end=d->bitstream+d->bitstream_size;
    }
    nalu_type=(*src) & ((1<<5)-1);
    if (nalu_type==7) {
      *new_sps_pps=TRUE;
      *new_sps=check_sps_pps_change(d,im,NULL); //true if modified!
    }
    if (nalu_type==8) {
      *new_sps_pps=TRUE;
      check_sps_pps_change(d,NULL,im);
    }
    if (start_picture || nalu_type==7/*SPS*/ || nalu_type==8/*PPS*/ ){
      *dst++=0;
      start_picture=FALSE;
    }
    /*prepend nal marker*/
    *dst++=0;
    *dst++=0;
    *dst++=1;
    *dst++=*src++;
    while(src<(im->b_wptr-3)){
      if (src[0]==0 && src[1]==0 && src[2]<3){
        *dst++=0;
        *dst++=0;
        *dst++=3;
        src+=2;
      }
      *dst++=*src++;
    }
    *dst++=*src++;
    *dst++=*src++;
    *dst++=*src++;
    freemsg(im);
  }
  return (int)(dst-d->bitstream);
}


static void jni_detach_thread(void *data){
  JNIEnv* env=(JNIEnv*)pthread_getspecific(key);
  ms_message("MSH264MediaCodecDecoder: jni_detach_thread");
  if (env != NULL) {
    (*jvm)->DetachCurrentThread(jvm);
    pthread_setspecific(key,NULL);
  }
}

static void make_key(){
  (void) pthread_key_create(&key, jni_detach_thread);
}

static void jni_attach_thread(MSFilter *f)
{
  H264MediaCodecDecState *d=(H264MediaCodecDecState*)f->data;
  JNIEnv *env=NULL;

  pthread_once(&once_control, make_key);
  env=(JNIEnv*)pthread_getspecific(key);
  if (env==NULL)
    {
      int res = (*jvm)->AttachCurrentThread(jvm, &d->jenv, NULL);
      if (res!=0)
	{
	  ms_error("MSH264MediaCodecDecoder: AttachCurrentThread failed! %i", res);
	  d->jenv=NULL;
	  return;
	}
      pthread_setspecific(key,d->jenv);
      ms_message("MSH264MediaCodecDecoder: jni_attach_thread");
      return;
    }
  d->jenv=env;
  return;
}

jclass H264MediaCodecDecoder_myclz = 0;
#if 0
jmethodID H264MediaCodecDecoder_get_ms_format = 0;
#endif
jmethodID H264MediaCodecDecoder_cons = 0;
jmethodID H264MediaCodecDecoder_close = 0;
jmethodID H264MediaCodecDecoder_decode_data = 0;
jmethodID H264MediaCodecDecoder_get_raw_data = 0;

jmethodID H264MediaCodecDecoder_getWidth = 0;
jmethodID H264MediaCodecDecoder_getHeight = 0;
jmethodID H264MediaCodecDecoder_getStride = 0;
jmethodID H264MediaCodecDecoder_getSliceHeight = 0;
jmethodID H264MediaCodecDecoder_getColorFormat = 0;
jmethodID H264MediaCodecDecoder_getMSColorFormat = 0;
jmethodID H264MediaCodecDecoder_getCropLeft = 0;
jmethodID H264MediaCodecDecoder_getCropTop = 0;
jmethodID H264MediaCodecDecoder_getCropRight = 0;
jmethodID H264MediaCodecDecoder_getCropBottom = 0;

static void dec_open(MSFilter *f) {
  H264MediaCodecDecState *d=(H264MediaCodecDecState*)f->data;
  int i;

  ms_message("H264MediaCodecDec: dec_open");

  d->jobj = (*d->jenv)->NewGlobalRef(d->jenv, (*d->jenv)->NewObject(d->jenv, H264MediaCodecDecoder_myclz, H264MediaCodecDecoder_cons));
  ms_message("New Java Object H264MediaCodecDecoder allocated");

  if (d->jobj==NULL)
    {
      ms_message("H264MediaCodecDec: Failed to allocate Java Object H264MediaCodecDecoder");
      return ;
    }
}


static void dec_close(MSFilter *f, JNIEnv *env) {
  H264MediaCodecDecState *d=(H264MediaCodecDecState*)f->data;
  int i;
  ms_message("H264MediaCodecDec: dec_close");
  if (d->jobj==NULL)
    return;
  i = (*env)->CallIntMethod(env, d->jobj, H264MediaCodecDecoder_close);
  (*env)->DeleteGlobalRef(env, d->jobj);
  ms_message("H264MediaCodecDec: calling destructor for H264MediaCodecDecState!");
}

static void dec_reinit(MSFilter *f) {
  H264MediaCodecDecState *d=(H264MediaCodecDecState*)f->data;
  dec_close(f, d->jenv);
  dec_open(f);
  d->last_vfu_request=0;
}

static void dec_setup_methods(JNIEnv *env) {

  if (H264MediaCodecDecoder_myclz==0)
    H264MediaCodecDecoder_myclz = (*env)->NewGlobalRef(env, (*env)->FindClass(env, "com/antisip/amsip/H264MediaCodecDecoder"));

  if (H264MediaCodecDecoder_myclz==0)
    ms_message("H264MediaCodecDec: H264MediaCodecDecoder_myclz NOT loaded");
  else
    ms_message("H264MediaCodecDec: H264MediaCodecDecoder_myclz loaded");
  if (H264MediaCodecDecoder_myclz==0)
    return;

#if 0
  if (H264MediaCodecDecoder_get_ms_format==0)
    H264MediaCodecDecoder_get_ms_format = (*env)->GetStaticMethodID(env, H264MediaCodecDecoder_myclz, "get_ms_format", "()I");
  if (H264MediaCodecDecoder_get_ms_format==0) {
    ms_message("H264MediaCodecDec: missing method: H264MediaCodecDecoder_get_ms_format");
    return;
  }
#endif

  if (H264MediaCodecDecoder_cons==0)
    H264MediaCodecDecoder_cons = (*env)->GetMethodID(env, H264MediaCodecDecoder_myclz, "<init>", "()V");
  if (H264MediaCodecDecoder_cons==0) {
    ms_message("H264MediaCodecDec: missing method: H264MediaCodecDecoder_cons");
    return;
  }

  if (H264MediaCodecDecoder_close==0)
    H264MediaCodecDecoder_close = (*env)->GetMethodID(env, H264MediaCodecDecoder_myclz, "close", "()I");
  if (H264MediaCodecDecoder_close==0) {
    ms_message("H264MediaCodecDec: missing method: H264MediaCodecDecoder_close");
    return;
  }

  if (H264MediaCodecDecoder_decode_data==0)
    H264MediaCodecDecoder_decode_data = (*env)->GetMethodID(env, H264MediaCodecDecoder_myclz, "decode_data", "(I[BI)I");
  if (H264MediaCodecDecoder_decode_data==0) {
    ms_message("H264MediaCodecDec: missing method: H264MediaCodecDecoder_decode_data");
    return;
  }

  if (H264MediaCodecDecoder_get_raw_data==0)
    H264MediaCodecDecoder_get_raw_data = (*env)->GetMethodID(env, H264MediaCodecDecoder_myclz, "get_raw_data", "([BI)I");
  if (H264MediaCodecDecoder_get_raw_data==0) {
    ms_message("H264MediaCodecDec: missing method: H264MediaCodecDecoder_get_raw_data");
    return;
  }

  if (H264MediaCodecDecoder_getWidth==0)
    H264MediaCodecDecoder_getWidth = (*env)->GetMethodID(env, H264MediaCodecDecoder_myclz, "getWidth", "()I");
  if (H264MediaCodecDecoder_getWidth==0) {
    ms_message("H264MediaCodecDec: missing method: H264MediaCodecDecoder_getWidth");
    return;
  }

  if (H264MediaCodecDecoder_getHeight==0)
    H264MediaCodecDecoder_getHeight = (*env)->GetMethodID(env, H264MediaCodecDecoder_myclz, "getHeight", "()I");
  if (H264MediaCodecDecoder_getHeight==0) {
    ms_message("H264MediaCodecDec: missing method: H264MediaCodecDecoder_getHeight");
    return;
  }

  if (H264MediaCodecDecoder_getStride==0)
    H264MediaCodecDecoder_getStride = (*env)->GetMethodID(env, H264MediaCodecDecoder_myclz, "getStride", "()I");
  if (H264MediaCodecDecoder_getStride==0) {
    ms_message("H264MediaCodecDec: missing method: H264MediaCodecDecoder_getStride");
    return;
  }

  if (H264MediaCodecDecoder_getSliceHeight==0)
    H264MediaCodecDecoder_getSliceHeight = (*env)->GetMethodID(env, H264MediaCodecDecoder_myclz, "getSliceHeight", "()I");
  if (H264MediaCodecDecoder_getSliceHeight==0) {
    ms_message("H264MediaCodecDec: missing method: H264MediaCodecDecoder_getSliceHeight");
    return;
  }

  if (H264MediaCodecDecoder_getColorFormat==0)
    H264MediaCodecDecoder_getColorFormat = (*env)->GetMethodID(env, H264MediaCodecDecoder_myclz, "getColorFormat", "()I");
  if (H264MediaCodecDecoder_getColorFormat==0) {
    ms_message("H264MediaCodecDec: missing method: H264MediaCodecDecoder_getColorFormat");
    return;
  }

  if (H264MediaCodecDecoder_getMSColorFormat==0)
    H264MediaCodecDecoder_getMSColorFormat = (*env)->GetMethodID(env, H264MediaCodecDecoder_myclz, "getMSColorFormat", "()I");
  if (H264MediaCodecDecoder_getMSColorFormat==0) {
    ms_message("H264MediaCodecDec: missing method: H264MediaCodecDecoder_getMSColorFormat");
    return;
  }

  if (H264MediaCodecDecoder_getCropLeft==0)
    H264MediaCodecDecoder_getCropLeft = (*env)->GetMethodID(env, H264MediaCodecDecoder_myclz, "getCropLeft", "()I");
  if (H264MediaCodecDecoder_getCropLeft==0) {
    ms_message("H264MediaCodecDec: missing method: H264MediaCodecDecoder_getCropLeft");
    return;
  }

  if (H264MediaCodecDecoder_getCropTop==0)
    H264MediaCodecDecoder_getCropTop = (*env)->GetMethodID(env, H264MediaCodecDecoder_myclz, "getCropTop", "()I");
  if (H264MediaCodecDecoder_getCropTop==0) {
    ms_message("H264MediaCodecDec: missing method: H264MediaCodecDecoder_getCropTop");
    return;
  }

  if (H264MediaCodecDecoder_getCropRight==0)
    H264MediaCodecDecoder_getCropRight = (*env)->GetMethodID(env, H264MediaCodecDecoder_myclz, "getCropRight", "()I");
  if (H264MediaCodecDecoder_getCropRight==0) {
    ms_message("H264MediaCodecDec: missing method: H264MediaCodecDecoder_getCropRight");
    return;
  }

  if (H264MediaCodecDecoder_getCropBottom==0)
    H264MediaCodecDecoder_getCropBottom = (*env)->GetMethodID(env, H264MediaCodecDecoder_myclz, "getCropBottom", "()I");
  if (H264MediaCodecDecoder_getCropBottom==0) {
    ms_message("H264MediaCodecDec: missing method: H264MediaCodecDecoder_getCropBottom");
    return;
  }
}

static void alloc_jdata_nv12(H264MediaCodecDecState *d) {
  if (d->jdata_nv12_size<=0)
    d->jdata_nv12_size=80000;
  if (d->jdata_nv12==NULL) {
    d->jdata_nv12 = (*d->jenv)->NewByteArray(d->jenv, d->jdata_nv12_size);
    if (d->jdata_nv12==NULL) {
      ms_error("H264MediaCodecDec: out of memory for allocating jdata_nv12 %i", d->jdata_nv12_size);
      return;
    }
    d->jdata_nv12 = (jbyteArray)(*d->jenv)->NewGlobalRef(d->jenv, d->jdata_nv12);
    if (d->jdata_nv12==NULL) {
      ms_error("H264MediaCodecDec: out of memory for allocating globalref jdata_nv12 %i", d->jdata_nv12_size);
      return;
    }
  }
  ms_message("H264MediaCodecDec: jdata_nv12 allocated (size=%i)", d->jdata_nv12_size);
}

static void dec_get_picture(MSFilter *f) {
  H264MediaCodecDecState *d=(H264MediaCodecDecState*)f->data;

  int raw_len;

  if (d->jdata_nv12==NULL) {
    alloc_jdata_nv12(d);
  }
  if (d->jdata_nv12==NULL)
    return;

  raw_len = (*d->jenv)->CallIntMethod(d->jenv, d->jobj, H264MediaCodecDecoder_get_raw_data, d->jdata_nv12, d->jdata_nv12_size);
  if (raw_len<-1000) {
    /* increase allocation */
    if (d->jdata_nv12!=NULL)
      (*d->jenv)->DeleteGlobalRef(d->jenv, d->jdata_nv12);
    d->jdata_nv12=NULL;
    d->jdata_nv12_size=-raw_len; /* for future allocation -if it fails now- */
    alloc_jdata_nv12(d);
    if (d->jdata_nv12==NULL)
      return;
    raw_len = (*d->jenv)->CallIntMethod(d->jenv, d->jobj, H264MediaCodecDecoder_get_raw_data, d->jdata_nv12, d->jdata_nv12_size);
  }

  while (raw_len>0) {
    MSPicture src_pic;
    int video_pitch;
    
    if (d->data_nv12==NULL || msgdsize(d->data_nv12)!=raw_len) {
      
      ms_message("H264MediaCodecDec: raw_len=%i", raw_len);
      if (d->data_nv12!=NULL) freeb(d->data_nv12);
      d->data_nv12=allocb(raw_len,0);
      memset(d->data_nv12->b_wptr,0,raw_len);
      d->data_nv12->b_wptr+=raw_len;
      
      d->codec_format = (*d->jenv)->CallIntMethod(d->jenv, d->jobj, H264MediaCodecDecoder_getColorFormat);
#if 0
      if (d->codec_format==19) /* COLOR_FormatYUV420Planar */
	d->color_format = MS_YUV420P;
      else if (d->codec_format==20) /* COLOR_FormatYUV420PackedPlanar */
	d->color_format = MS_YUV420P;
      else if (d->codec_format==2130706688) /* COLOR_TI_FormatYUV420PackedSemiPlanar */
	d->color_format = MS_NV12;
      else if (d->codec_format==0x7f000001) /* COLOR_TI_FormatYUV420PackedSemiPlanarInterlaced */
	d->color_format = MS_NV12;
      else if (d->codec_format==2141391872) /* COLOR_QCOM_FormatYUV420SemiPlanar */
	d->color_format = MS_NV12;
      else if (d->codec_format==2141391875) /* QOMX_COLOR_FormatYUV420PackedSemiPlanar64x32Tile2m8ka (supposed to be NV12MT?) */
	/* might be usefull?: */
	/* https://github.com/Owersun/xbmc/blob/8a2f587242eaedc03b8a0dfb0000eee3d0522db7/xbmc/cores/dvdplayer/DVDCodecs/Video/nv12mt_to_yuv420m.neon.S */
	d->color_format = MS_NV12;
      else if (d->codec_format==2141391876) /* OMX_QCOM_COLOR_FormatYUV420PackedSemiPlanar32m (detected on nexus 5) */
	d->color_format = MS_NV12;
      else if (d->codec_format==21) /* COLOR_FormatYUV420SemiPlanar */ 
	d->color_format = MS_NV12;
      else if (d->codec_format==842094169) /* YV12 (U and V reversed) */ 
	d->color_format = MS_YUV420P;
      else {
	d->color_format = -1;
      }
      d->color_format = (*d->jenv)->CallStaticIntMethod(d->jenv, H264MediaCodecDecoder_myclz, H264MediaCodecDecoder_get_ms_format);
#else
      d->color_format = (*d->jenv)->CallIntMethod(d->jenv, d->jobj, H264MediaCodecDecoder_getMSColorFormat);
#endif

      
      ms_message("H264MediaCodecDec: color_format=%i", d->color_format);
      if (d->color_format<0) {	
	continue;
      }
      
      d->width = (*d->jenv)->CallIntMethod(d->jenv, d->jobj, H264MediaCodecDecoder_getWidth);
      d->height = (*d->jenv)->CallIntMethod(d->jenv, d->jobj, H264MediaCodecDecoder_getHeight);
      d->stride = (*d->jenv)->CallIntMethod(d->jenv, d->jobj, H264MediaCodecDecoder_getStride);
      d->slice_height = (*d->jenv)->CallIntMethod(d->jenv, d->jobj, H264MediaCodecDecoder_getSliceHeight);
      d->crop_left = (*d->jenv)->CallIntMethod(d->jenv, d->jobj, H264MediaCodecDecoder_getCropLeft);
      d->crop_top = (*d->jenv)->CallIntMethod(d->jenv, d->jobj, H264MediaCodecDecoder_getCropTop);
      d->crop_right = (*d->jenv)->CallIntMethod(d->jenv, d->jobj, H264MediaCodecDecoder_getCropRight);
      d->crop_bottom = (*d->jenv)->CallIntMethod(d->jenv, d->jobj, H264MediaCodecDecoder_getCropBottom);

      ms_message("H264MediaCodecDec: width=%i", d->width);
      ms_message("H264MediaCodecDec: height=%i", d->height);
      ms_message("H264MediaCodecDec: stride=%i", d->stride);
      ms_message("H264MediaCodecDec: slice_height=%i", d->slice_height);
      ms_message("H264MediaCodecDec: crop_left=%i", d->crop_left);
      ms_message("H264MediaCodecDec: crop_top=%i", d->crop_top);
      ms_message("H264MediaCodecDec: crop_right=%i", d->crop_right);
      ms_message("H264MediaCodecDec: crop_bottom=%i", d->crop_bottom);
      
      ms_message("H264MediaCodecDec: src_pic.w %i", (d->crop_right + 1 - d->crop_left + 15) & ~0xF);
      ms_message("H264MediaCodecDec: src_pic.h %i", (d->crop_bottom + 1 - d->crop_top + 15) & ~0xF);
    }
    
    d->last_vfu_request = f->ticker->time;

    (*d->jenv)->GetByteArrayRegion(d->jenv, d->jdata_nv12, 0, raw_len, (jbyte*)d->data_nv12->b_rptr);
    
    ms_fps_process(d->stats, f, f->ticker->time);
    d->mStat_incoming_image++;
    if (d->mStat_incoming_image%100==0)
      ms_message("H264MediaCodecDec: stat: incoming_image %i.",d->mStat_incoming_image);
    
    /* Align on macroblock boundary */
    src_pic.w=(d->crop_right + 1 - d->crop_left + 15) & ~0xF;
    src_pic.h=(d->crop_bottom + 1 - d->crop_top + 15) & ~0xF;
    
    
    yuv_buf_init_with_format(&src_pic, d->color_format, d->stride, src_pic.h, (uint8_t*)d->data_nv12->b_rptr);
    if (d->color_format==MS_NV12 || d->color_format==MS_NV21) {
      int ysize=d->crop_top*d->stride+d->crop_left;
      int slice_height=d->slice_height;
      if (slice_height<=0)
	slice_height=d->height;
      //fix image planes:
      src_pic.planes[0]=d->data_nv12->b_rptr+ysize;
      src_pic.planes[1]=d->data_nv12->b_rptr+d->stride*slice_height+(ysize)/2;

      //Why do I need to add +16 for my Galaxy Nexus with "COLOR_TI_FormatYUV420PackedSemiPlanar"?
      if (d->codec_format==2130706688) /* COLOR_TI_FormatYUV420PackedSemiPlanar */
	src_pic.planes[1]=d->data_nv12->b_rptr+d->stride*slice_height+(ysize)/2+16;
      
    } else if (d->color_format==MS_YUV420P) {
      //TODO: test me...
      int ysize=d->crop_top*d->stride+d->crop_left;
      src_pic.planes[0]=d->data_nv12->b_rptr+ysize;
      if (d->codec_format==842094169) {
	src_pic.planes[2]=d->data_nv12->b_rptr+d->stride*d->slice_height+(ysize)/2;
	src_pic.planes[1]=d->data_nv12->b_rptr+d->stride*d->slice_height*5/4+(ysize)/2;
      } else {
	src_pic.planes[1]=d->data_nv12->b_rptr+d->stride*d->slice_height+(ysize)/2;
	src_pic.planes[2]=d->data_nv12->b_rptr+d->stride*d->slice_height*5/4+(ysize)/2;
      }
    }

    ms_queue_put(f->outputs[0],get_as_yuvmsg(f,d,&src_pic));
    
    raw_len = (*d->jenv)->CallIntMethod(d->jenv, d->jobj, H264MediaCodecDecoder_get_raw_data, d->jdata_nv12, d->jdata_nv12_size);
    if (raw_len<-1000) {
      /* increase allocation */
      if (d->jdata_nv12!=NULL)
	(*d->jenv)->DeleteGlobalRef(d->jenv, d->jdata_nv12);

      d->jdata_nv12=NULL;
      d->jdata_nv12_size=-raw_len; /* for future allocation -if it fails now- */
      alloc_jdata_nv12(d);
      if (d->jdata_nv12==NULL)
	return;
      raw_len = (*d->jenv)->CallIntMethod(d->jenv, d->jobj, H264MediaCodecDecoder_get_raw_data, d->jdata_nv12, d->jdata_nv12_size);
    }
  }
}

static void dec_process(MSFilter *f){
  H264MediaCodecDecState *d=(H264MediaCodecDecState*)f->data;
  mblk_t *im;
  MSQueue nalus;
  AVFrame orig;

  jni_attach_thread(f);

  if (d->jenv==NULL) {
    ms_message("H264MediaCodecDec: d->jenv is NULL?");
    return;
  }

  if (H264MediaCodecDecoder_get_raw_data==0) {
    ms_queue_flush(f->inputs[0]);
    return;
  }

  if (d->jdata_h264==NULL) {
    d->jdata_h264 = (*d->jenv)->NewByteArray(d->jenv, 30000);
    d->jdata_h264 = (jbyteArray)(*d->jenv)->NewGlobalRef(d->jenv, d->jdata_h264);
    d->jdata_h264_size = 30000;
  }
  if (d->jdata_h264==NULL) {
    ms_queue_flush(f->inputs[0]);
    return;
  }

  if (d->jobj==NULL) {
    dec_open(f);
  }

  if (d->jobj==NULL) {
    ms_queue_flush(f->inputs[0]);
    return;
  }

  if (d->jdata_nv12==NULL) {
    alloc_jdata_nv12(d);
  }
  if (d->jdata_nv12==NULL) {
    ms_queue_flush(f->inputs[0]);
    return;
  }

  ms_queue_init(&nalus);
  while((im=ms_queue_get(f->inputs[0]))!=NULL){
    /*push the sps/pps given in sprop-parameter-sets if any*/
    if (d->packet_num==0 && d->sps && d->pps){
      mblk_set_timestamp_info(d->sps,mblk_get_timestamp_info(im));
      mblk_set_timestamp_info(d->pps,mblk_get_timestamp_info(im));
      rfc3984_unpack(&d->unpacker,d->sps,&nalus);
      rfc3984_unpack(&d->unpacker,d->pps,&nalus);
      d->sps=NULL;
      d->pps=NULL;
    }
    rfc3984_unpack(&d->unpacker,im,&nalus);

    if (d->unpacker.nack_lost_detected_cseq>0 && d->rtp_session!=NULL) {
      if (f->ticker->time - d->unpacker.nack_last_sent_time>500 && d->rtp_session->rtcpfeedback_pli==TRUE) {
        ms_warning("H264MediaCodecDec: sending PLI for nack_lost_detected_cseq=%i", d->unpacker.nack_lost_detected_cseq);
        rtp_session_send_rtcp_fb_PLI(d->rtp_session);
        d->unpacker.nack_lost_detected_cseq=0;
        d->unpacker.nack_lost_bits=0;
        d->unpacker.nack_last_sent_time=f->ticker->time;
      } else if (f->ticker->time - d->unpacker.nack_last_sent_time>500 && d->rtp_session->rtcpfeedback_nack==TRUE) {
        ms_warning("H264MediaCodecDec: sending generic NACK for nack_lost_detected_cseq=%i", d->unpacker.nack_lost_detected_cseq);
        rtp_session_send_rtcp_fb_NACK(d->rtp_session, d->unpacker.nack_lost_detected_cseq, d->unpacker.nack_lost_bits);
        d->unpacker.nack_lost_detected_cseq=0;
        d->unpacker.nack_lost_bits=0;
        d->unpacker.nack_last_sent_time=f->ticker->time;
      }
    }

    if (!ms_queue_empty(&nalus)){
      int i;
      int size;
      uint8_t *p,*end;
      bool_t need_reinit=FALSE;
      bool_t isspsorpps=FALSE;

      if (d->rtp_session->rtcpfeedback_nack==FALSE && d->rtp_session->rtcpfeedback_pli==FALSE && d->last_vfu_request>0) {
        /* there is no feedback support negotiated ... */
      } else if (d->unpacker.decoder_ready==FALSE) {
        mblk_t *old;
        while((old=ms_queue_get(&nalus))!=NULL){
          freemsg(old);
        }
        continue;
      }

      size=nalusToFrame(d,&nalus,&need_reinit,&isspsorpps);
      if (need_reinit)
        dec_reinit(f);
      p=d->bitstream;
      end=d->bitstream+size;

      if (size>d->jdata_h264_size)
	{
	  ms_message("H264MediaCodecDec: re-allocate more space for decoder NAL size %i -> %i", d->jdata_h264_size, size);
	  (*d->jenv)->DeleteGlobalRef(d->jenv, d->jdata_h264);

	  d->jdata_h264 = (*d->jenv)->NewByteArray(d->jenv, size);
	  d->jdata_h264 = (jbyteArray)(*d->jenv)->NewGlobalRef(d->jenv, d->jdata_h264);
	  d->jdata_h264_size = size;
	}

      (*d->jenv)->SetByteArrayRegion(d->jenv, d->jdata_h264, 0, size, (jbyte*)p);

      i=-3;
      while (i==-3) {
	if (isspsorpps)
	  i = (*d->jenv)->CallIntMethod(d->jenv, d->jobj, H264MediaCodecDecoder_decode_data,
					2, d->jdata_h264, size);
	else
	  i = (*d->jenv)->CallIntMethod(d->jenv, d->jobj, H264MediaCodecDecoder_decode_data,
					0, d->jdata_h264, size);
	if (i==-3)
	  {
	    dec_get_picture(f);
	  }
      }

      if (d->jdata_nv12==NULL) {
	ms_queue_flush(f->inputs[0]);
	break;
      }
    }
    d->packet_num++;

    dec_get_picture(f);
  }

  /* if no sps/pps received yet */
  if (d->last_vfu_request==0) {
    int got_picture=0;
    d->last_vfu_request = f->ticker->time;
    ms_warning("H264MediaCodecDecState: MS_FILTER_REQUIRE_VFU might be needed.");
    if (f->notify!=NULL){
      f->notify(f->notify_ud,MS_FILTER_REQUIRE_VFU,(void*)&got_picture);
      }
  } else if (f->ticker->time-d->last_vfu_request>4000) {
    int got_picture=0;
    /* when no frame can be decoded during 4 seconds, we are -prety- sure a valid SPS/PPS was not received */
    d->last_vfu_request = f->ticker->time;
    ms_warning("H264MediaCodecDecState: MS_FILTER_REQUIRE_VFU might be needed.");
    if (f->notify!=NULL){
      f->notify(f->notify_ud,MS_FILTER_REQUIRE_VFU,(void*)&got_picture);
    }
  }
}


static int dec_add_fmtp(MSFilter *f, void *arg){
  H264MediaCodecDecState *d=(H264MediaCodecDecState*)f->data;
  const char *fmtp=(const char *)arg;
  char value[256];
  if (fmtp_get_value(fmtp,"sprop-parameter-sets",value,sizeof(value))){
    char * b64_sps=value;
    char * b64_pps=strchr(value,',');
    if (b64_pps){
      *b64_pps='\0';
      ++b64_pps;
      ms_message("H264MediaCodecDec: Got sprop-parameter-sets : sps=%s , pps=%s",b64_sps,b64_pps);
      d->sps=allocb(sizeof(value),0);
      d->sps->b_wptr+=b64_decode((const char *)b64_sps,(size_t)strlen(b64_sps),(void *)d->sps->b_wptr,(size_t)sizeof(value));
      d->pps=allocb(sizeof(value),0);
      d->pps->b_wptr+=b64_decode(b64_pps,strlen(b64_pps),d->pps->b_wptr,sizeof(value));
    }
  }
  return 0;
}

static int dec_set_session(MSFilter *f, void *data){
  H264MediaCodecDecState *d=(H264MediaCodecDecState*)f->data;
  RtpSession *s = (RtpSession *) data;

  d->rtp_session = s;

  return 0;
}

static MSFilterMethod  h264_dec_methods[]={
  {	MS_FILTER_ADD_FMTP	,	dec_add_fmtp	},
  {	MS_FILTER_SET_SESSION ,	dec_set_session	},
  {	0			,	NULL	}
};

static MSFilterDesc h264mediacodec_dec_desc={
  MS_FILTER_PLUGIN_ID,
  "MSH264MediaCodecDec",
  "A H264 decoder based on MediaCodec android API.",
  MS_FILTER_DECODER,
  "H264",
  1,
  1,
  dec_init,
  NULL,
  dec_process,
  NULL,
  dec_uninit,
  h264_dec_methods,
  MS_FILTER_PRIORITY_BIT2|MS_FILTER_PRIORITY_BIT3,
};


#ifdef WIN32
#define GLOBAL_LINKAGE __declspec(dllexport)
#else
#define GLOBAL_LINKAGE
#endif

GLOBAL_LINKAGE void libmsandroidmediacodecdec_init(void);

GLOBAL_LINKAGE void libmsandroidmediacodecdec_init(void){
  JNIEnv *env;
  if ((*jvm)->GetEnv(jvm, (void**)&env, JNI_VERSION_1_4) != JNI_OK) {
    ms_error("H264MediaCodecDec: GetVm failed!");
    return;
  }  
  if (H264MediaCodecDecoder_get_raw_data==0)
    dec_setup_methods(env);

  if (H264MediaCodecDecoder_get_raw_data==0)
    return;

  ms_filter_register(&h264mediacodec_dec_desc);
}
