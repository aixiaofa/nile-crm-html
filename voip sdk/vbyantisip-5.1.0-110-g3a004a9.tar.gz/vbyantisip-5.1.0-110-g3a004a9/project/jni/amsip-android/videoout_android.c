/*
  amsip is a SIP library for softphone (SIP -rfc3261-)
  Copyright (C) 2003,2004,2005,2006,2007,2008,2009,2010  Aymeric MOIZARD - <amoizard@gmail.com>
*/

#ifdef VIDEO_ENABLED

#include <string.h>
#include <jni.h>
#include <dlfcn.h>

#ifdef HAVE_CONFIG_H
#include "mediastreamer-config.h"
#endif

#include "mediastreamer2/msfilter.h"
#include "mediastreamer2/msvideo.h"
#include "mediastreamer2/msvideoout.h"

#if defined(HAVE_LIBAVCODEC_AVCODEC_H)
/* new layout */
# include <libavcodec/avcodec.h>
# include <libavutil/avutil.h>
#else
/* old layout */
# include <ffmpeg/avcodec.h>
# include <ffmpeg/avutil.h>
#endif
      
#if defined(HAVE_LIBSWSCALE_SWSCALE_H)
/* new layout */
#  include <libswscale/swscale.h>
# elif !defined(HAVE_LIBAVCODEC_AVCODEC_H)
/* old layout */
# include <ffmpeg/swscale.h>
#else
/* swscale.h not delivered: use linphone private version */
#  include "swscale.h"
#endif

#include <android/bitmap.h>

extern ms_mutex_t vd_mutex;
extern jobject mAndroidBitmap;
extern AndroidBitmapInfo info;

extern JavaVM *jvm;
extern jclass videodisplay_myclz;
extern jmethodID videodisplay_lockIncomingImage;
extern jmethodID videodisplay_unlockIncomingImage;

extern unsigned long gVideoDisplay;

static pthread_key_t key;
static pthread_once_t once_control = PTHREAD_ONCE_INIT;


static int (*func_AndroidBitmap_getInfo)(JNIEnv *env, jobject jbitmap, AndroidBitmapInfo *info)=NULL;
static int (*func_AndroidBitmap_lockPixels)(JNIEnv *env, jobject jbitmap, void **addrPtr)=NULL;
static int (*func_AndroidBitmap_unlockPixels)(JNIEnv *env, jobject jbitmap)=NULL;

typedef struct VideoOut
{
  JNIEnv* jenv;
  MSPicture dest;
  struct MSScalerContext *sws;
  MSVideoSize in_size;
}VideoOut;

static void set_vsize(VideoOut *s, MSVideoSize *sz){
}

static void video_out_init(MSFilter  *f){
  VideoOut *obj=(VideoOut*)ms_new0(VideoOut,1);
  MSVideoSize def_size;

  obj->jenv=NULL;
  obj->sws=NULL;
  obj->dest.w=0;
  obj->dest.h=0;
  obj->in_size.width=0;
  obj->in_size.height=0;
  f->data=obj;
}

static void video_out_uninit(MSFilter *f){
  VideoOut *obj=(VideoOut*)f->data;
  if (obj->sws!=NULL){
    ms_video_scalercontext_free(obj->sws);
    obj->sws=NULL;
  }
  obj->in_size.width=0;
  obj->in_size.height=0;
  ms_free(obj);
}

static void video_out_preprocess(MSFilter *f){

}

static void jni_detach_thread(void *data){
  JNIEnv* env=(JNIEnv*)pthread_getspecific(key);
  ms_message("videoout_android: jni_detach_thread");
  if (env != NULL) {
    (*jvm)->DetachCurrentThread(jvm);
    pthread_setspecific(key,NULL);
  }
}

static void make_key(){
  (void) pthread_key_create(&key, jni_detach_thread);
}

static void jni_attach_thread(MSFilter *f)
{
  VideoOut *obj=(VideoOut*)f->data;
  JNIEnv *env=NULL;

  pthread_once(&once_control, make_key);
  env=(JNIEnv*)pthread_getspecific(key);
  if (env==NULL)
    {
      int res = (*jvm)->AttachCurrentThread(jvm, &obj->jenv, NULL);
      if (res!=0)
	{
	  ms_error("videoout_android: AttachCurrentThread failed! %i", res);
	  obj->jenv=NULL;
	  return;
	}
      pthread_setspecific(key,obj->jenv);
      ms_message("videoout_android: jni_attach_thread");
      return;
    }
  obj->jenv=env;
  return;
}

static void load_jnigraphics()
{
  if (func_AndroidBitmap_getInfo!=NULL
      &&func_AndroidBitmap_lockPixels!=NULL
      &&func_AndroidBitmap_unlockPixels!=NULL)
    return;
  void *handle = dlopen("libjnigraphics.so", RTLD_LAZY);
  if (handle!=NULL)
    {
      ms_message("libjnigraphics.so // Android bitmap API/ndk >= 2.2 detected");
      func_AndroidBitmap_getInfo=dlsym(handle,"AndroidBitmap_getInfo");
      func_AndroidBitmap_lockPixels=dlsym(handle,"AndroidBitmap_lockPixels");
      func_AndroidBitmap_unlockPixels=dlsym(handle,"AndroidBitmap_unlockPixels");
    }
  return;
}

static void video_out_process(MSFilter *f){
  VideoOut *obj=(VideoOut*)f->data;
  mblk_t *inm;

  jni_attach_thread(f);

  if (videodisplay_myclz==0
      ||videodisplay_lockIncomingImage==0
      ||videodisplay_unlockIncomingImage==0)
    {
      if (f->inputs[0]!=NULL)
	ms_queue_flush(f->inputs[0]);
      ms_warning("videoout_android: no VideoDisplay class available");
      return;
    }

  load_jnigraphics();
  if (func_AndroidBitmap_getInfo==NULL
      ||func_AndroidBitmap_lockPixels==NULL
      ||func_AndroidBitmap_unlockPixels==NULL)
    {
      if (f->inputs[0]!=NULL)
	ms_queue_flush(f->inputs[0]);
      ms_error("libjnigraphics.so missing // Android bitmap API/ndk < 2.2 detected");
      return;
    }

  if (obj->jenv==NULL)
    {
      if (f->inputs[0]!=NULL)
	ms_queue_flush(f->inputs[0]);
      ms_warning("videoout_android: not attached to jvm");
      return;
    }
      
  ms_mutex_lock(&vd_mutex);
  if (f->inputs[0]!=NULL && (inm=ms_queue_peek_last(f->inputs[0]))!=0) {
    MSPicture src;
    if (yuv_buf_init_from_mblk(&src,inm)==0){

      //AndroidBitmapInfo info;
      void* addrPtr=NULL;
      int i;
      jobject jdisplay = (jobject)gVideoDisplay;

      if (gVideoDisplay==0)
	{
	  static int counter=0;
	  if (f->inputs[0]!=NULL)
	    ms_queue_flush(f->inputs[0]);

	  counter++;
	  if (counter%100==0)
	    ms_warning("videoout_android: no VideoDisplay instance available");

	  ms_mutex_unlock(&vd_mutex);
	  return;
	}

      /* check if source size has changed */
      if (obj->in_size.width!=src.w || obj->in_size.height!=src.h)
	{
	  if (obj->sws!=NULL){
	    ms_video_scalercontext_free(obj->sws);
	    obj->sws=NULL;
	  }
	  obj->in_size.width=src.w;
	  obj->in_size.height=src.h;
	  
	  /* Is this what we should do? */
	  (*obj->jenv)->DeleteGlobalRef(obj->jenv, mAndroidBitmap);
	  mAndroidBitmap=NULL;
	  info.width=0;
	  info.height=0;
	}

      if (mAndroidBitmap==NULL)
	{
	  jobject lAndroidBitmap = (*obj->jenv)->CallObjectMethod(obj->jenv, jdisplay, videodisplay_lockIncomingImage, src.w, src.h);
	  if (lAndroidBitmap==NULL)
	    {
	      if (f->inputs[0]!=NULL)
		ms_queue_flush(f->inputs[0]);
	      ms_warning("videoout_android: not bitmap available for drawing");
	      ms_mutex_unlock(&vd_mutex);
	      return;
	    }
	  mAndroidBitmap = (*obj->jenv)->NewGlobalRef(obj->jenv, lAndroidBitmap);
	  (*obj->jenv)->DeleteLocalRef(obj->jenv, lAndroidBitmap);
	}

      if (info.width==0)
	{
	  i = func_AndroidBitmap_getInfo(obj->jenv, mAndroidBitmap, &info);
	  if (i!=0)
	    {
	      if (f->inputs[0]!=NULL)
		ms_queue_flush(f->inputs[0]);
	      ms_warning("videoout_android: no info for bitmap");
	      
	      (*obj->jenv)->CallObjectMethod(obj->jenv, jdisplay, videodisplay_unlockIncomingImage);	
	      ms_mutex_unlock(&vd_mutex);
	      return;
	    }
	}

      if (obj->sws==NULL || obj->dest.w!=info.width || obj->dest.h!=info.height){
	
	obj->dest.w=info.width;
	obj->dest.h=info.height;

	if (obj->sws!=NULL)
	  {
	    ms_video_scalercontext_free(obj->sws);
	    obj->sws=NULL;
	  }       
	
	obj->sws=ms_video_scalercontext_init(src.w,src.h,MS_YUV420P,
				   obj->dest.w,obj->dest.h,MS_RGB565,
				   MS_YUVFAST, NULL, NULL, NULL);
	if (obj->sws!=NULL)
	  {
	    ms_message("videoout_android: conversion to RGB565 %ix%i", obj->dest.w, obj->dest.h);
	  }
      }

      i = func_AndroidBitmap_lockPixels(obj->jenv, mAndroidBitmap, &addrPtr);
      if (i==0) {
	if (addrPtr!=NULL){
	  obj->dest.planes[0]=(uint8_t*)addrPtr;
	  obj->dest.planes[1]=NULL;
	  obj->dest.planes[2]=NULL;
	  obj->dest.planes[3]=NULL;
	  obj->dest.strides[0]=info.stride;
	  obj->dest.strides[1]=0;
	  obj->dest.strides[2]=0;
	  obj->dest.strides[3]=0;
	  ms_video_scalercontext_convert(obj->sws,src.planes,src.strides,0,src.h,obj->dest.planes,obj->dest.strides);
	}
	func_AndroidBitmap_unlockPixels(obj->jenv, mAndroidBitmap);
      }
      (*obj->jenv)->CallVoidMethod(obj->jenv, jdisplay, videodisplay_unlockIncomingImage);
    }

    ms_queue_flush(f->inputs[0]);
  }
  ms_mutex_unlock(&vd_mutex);
}

static int video_out_set_vsize(MSFilter *f,void *arg){
  VideoOut *s=(VideoOut*)f->data;
  return 0;
}

static int video_out_null(MSFilter *f,void *arg){
  VideoOut *s=(VideoOut*)f->data;
  return 0;
}

static MSFilterMethod methods[]={
  {       MS_FILTER_SET_VIDEO_SIZE        ,       video_out_set_vsize },
	{	MS_VIDEO_OUT_SET_DISPLAY	,	video_out_null},
	{	MS_VIDEO_OUT_SET_CORNER 	,	video_out_null},
	{	MS_VIDEO_OUT_AUTO_FIT		,	video_out_null},
	{	MS_VIDEO_OUT_HANDLE_RESIZING	,	video_out_null},
	{	MS_VIDEO_OUT_ENABLE_MIRRORING	,	video_out_null},
	{	MS_VIDEO_OUT_GET_NATIVE_WINDOW_ID,	video_out_null},
	{	MS_VIDEO_OUT_GET_CORNER 	,	video_out_null},
	{	MS_VIDEO_OUT_SET_SCALE_FACTOR 	,	video_out_null},
	{	MS_VIDEO_OUT_GET_SCALE_FACTOR 	,	video_out_null},
	{	MS_VIDEO_OUT_SET_SELFVIEW_POS 	 ,	video_out_null},
	{	MS_VIDEO_OUT_GET_SELFVIEW_POS    ,  video_out_null},
  {	MS_VIDEO_OUT_SET_BACKGROUND_COLOR    ,  video_out_null},
	{	MS_VIDEO_OUT_GET_BACKGROUND_COLOR    ,  video_out_null},
/* methods for compatibility with the MSVideoDisplay interface*/
	{	MS_VIDEO_DISPLAY_SET_LOCAL_VIEW_MODE , video_out_null },
	{	MS_VIDEO_DISPLAY_ENABLE_AUTOFIT			, video_out_null },
	{	MS_VIDEO_DISPLAY_ENABLE_MIRRORING		, video_out_null },
	{	MS_VIDEO_DISPLAY_GET_NATIVE_WINDOW_ID	, video_out_null },
	{	MS_VIDEO_DISPLAY_SET_LOCAL_VIEW_SCALEFACTOR	, video_out_null },
	{	MS_VIDEO_DISPLAY_SET_SELFVIEW_POS 	 ,	video_out_null},
	{	MS_VIDEO_DISPLAY_GET_SELFVIEW_POS    ,  video_out_null},
	{	MS_VIDEO_DISPLAY_SET_BACKGROUND_COLOR    ,  video_out_null},

  {0,NULL}
};

MSFilterDesc ms_video_out_desc={
  .id=MS_VIDEO_OUT_ID,
  .name="MSVideoOutAndroid",
  .text=N_("An android video display"),
  .category=MS_FILTER_OTHER,
  .ninputs=1,
  .noutputs=0,
  .init=video_out_init,
  .preprocess=video_out_preprocess,
  .process=video_out_process,
  .uninit=video_out_uninit,
  .methods=methods
};

#endif
