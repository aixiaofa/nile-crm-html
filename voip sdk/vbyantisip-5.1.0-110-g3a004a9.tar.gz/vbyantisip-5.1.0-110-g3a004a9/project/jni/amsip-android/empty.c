

extern int am_init(char *app_name, int debug);

/* this is required to import all used symbol */
void donotcall()
{
  am_init("not used", 0);
  return;
}
