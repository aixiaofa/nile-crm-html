/*
  amsip is a SIP library for softphone (SIP -rfc3261-)
  Copyright (C) 2003,2004,2005,2006,2007,2008,2009,2010  Aymeric MOIZARD - <amoizard@gmail.com>
*/

#include <string.h>
#include <jni.h>


#include "mediastreamer2/mssndcard.h"
#include "mediastreamer2/msfilter.h"
#include "mediastreamer2/msticker.h"

#define androidsnd_NBUFS 10
#define androidsnd_OUT_NBUFS 20
#define androidsnd_NSAMPLES 320
#define androidsnd_MINIMUMBUFFER 5

#define MODE_PREPARE_BEFORE_ATTACH

static MSFilter *ms_androidsnd_read_new(MSSndCard *card);
static MSFilter *ms_androidsnd_write_new(MSSndCard *card);

typedef struct AndroidCard{
  char devname[256];
  char deviceid[256];
}AndroidCard;

extern JavaVM *jvm;
extern jclass audioinput_myclz; 
extern jmethodID audioinput_cons;
extern jmethodID audioinput_cons_read_bytes;
extern jmethodID audioinput_cons_halt;

extern jclass audiooutput_myclz;
extern jmethodID audiooutput_cons;
extern jmethodID audiooutput_cons_write_bytes;
extern jmethodID audiooutput_cons_halt;

extern int rate[];

static void AndroidCard_set_level(MSSndCard *card, MSSndCardMixerElem e, int percent){
  AndroidCard *d=(AndroidCard*)card->data;

  unsigned long dwVolume = 0xFFFF;
  dwVolume = ((0xFFFF) * percent) / 100;

  switch(e){
  case MS_SND_CARD_MASTER:
    {
    }
    break;
  case MS_SND_CARD_PLAYBACK:
    {
    }
    break;
  case MS_SND_CARD_CAPTURE:
    {
    }
    break;
  default:
    ms_warning("AndroidCard_set_level: unsupported command.");
  }
}

static int AndroidCard_get_level(MSSndCard *card, MSSndCardMixerElem e){
  AndroidCard *d=(AndroidCard*)card->data;

  int percent = 100;

  switch(e){
  case MS_SND_CARD_MASTER:
    return percent;
  case MS_SND_CARD_PLAYBACK:
    return percent;
  case MS_SND_CARD_CAPTURE:
    return percent;
  default:
    ms_warning("AndroidCard_get_level: unsupported command.");
  }
  return -1;
}

static void AndroidCard_set_source(MSSndCard *card, MSSndCardCapture source){

  switch(source){
  case MS_SND_CARD_MIC:
    break;
  case MS_SND_CARD_LINE:
    break;
  }	
}

static int AndroidCard_set_control(MSSndCard *card, MSSndCardControlElem e, int val){
  AndroidCard *d=(AndroidCard*)card->data;

  switch(e){
  case MS_SND_CARD_MASTER_MUTE:
    break;
  case MS_SND_CARD_PLAYBACK_MUTE:
    break;
  case MS_SND_CARD_CAPTURE_MUTE:
    break;
  default:
    ms_warning("AndroidCard_set_control: unsupported command.");
  }
  return -1;
}

static int AndroidCard_get_control(MSSndCard *card, MSSndCardControlElem e){
  AndroidCard *d=(AndroidCard*)card->data;
  return -1;
}

static void AndroidCard_init(MSSndCard *card){
  AndroidCard *c=(AndroidCard *)ms_new(AndroidCard,1);
  card->data=c;
}

static void AndroidCard_uninit(MSSndCard *card){
  ms_free(card->data);
}

static void AndroidCard_unload(MSSndCardManager *obj){
}

static void AndroidCard_detect(MSSndCardManager *m);
static  MSSndCard *AndroidCard_dup(MSSndCard *obj);

MSSndCardDesc androidsnd_card_desc={
  "ANDROIDSND",
  AndroidCard_detect,
  AndroidCard_init,
  AndroidCard_set_level,
  AndroidCard_get_level,
  AndroidCard_set_source,
  AndroidCard_set_control,
  AndroidCard_get_control,
  ms_androidsnd_read_new,
  ms_androidsnd_write_new,
  AndroidCard_uninit,
  AndroidCard_dup,
  AndroidCard_unload
};

static  MSSndCard *AndroidCard_dup(MSSndCard *obj){
  MSSndCard *card=ms_snd_card_new(&androidsnd_card_desc);
  card->name=ms_strdup(obj->name);
  card->data=ms_new(AndroidCard,1);
  memcpy(card->data,obj->data,sizeof(AndroidCard));
  return card;
}

static MSSndCard *AndroidCard_new(const char *name, const char *deviceid, unsigned cap){
  MSSndCard *card=ms_snd_card_new(&androidsnd_card_desc);
  AndroidCard *d=(AndroidCard*)card->data;
  card->name=ms_strdup(name);
  strncpy(d->devname, name, sizeof(d->devname));
  memset(d->deviceid, 0, sizeof(d->deviceid));
  card->capabilities=cap;
  return card;
}

static void add_or_update_card(MSSndCardManager *m, const char *name, const char *deviceid, unsigned int capability){
  MSSndCard *card;
  const MSList *elem=ms_snd_card_manager_get_list(m);
  for(;elem!=NULL;elem=elem->next){
    card=(MSSndCard*)elem->data;
    if (strcmp(card->desc->driver_type, androidsnd_card_desc.driver_type)==0
	&& strcmp(card->name,name)==0){
      /*update already entered card */
      AndroidCard *d=(AndroidCard*)card->data;
      card->capabilities|=capability;
      /* already exist */
      return;
    }
  }
  ms_snd_card_manager_add_card(m,AndroidCard_new(name, deviceid, capability));
}

static void AndroidCard_detect(MSSndCardManager *m){
  add_or_update_card(m,"Android output audio",NULL, MS_SND_CARD_CAP_PLAYBACK);
  add_or_update_card(m,"Android input audio",NULL, MS_SND_CARD_CAP_CAPTURE);
}


typedef struct AndroidSnd{
  char devname[256];
  char deviceid[256];

  /* Input device information */
  int rate;
  int nchannels;

  ms_thread_t thread;
  bool_t read_started;
  bool_t write_started;

  JNIEnv* jenv;
  jobject* jobj;

  queue_t rq;
  MSBufferizer *bufferizer;
  ms_mutex_t mutex;
  ms_cond_t cond;

  unsigned int nbufs_playing;

  int32_t stat_input;
  int32_t stat_output;
  int32_t stat_notplayed;

  int32_t stat_minimumbuffer;

  int reset;
  int mode; /* 0: open/close upon restart. 1: keep opened until destroy */
  int filter_attached;
}AndroidSnd;

static void * android_read_thread(void *p){
  MSFilter *f=p;
  AndroidSnd *d=(AndroidSnd*)f->data;


  /* int bytes = 2*2*(f->ticker->interval*d->rate*d->nchannels)/1000; */
  int bytes = 2*2*(d->rate*d->nchannels)/100; /* 10ms interval */
  int size;

  int res;
  ms_message("android_read_thread");
  res = (*jvm)->AttachCurrentThread(jvm, &d->jenv, NULL);
  if (res!=0)
    ms_message("AttachCurrentThread failed! %i", res);

  if (d->jenv==NULL)
    return;
  ms_message("android_read_thread: current thread attached");
  d->jobj = (*d->jenv)->NewGlobalRef(d->jenv, (*d->jenv)->NewObject(d->jenv, audioinput_myclz, audioinput_cons, d->rate));
  ms_message("New Java Object AudioInput allocated");

  if (d->jobj==NULL)
    {
      ms_message("Failed to allocate Java Object AudioInput");
      return ;
    }

  jbyteArray jdata = (*d->jenv)->NewByteArray(d->jenv, bytes);
  jdata = (jbyteArray)(*d->jenv)->NewGlobalRef(d->jenv, jdata);

  while (d->read_started)
    {
      size = (*d->jenv)->CallIntMethod(d->jenv, d->jobj, audioinput_cons_read_bytes,
				       jdata, bytes);
      if (size<=0)
	{
	  if (d->filter_attached==TRUE) {
	    ms_mutex_lock(&d->mutex);
	    if (d->read_started) ms_cond_wait(&d->cond, &d->mutex);
	    ms_mutex_unlock(&d->mutex);
	  } else {
	    /* drop data from this detached filter */
	    osip_usleep(10000);
	  }
	}
      else
	{
	  if (d->filter_attached==TRUE) {
	    mblk_t *om=allocb(size,0);
	    memset(om->b_wptr,0,size);
	    
	    (*d->jenv)->GetByteArrayRegion(d->jenv, jdata, 0, size, (jbyte*)om->b_wptr);
	    om->b_wptr+=size;
	    ms_mutex_lock(&d->mutex);
	    putq(&d->rq,om);
	    if (d->read_started) ms_cond_wait(&d->cond, &d->mutex);
	    ms_mutex_unlock(&d->mutex);
	  } else {
	    /* drop data from this detached filter */
	    osip_usleep(10000);
	  }
	}
    }

  (*d->jenv)->DeleteGlobalRef(d->jenv, jdata);

  (*d->jenv)->CallIntMethod(d->jenv, d->jobj, audioinput_cons_halt);
  ms_message("calling destructor for Input!");
  (*d->jenv)->DeleteGlobalRef(d->jenv, d->jobj);


  res = (*jvm)->DetachCurrentThread(jvm);
  if (res!=0)
    ms_message("DetachCurrentThread failed! %i", res);
  d->jobj=NULL;
  d->jenv=NULL;
}

static void android_start_r(MSFilter *f){
  AndroidSnd *d=(AndroidSnd*)f->data;
  if (d->read_started==FALSE){
    d->read_started=TRUE;
    d->reset=0;
    ms_thread_create(&d->thread,NULL,android_read_thread,f);
  }
}

static void android_stop_r(MSFilter *f){
  AndroidSnd *d=(AndroidSnd*)f->data;
  d->read_started=FALSE;
  if (d->thread!=0)
    {
      ms_mutex_lock(&d->mutex);
      ms_cond_signal(&d->cond);
      ms_mutex_unlock(&d->mutex);
      ms_thread_join(d->thread,NULL);
      d->thread=0;
    }
}

static void androidsnd_read_uninit(MSFilter *f){
  AndroidSnd *d=(AndroidSnd*)f->data;

  if (d->mode!=0)
    android_stop_r(f);

  d->jenv=NULL;
  d->jobj=NULL;
  flushq(&d->rq,0);
  ms_bufferizer_flush(d->bufferizer);
  ms_bufferizer_destroy(d->bufferizer);
  ms_mutex_destroy(&d->mutex);
  ms_cond_destroy(&d->cond);
  ms_free(f->data);
}

static void androidsnd_read_preprocess(MSFilter *f){
  AndroidSnd *d=(AndroidSnd*)f->data;

  d->stat_input=0;
  d->stat_output=0;
  d->stat_notplayed=0;
  d->stat_minimumbuffer=androidsnd_MINIMUMBUFFER;
  d->filter_attached=TRUE;

  if (d->read_started==TRUE && d->reset==1) {
    android_stop_r(f);
  }
  android_start_r(f);
}

static void androidsnd_read_postprocess(MSFilter *f){
  AndroidSnd *d=(AndroidSnd*)f->data;

  if (d->mode==0)
    android_stop_r(f);
  d->filter_attached=FALSE;
  if (d->mode!=0) {
    ms_mutex_lock(&d->mutex);
    ms_cond_signal(&d->cond);
    ms_mutex_unlock(&d->mutex);
  }

  ms_message("androidsnd_read_postprocess: device closed (playing: %i) (input-output: %i) (notplayed: %i)",
	     d->nbufs_playing, d->stat_input, d->stat_notplayed);
}

static void androidsnd_read_process(MSFilter *f){
  AndroidSnd *d=(AndroidSnd*)f->data;

  mblk_t *om;

  if (d->reset==1) {
    android_stop_r(f);
    android_start_r(f);
  }

  if (f->last_tick%2==0)
    {
      ms_mutex_lock(&d->mutex);
      ms_cond_signal(&d->cond);
      ms_mutex_unlock(&d->mutex);
      return;
    }
  ms_mutex_lock(&d->mutex);
  om=getq(&d->rq);
  if (om!=NULL)
    ms_queue_put(f->outputs[0],om);
  ms_cond_signal(&d->cond);
  ms_mutex_unlock(&d->mutex);
  return;

  while (om!=NULL)
    {
      ms_queue_put(f->outputs[0],om);
      om=getq(&d->rq);
    }
  ms_mutex_unlock(&d->mutex);
}

static void androidsnd_read_init(MSFilter *f){
  AndroidSnd *d=(AndroidSnd *)ms_new0(AndroidSnd,1);

  d->nchannels=1;
  d->rate=16000;
  d->jenv=NULL;
  d->jobj=NULL;
  qinit(&d->rq);
  d->bufferizer = ms_bufferizer_new();
  ms_mutex_init(&d->mutex,NULL);
  ms_cond_init(&d->cond, 0);

  d->read_started=FALSE;
  d->write_started=FALSE;
  d->thread=0;

  d->stat_input=0;
  d->stat_output=0;
  d->stat_notplayed=0;
  d->stat_minimumbuffer=androidsnd_MINIMUMBUFFER;

#if defined(MODE_PREPARE_BEFORE_ATTACH)
  d->mode=1;
#endif
  f->data=d;

  if (d->mode!=0)
    android_start_r(f);
}

static void * android_write_thread(void *p){
  MSFilter *f=p;
  AndroidSnd *d=(AndroidSnd*)f->data;
  int res;

  ms_message("android_write_thread");
  if (d->jenv==NULL)
    {
      res = (*jvm)->AttachCurrentThread(jvm, &d->jenv, NULL);
      if (res!=0)
	ms_message("AttachCurrentThread failed! %i", res);
      if (d->jenv==NULL)
	return;
      ms_message("android_write_thread: current thread attached");
      d->jobj = (*d->jenv)->NewGlobalRef(d->jenv, (*d->jenv)->NewObject(d->jenv, audiooutput_myclz, audiooutput_cons, d->rate));
      ms_message("New Java Object AudioOutput allocated");
    }
	
  if (d->jobj==NULL)
    {
      ms_message("Failed to allocate Java Object AudioOutput");
      return ;
    }

  jbyteArray jdata = (*d->jenv)->NewByteArray(d->jenv, 320);
	    
  while(d->write_started)
    {
      int buf_size;
      ms_mutex_lock(&d->mutex);

      buf_size = ms_bufferizer_get_avail(d->bufferizer);
      while (buf_size>=320) {
	char buf[320];

	ms_bufferizer_read(d->bufferizer, buf, 320);
	ms_mutex_unlock(&d->mutex);

	(*d->jenv)->SetByteArrayRegion(d->jenv, jdata, 0, 320, (jbyte*)buf);
	    
	int size = (*d->jenv)->CallIntMethod(d->jenv, d->jobj, audiooutput_cons_write_bytes,
					     jdata, 320);
	if (size<=0)
	  {
	    ms_message("AudioOutput write_bytes failure %i", size);
	  }
	ms_mutex_lock(&d->mutex);
	if (buf_size > (d->rate*2*d->nchannels*250)/1000)
	  {
	    ms_warning("dropping packets (%i)", buf_size);
	    ms_bufferizer_flush(d->bufferizer);
	  }
	buf_size = ms_bufferizer_get_avail(d->bufferizer);
      }
      if (d->filter_attached==TRUE) {
	if (d->write_started) ms_cond_wait(&d->cond, &d->mutex);
      } else {
	int size = (*d->jenv)->CallIntMethod(d->jenv, d->jobj, audiooutput_cons_write_bytes,
					     NULL, 0);	
	osip_usleep(10000);
      }
      ms_mutex_unlock(&d->mutex);
    }

  (*d->jenv)->DeleteLocalRef(d->jenv, jdata);


  (*d->jenv)->CallIntMethod(d->jenv, d->jobj, audiooutput_cons_halt);
  ms_message("calling destructor for Output!");
  (*d->jenv)->DeleteGlobalRef(d->jenv, d->jobj);

  res = (*jvm)->DetachCurrentThread(jvm);
  if (res!=0)
    ms_message("DetachCurrentThread failed! %i", res);
  d->jobj=NULL;
  d->jenv=NULL;

}

static void android_start_w(MSFilter *f){
  AndroidSnd *d=(AndroidSnd*)f->data;
  if (d->write_started==FALSE){
    d->write_started=TRUE;
    d->reset=0;
    ms_thread_create(&d->thread,NULL,android_write_thread,f);
  }
}

static void android_stop_w(MSFilter *f){
  AndroidSnd *d=(AndroidSnd*)f->data;
  d->write_started=FALSE;
  if (d->thread!=0)
    {
      ms_mutex_lock(&d->mutex);
      ms_cond_signal(&d->cond);
      ms_mutex_unlock(&d->mutex);
      ms_thread_join(d->thread,NULL);
      d->thread=0;
    }
}

static void androidsnd_write_uninit(MSFilter *f){
  AndroidSnd *d=(AndroidSnd*)f->data;

  if (d->mode!=0)
    android_stop_w(f);

  d->jenv=NULL;
  d->jobj=NULL;
  flushq(&d->rq,0);
  ms_bufferizer_flush(d->bufferizer);
  ms_bufferizer_destroy(d->bufferizer);
  ms_mutex_destroy(&d->mutex);
  ms_cond_destroy(&d->cond);
  ms_free(f->data);
}

static void androidsnd_write_preprocess(MSFilter *f){
  AndroidSnd *d=(AndroidSnd*)f->data;

  d->stat_input=0;
  d->stat_output=0;
  d->stat_notplayed=0;
  d->stat_minimumbuffer=androidsnd_MINIMUMBUFFER;

  if (d->write_started==TRUE && d->reset==1) {
    android_stop_w(f);
  }

  d->filter_attached=TRUE;

  android_start_w(f);
}

static void androidsnd_write_postprocess(MSFilter *f){
  AndroidSnd *d=(AndroidSnd*)f->data;

  if (d->mode==0)
    android_stop_w(f);
  d->filter_attached=FALSE;
  if (d->mode!=0) {
    ms_mutex_lock(&d->mutex);
    ms_cond_signal(&d->cond);
    ms_mutex_unlock(&d->mutex);
  }

  ms_message("androidsnd_write_postprocess: device closed (playing: %i) (input-output: %i) (notplayed: %i)",
	     d->nbufs_playing, d->stat_output, d->stat_notplayed);
}

static void androidsnd_write_process(MSFilter *f){
  AndroidSnd *d=(AndroidSnd*)f->data;
  mblk_t *m;
  int discarded=0;

  if (d->reset==1) {
    android_stop_w(f);
    android_start_w(f);
  }

  ms_mutex_lock(&d->mutex);
  while((m=ms_queue_get(f->inputs[0]))!=NULL){
    ms_bufferizer_put(d->bufferizer, m);
  }
  ms_cond_signal(&d->cond);
  ms_mutex_unlock(&d->mutex);
  if (discarded>0)
    ms_message("androidsnd_write_process: %i buffer removed", discarded);
}

static void androidsnd_write_init(MSFilter *f){
  AndroidSnd *d=(AndroidSnd *)ms_new0(AndroidSnd,1);

  d->nchannels=1;
  d->rate=16000;
  d->jenv=NULL;
  d->jobj=NULL;
  qinit(&d->rq);
  d->bufferizer = ms_bufferizer_new();
  ms_mutex_init(&d->mutex,NULL);
  ms_cond_init(&d->cond, 0);

  d->read_started=FALSE;
  d->write_started=FALSE;
  d->thread=0;

  d->stat_input=0;
  d->stat_output=0;
  d->stat_notplayed=0;
  d->stat_minimumbuffer=androidsnd_MINIMUMBUFFER;

#if defined(MODE_PREPARE_BEFORE_ATTACH)
  d->mode=1;
#endif
  f->data=d;

  if (d->mode!=0)
    android_start_w(f);
}

static int androidsnd_read_get_rate(MSFilter *f, void *arg){
  AndroidSnd *d=(AndroidSnd*)f->data;
  *((int*)arg)=d->rate;
  return 0;
}

static int androidsnd_write_get_rate(MSFilter *f, void *arg){
  AndroidSnd *d=(AndroidSnd*)f->data;
  *((int*)arg)=d->rate;
  return 0;
}

static int set_rate(MSFilter *f, void *arg){
  AndroidSnd *d=(AndroidSnd*)f->data;
  if (rate[0]==*((int*)arg)
      ||rate[1]==*((int*)arg)
      ||rate[2]==*((int*)arg)
      ||rate[3]==*((int*)arg)
      ||rate[4]==*((int*)arg)) {

    if (d->rate!=*((int*)arg)) {
      d->rate=*((int*)arg);
      d->reset=1;
    }
  }
  return 0;
}

static int set_nchannels(MSFilter *f, void *arg){
  AndroidSnd *d=(AndroidSnd*)f->data;
  d->nchannels=*((int*)arg);
  return 0;
}

static int androidsnd_get_stat_input(MSFilter *f, void *arg){
  AndroidSnd *d=(AndroidSnd*)f->data;
  return d->stat_input;
}

static int androidsnd_get_stat_ouptut(MSFilter *f, void *arg){
  AndroidSnd *d=(AndroidSnd*)f->data;
  return d->stat_output;
}

static int androidsnd_get_stat_discarded(MSFilter *f, void *arg){
  AndroidSnd *d=(AndroidSnd*)f->data;
  return d->stat_notplayed;
}

static MSFilterMethod androidsnd_read_methods[]={
  {	MS_FILTER_GET_SAMPLE_RATE	, androidsnd_read_get_rate	},
  {	MS_FILTER_SET_SAMPLE_RATE	, set_rate	},
  {	MS_FILTER_SET_NCHANNELS		, set_nchannels	},
  {	MS_FILTER_GET_STAT_INPUT, androidsnd_get_stat_input },
  {	MS_FILTER_GET_STAT_OUTPUT, androidsnd_get_stat_ouptut },
  {	MS_FILTER_GET_STAT_DISCARDED, androidsnd_get_stat_discarded },
  {	0				, NULL		}
};

MSFilterDesc androidsnd_read_desc={
  MS_FILTER_PLUGIN_ID,
  "AndroidSndRead",
  "Sound capture filter for Android",
  MS_FILTER_OTHER,
  NULL,
  0,
  1,
  androidsnd_read_init,
  androidsnd_read_preprocess,
  androidsnd_read_process,
  androidsnd_read_postprocess,
  androidsnd_read_uninit,
  androidsnd_read_methods
};

static MSFilterMethod androidsnd_write_methods[]={
  {	MS_FILTER_GET_SAMPLE_RATE	, androidsnd_write_get_rate	},
  {	MS_FILTER_SET_SAMPLE_RATE	, set_rate	},
  {	MS_FILTER_SET_NCHANNELS		, set_nchannels	},
  {	MS_FILTER_GET_STAT_INPUT, androidsnd_get_stat_input },
  {	MS_FILTER_GET_STAT_OUTPUT, androidsnd_get_stat_ouptut },
  {	MS_FILTER_GET_STAT_DISCARDED, androidsnd_get_stat_discarded },
  {	0				, NULL		}
};

MSFilterDesc androidsnd_write_desc={
  MS_FILTER_PLUGIN_ID,
  "AndroidSndWrite",
  "Sound playback filter for Android",
  MS_FILTER_OTHER,
  NULL,
  1,
  0,
  androidsnd_write_init,
  androidsnd_write_preprocess,
  androidsnd_write_process,
  androidsnd_write_postprocess,
  androidsnd_write_uninit,
  androidsnd_write_methods
};

MSFilter *ms_androidsnd_read_new(MSSndCard *card){
  MSFilter *f=ms_filter_new_from_desc(&androidsnd_read_desc);
  AndroidCard *wc=(AndroidCard*)card->data;
  AndroidSnd *d=(AndroidSnd*)f->data;
  strncpy(d->devname, wc->devname, sizeof(d->devname));
  strncpy(d->deviceid, wc->deviceid, sizeof(d->deviceid));
  return f;
}


MSFilter *ms_androidsnd_write_new(MSSndCard *card){
  MSFilter *f=ms_filter_new_from_desc(&androidsnd_write_desc);
  AndroidCard *wc=(AndroidCard*)card->data;
  AndroidSnd *d=(AndroidSnd*)f->data;
  strncpy(d->devname, wc->devname, sizeof(d->devname));
  strncpy(d->deviceid, wc->deviceid, sizeof(d->deviceid));
  return f;
}

