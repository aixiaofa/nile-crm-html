/*
  amsip is a SIP library for softphone (SIP -rfc3261-)
  Copyright (C) 2003,2004,2005,2006,2007,2008,2009,2010  Aymeric MOIZARD - <amoizard@gmail.com>
*/

#include <string.h>
#include <jni.h>

#include <amsip/am_options.h>

#define AMDROID_VERSION "amdroid/0.1"

extern void libmssocketreader_init();
extern void libmsitug729_init();
extern void libmsbcg729_init();
extern void libmssilk_init();
extern void libmsopus_init();
extern void libmswebrtc_init();
extern void libmsantisipx264_init();
extern void libmsandroidmediacodecenc_init();
extern void libmsandroidmediacodecdec_init();
extern void libmslibyuv_init();
extern void libmsvp8_init();
extern void libmsffmpeg_init();
extern void libmsnoimage_init();
extern void libmsvideostitcher_init();

#include <cpu-features.h>

int rate[] = {
  8000,
  0,
  0,
  0,
  0
};

JNIEXPORT static jint
Java_amsip_aminit( JNIEnv* env, jobject thiz, jint debug_level)
{
  int i = am_init(AMDROID_VERSION, debug_level);

#ifdef HAVE_MSITUG729
  libmsitug729_init();
#endif
#ifdef HAVE_MSBCG729
  libmsbcg729_init();
#endif

#ifdef HAVE_SILK
  libmssilk_init();
#endif

#ifdef HAVE_OPUS
  libmsopus_init();
#endif

#ifdef HAVE_WEBRTC
  libmswebrtc_init();
#endif

#ifdef ENABLE_VIDEO
  libmssocketreader_init();
  libmsandroidpixconv_init();
#ifdef HAVE_X264
  libmsantisipx264_init();
#endif

#ifdef HAVE_VP8
  libmsvp8_init();
#endif
#ifdef HAVE_OPENH264
  libmsopenh264_init();
#endif
  libmslibyuv_init();
  libmsffmpeg_init();
  libmsvideostitcher_init();
  libmsnoimage_init();
#endif

  if (i==0)
    {
      am_codec_info_t codec;
      memset(&codec, 0, sizeof(codec));
      snprintf(codec.name, 64, "SILK");
      codec.payload = 97;
      codec.enable = 0;
      codec.freq = 8000;
      codec.vbr = 0;
      codec.cng = 0;
      codec.mode = 0;
      am_codec_info_modify(&codec, 0);

      memset(&codec, 0, sizeof(codec));
      snprintf(codec.name, 64, "GSM");
      codec.payload = 3;
      codec.enable = 0;
      codec.freq = 8000;
      codec.vbr = 0;
      codec.cng = 0;
      codec.mode = 0;
      am_codec_info_modify(&codec, 1);
      
      memset(&codec, 0, sizeof(codec));
      snprintf(codec.name, 64, "speex");
      codec.payload = 99;
      codec.enable = 0;
      codec.freq = 8000;
      codec.vbr = 0;
      codec.cng = 1;
      codec.mode = 3;
      am_codec_info_modify(&codec, 2);
      
      memset(&codec, 0, sizeof(codec));
      snprintf(codec.name, 64, "iLBC");
      codec.payload = 103;
      codec.enable = 0;
      codec.freq = 8000;
      codec.mode = 30;
      am_codec_info_modify(&codec, 3);
      
      memset(&codec, 0, sizeof(codec));
      snprintf(codec.name, 64, "PCMU");
      codec.payload = 0;
      codec.enable = 1;
      codec.freq = 8000;
      am_codec_info_modify(&codec, 4);
      
      memset(&codec, 0, sizeof(codec));
      snprintf(codec.name, 64, "PCMA");
      codec.payload = 8;
      codec.enable = 0;
      codec.freq = 8000;
      am_codec_info_modify(&codec, 5);

#ifdef ENABLE_VIDEO
      {
	am_video_codec_info_t video_codec;
	am_video_codec_attr_t codec_attr;

        memset(&video_codec, 0, sizeof(video_codec));
        am_video_codec_info_modify(&video_codec, 0);
        am_video_codec_info_modify(&video_codec, 1);
        am_video_codec_info_modify(&video_codec, 2);
        am_video_codec_info_modify(&video_codec, 3);

        snprintf(video_codec.name, 64, "H263-1998");
        video_codec.payload = 115;
        video_codec.enable = 1;
        video_codec.freq = 90000;
        am_video_codec_info_modify(&video_codec, 0);

        snprintf(video_codec.name, 64, "MP4V-ES");
        video_codec.payload = 116;
        video_codec.enable = 0;
        video_codec.freq = 90000;
        am_video_codec_info_modify(&video_codec, 1);

        snprintf(video_codec.name, 64, "H264");
        video_codec.payload = 117;
        video_codec.enable = 0;
        video_codec.freq = 90000;
        am_video_codec_info_modify(&video_codec, 2);

        snprintf(video_codec.name, 64, "VP8");
        video_codec.payload = 118;
        video_codec.enable = 0;
        video_codec.freq = 90000;
        am_video_codec_info_modify(&video_codec, 3);

	codec_attr.ptime = 0;
	codec_attr.maxptime = 0;
	codec_attr.upload_bandwidth = 128;
	codec_attr.download_bandwidth = 128;
	am_video_codec_attr_modify(&codec_attr);
      }
#endif
    }

  return i;
}

JNIEXPORT static jint
Java_amsip_amreset( JNIEnv* env, jobject thiz,
					jint debug_level)
{
  int i = am_reset(AMDROID_VERSION, debug_level);

  if (i==0)
    {
      am_codec_info_t codec;
      memset(&codec, 0, sizeof(codec));
      snprintf(codec.name, 64, "SILK");
      codec.payload = 97;
      codec.enable = 0;
      codec.freq = 8000;
      codec.vbr = 0;
      codec.cng = 0;
      codec.mode = 0;
      am_codec_info_modify(&codec, 0);

      memset(&codec, 0, sizeof(codec));
      snprintf(codec.name, 64, "GSM");
      codec.payload = 3;
      codec.enable = 0;
      codec.freq = 8000;
      codec.vbr = 0;
      codec.cng = 0;
      codec.mode = 0;
      am_codec_info_modify(&codec, 1);
      
      memset(&codec, 0, sizeof(codec));
      snprintf(codec.name, 64, "speex");
      codec.payload = 99;
      codec.enable = 0;
      codec.freq = 8000;
      codec.vbr = 0;
      codec.cng = 1;
      codec.mode = 3;
      am_codec_info_modify(&codec, 2);
      
      memset(&codec, 0, sizeof(codec));
      snprintf(codec.name, 64, "iLBC");
      codec.payload = 103;
      codec.enable = 0;
      codec.freq = 8000;
      codec.mode = 30;
      am_codec_info_modify(&codec, 3);
      
      memset(&codec, 0, sizeof(codec));
      snprintf(codec.name, 64, "PCMU");
      codec.payload = 0;
      codec.enable = 1;
      codec.freq = 8000;
      am_codec_info_modify(&codec, 4);
      
      memset(&codec, 0, sizeof(codec));
      snprintf(codec.name, 64, "PCMA");
      codec.payload = 8;
      codec.enable = 0;
      codec.freq = 8000;
      am_codec_info_modify(&codec, 5);

#ifdef ENABLE_VIDEO
      {
	am_video_codec_info_t video_codec;
	am_video_codec_attr_t codec_attr;

        memset(&video_codec, 0, sizeof(video_codec));
        am_video_codec_info_modify(&video_codec, 0);
        am_video_codec_info_modify(&video_codec, 1);
        am_video_codec_info_modify(&video_codec, 2);
        am_video_codec_info_modify(&video_codec, 3);

        snprintf(video_codec.name, 64, "H263-1998");
        video_codec.payload = 115;
        video_codec.enable = 1;
        video_codec.freq = 90000;
        am_video_codec_info_modify(&video_codec, 0);

        snprintf(video_codec.name, 64, "MP4V-ES");
        video_codec.payload = 116;
        video_codec.enable = 0;
        video_codec.freq = 90000;
        am_video_codec_info_modify(&video_codec, 1);

        snprintf(video_codec.name, 64, "H264");
        video_codec.payload = 117;
        video_codec.enable = 0;
        video_codec.freq = 90000;
        am_video_codec_info_modify(&video_codec, 2);

        snprintf(video_codec.name, 64, "VP8");
        video_codec.payload = 118;
        video_codec.enable = 0;
        video_codec.freq = 90000;
        am_video_codec_info_modify(&video_codec, 3);

	codec_attr.ptime = 0;
	codec_attr.maxptime = 0;
	codec_attr.upload_bandwidth = 128;
	codec_attr.download_bandwidth = 128;
	am_video_codec_attr_modify(&codec_attr);
      }
#endif
    }

  return i;
}

JNIEXPORT static jint
Java_amsip_amquit( JNIEnv* env, jobject thiz)
{
  return am_quit();
}

JNIEXPORT static jint
Java_amsip_amcodecinfomodify( JNIEnv* env, jobject thiz,
							 jint pos, jint enable,
							 jstring codec_name,
							 jint mode, jint cng, jint vbr)
{
  am_codec_info_t codec;
  jboolean iscopy;
  int i;
  const char *cstr = (*env)->GetStringUTFChars(env, 
	  codec_name, &iscopy);

  if (strcasecmp(cstr, "PCMA/8000")==0) {
    memset(&codec, 0, sizeof(codec));
    snprintf(codec.name, 64, "PCMA");
    codec.payload = 8;
    codec.enable = enable;
    codec.freq = 8000;
    codec.mode = mode;
    am_codec_info_modify(&codec, pos);
  } else if (strcasecmp(cstr, "PCMU/8000")==0) {
    memset(&codec, 0, sizeof(codec));
    snprintf(codec.name, 64, "PCMU");
    codec.payload = 0;
    codec.enable = enable;
    codec.freq = 8000;
    codec.mode = mode;
    am_codec_info_modify(&codec, pos);
  } else if (strcasecmp(cstr, "GSM/8000")==0) {
    memset(&codec, 0, sizeof(codec));
    snprintf(codec.name, 64, "GSM");
    codec.payload = 3;
    codec.enable = enable;
    codec.freq = 8000;
    codec.mode = mode;
    am_codec_info_modify(&codec, pos);
  } else if (strcasecmp(cstr, "SILK/8000")==0) {
    memset(&codec, 0, sizeof(codec));
    snprintf(codec.name, 64, "SILK");
    codec.payload = 97;
    codec.enable = enable;
    codec.freq = 8000;
    codec.vbr = vbr; /* 0 */
    codec.cng = cng; /* 0 */
    codec.mode = mode; /* 0 */
    am_codec_info_modify(&codec, pos);
  } else if (strcasecmp(cstr, "SILK/16000")==0) {
    memset(&codec, 0, sizeof(codec));
    snprintf(codec.name, 64, "SILK");
    codec.payload = 98;
    codec.enable = enable;
    codec.freq = 16000;
    codec.vbr = vbr; /* 0 */
    codec.cng = cng; /* 0 */
    codec.mode = mode; /* 0 */
    am_codec_info_modify(&codec, pos);
  } else if (strcasecmp(cstr, "speex/8000")==0) {
    memset(&codec, 0, sizeof(codec));
    snprintf(codec.name, 64, "speex");
    codec.payload = 99;
    codec.enable = enable;
    codec.freq = 8000;
    codec.vbr = vbr; /* 0 or 1: should be 0 on mobile platform */
    codec.cng = cng; /* 0 or 1 */
    codec.mode = mode; /* between O and 6 */
    am_codec_info_modify(&codec, pos);
  } else if (strcasecmp(cstr, "speex/16000")==0) {
    memset(&codec, 0, sizeof(codec));
    snprintf(codec.name, 64, "speex");
    codec.payload = 100;
    codec.enable = enable;
    codec.freq = 16000;
    codec.vbr = vbr; /* 0 or 1: should be 0 on mobile platform */
    codec.cng = cng; /* 0 or 1 */
    codec.mode = mode; /* between O and 6 */
    am_codec_info_modify(&codec, pos);
  } else if (strcasecmp(cstr, "speex/32000")==0) {
    memset(&codec, 0, sizeof(codec));
    snprintf(codec.name, 64, "speex");
    codec.payload = 102;
    codec.enable = enable;
    codec.freq = 32000;
    codec.vbr = vbr; /* 0 or 1: should be 0 on mobile platform */
    codec.cng = cng; /* 0 or 1 */
    codec.mode = mode; /* between O and 6 */
    am_codec_info_modify(&codec, pos);
  } else if (strcasecmp(cstr, "iLBC/8000")==0) {
    memset(&codec, 0, sizeof(codec));
    snprintf(codec.name, 64, "iLBC");
    codec.payload = 103;
    codec.enable = enable;
    codec.freq = 8000;
    codec.mode = mode; /* must be 20 or 30 */
    am_codec_info_modify(&codec, pos);
  } else if (strcasecmp(cstr, "isac/16000")==0) {
    memset(&codec, 0, sizeof(codec));
    snprintf(codec.name, 64, "isac");
    codec.payload = 104;
    codec.enable = enable;
    codec.freq = 16000;
    codec.mode = 0;
    am_codec_info_modify(&codec, pos);
  } else if (strcasecmp(cstr, "OPUS/48000")==0) {
    memset(&codec, 0, sizeof(codec));
    snprintf(codec.name, 64, "OPUS");
    codec.payload = 105;
    codec.enable = enable;
    codec.freq = 48000;
    codec.vbr = vbr; /* 0 */
    codec.cng = cng; /* 0 */
    codec.mode = mode; /* 0 */
    am_codec_info_modify(&codec, pos);
  } else if (strcasecmp(cstr, "g729/8000")==0) {
    memset(&codec, 0, sizeof(codec));
    snprintf(codec.name, 64, "g729");
    codec.payload = 18;
    codec.enable = enable;
    codec.freq = 8000;
    codec.mode = mode; /* must be 10, 20 or 30 */
    am_codec_info_modify(&codec, pos);
  } else if (strcasecmp(cstr, "g722/8000")==0) {
    memset(&codec, 0, sizeof(codec));
    snprintf(codec.name, 64, "g722");
    codec.payload = 9;
    codec.enable = enable;
    codec.freq = 8000;
    codec.mode = mode;
    am_codec_info_modify(&codec, pos);
  }

  (*env)->ReleaseStringUTFChars(env, codec_name, cstr);
  return i;
}

JNIEXPORT static jint
Java_amsip_amvideocodecinfomodify( JNIEnv* env, jobject thiz,
							 jint pos, jint enable,
							 jstring codec_name,
							 jint mode, jint cng, jint vbr)
{
#ifdef ENABLE_VIDEO
  am_video_codec_info_t video_codec;
  am_video_codec_attr_t codec_attr;

  jboolean iscopy;
  int i = -1;
  const char *cstr = (*env)->GetStringUTFChars(env, 
	  codec_name, &iscopy);

  if (strcasecmp(cstr, "H263-1998/90000")==0) {
    memset(&video_codec, 0, sizeof(video_codec));
    snprintf(video_codec.name, 64, "H263-1998");
    video_codec.payload = 115;
    video_codec.enable = enable;
    video_codec.freq = 90000;
    video_codec.mode = mode;
    i = am_video_codec_info_modify(&video_codec, pos);
  } else if (strcasecmp(cstr, "H263/90000")==0) {
    memset(&video_codec, 0, sizeof(video_codec));
    snprintf(video_codec.name, 64, "H263");
    video_codec.payload = 34;
    video_codec.enable = enable;
    video_codec.freq = 90000;
    video_codec.mode = mode;
    i = am_video_codec_info_modify(&video_codec, pos);
  } else if (strcasecmp(cstr, "MP4V-ES/90000")==0) {
    memset(&video_codec, 0, sizeof(video_codec));
    snprintf(video_codec.name, 64, "MP4V-ES");
    video_codec.payload = 116;
    video_codec.enable = enable;
    video_codec.freq = 90000;
    video_codec.mode = mode;
    i =am_video_codec_info_modify(&video_codec, pos);
  } else if (strcasecmp(cstr, "H264/90000")==0) {
    memset(&video_codec, 0, sizeof(video_codec));
    snprintf(video_codec.name, 64, "H264");
    video_codec.payload = 117;
    video_codec.enable = enable;
    video_codec.freq = 90000;
    video_codec.mode = mode;
    i = am_video_codec_info_modify(&video_codec, pos);
  } else if (strcasecmp(cstr, "VP8/90000")==0) {
    memset(&video_codec, 0, sizeof(video_codec));
    snprintf(video_codec.name, 64, "VP8");
    video_codec.payload = 118;
    video_codec.enable = enable;
    video_codec.freq = 90000;
    video_codec.mode = 0;
    i = am_video_codec_info_modify(&video_codec, pos);
  }
  
  (*env)->ReleaseStringUTFChars(env, codec_name, cstr);
  return i;
#else
  return -1;
#endif
}

JNIEXPORT static jint
Java_amsip_amvideocodecattrmodify( JNIEnv* env, jobject thiz,
							      jint uploadrate, jint downloadrate)
{
#ifdef ENABLE_VIDEO
	am_video_codec_attr_t codec_attr;
	codec_attr.ptime = 0;
	codec_attr.maxptime = 0;
	codec_attr.upload_bandwidth = uploadrate;
	codec_attr.download_bandwidth = downloadrate;
	return am_video_codec_attr_modify(&codec_attr);
#else
	return -1;
#endif
}

JNIEXPORT static jint
Java_amsip_amcodecattrmodify( JNIEnv* env, jobject thiz, jint ptime, jint bandwidth)
{
  struct am_codec_attr attr;
  memset(&attr, 0, sizeof(struct am_codec_attr));

  attr.ptime = ptime;
  attr.maxptime = 0; /* UNUSED */
  attr.bandwidth = bandwidth;

  return am_codec_attr_modify(&attr);
}

JNIEXPORT static jstring
Java_amsip_amoptiongetversion(JNIEnv* env, jobject thiz)
{
  return (*env)->NewStringUTF(env, am_option_get_version());
}

JNIEXPORT static jint 
Java_amsip_amoptionsetuseragent( JNIEnv* env, jobject thiz,
jstring useragent)
{
  jboolean iscopy;
  int i;
  const char *cstr = (*env)->GetStringUTFChars(env, 
	  useragent, &iscopy);
  i = am_option_set_option (AMSIP_OPTION_SET_HEADER_USER_AGENT, (void*)cstr);
  (*env)->ReleaseStringUTFChars(env, useragent, cstr);
  return i;
}

JNIEXPORT static jint
Java_amsip_amoptionsetinitialaudioport( JNIEnv* env, jobject thiz,
					jint initialport)
{
  return am_option_set_option(AMSIP_OPTION_SET_INITIALAUDIOPORT, (void*)&initialport);
}

JNIEXPORT static jint
Java_amsip_amoptionenablestunserver( JNIEnv* env, jobject thiz,
					jstring stunserver, jint enable)
{
  jboolean iscopy;
  int i;
  const char *cstr = (*env)->GetStringUTFChars(env, 
	  stunserver, &iscopy);
  i = am_option_set_option(AMSIP_OPTION_SET_STUN_SERVER, (void *)cstr);
  (*env)->ReleaseStringUTFChars(env, stunserver, cstr);
  return i;
}

JNIEXPORT static jint
Java_amsip_amoptionenableturnserver( JNIEnv* env, jobject thiz,
					jstring turnserver, jint enable)
{
  jboolean iscopy;
  int i;
  const char *cstr = (*env)->GetStringUTFChars(env, 
	  turnserver, &iscopy);
  i = am_option_set_option(AMSIP_OPTION_SET_TURN_SERVER, (void *)cstr);
  (*env)->ReleaseStringUTFChars(env, turnserver, cstr);
  return i;
}

JNIEXPORT static jint
Java_amsip_amoptionsetipv4forgateway( JNIEnv* env, jobject thiz,
					jstring ipv4forgateway)
{
  jboolean iscopy;
  int i;
  const char *cstr = (*env)->GetStringUTFChars(env, 
	  ipv4forgateway, &iscopy);
  i = am_option_set_option(AMSIP_OPTION_SET_IPV4_FOR_GATEWAY, (void *)cstr);
  (*env)->ReleaseStringUTFChars(env, ipv4forgateway, cstr);
  return i;
}

JNIEXPORT static jint
Java_amsip_amoptionenablerport( JNIEnv* env, jobject thiz,
					jint enable)
{
  return am_option_set_option(AMSIP_OPTION_ENABLE_RPORT, &enable);
}

JNIEXPORT static jint
Java_amsip_amoptionsetdnscapabilities( JNIEnv* env, jobject thiz,
					jint dnscapabilities)
{
  return am_option_set_option(AMSIP_OPTION_ENABLE_NAPTR, &dnscapabilities);
}

JNIEXPORT static jint
Java_amsip_amoptionenablekeepalive( JNIEnv* env, jobject thiz,
					jint interval)
{
  return am_option_set_option(AMSIP_OPTION_SET_KEEPALIVE_INTERVAL, &interval);
}

JNIEXPORT static jint
Java_amsip_amoptionsetaudioprofile( JNIEnv* env, jobject thiz,
					jstring profile )
{
  jboolean iscopy;
  int i;
  const char *cstr = (*env)->GetStringUTFChars(env, 
	  profile, &iscopy);
  i = am_option_set_option(AMSIP_OPTION_SET_AUDIO_RTP_PROFILE, (void *)cstr);
  (*env)->ReleaseStringUTFChars(env, profile, cstr);
  return i;
}

JNIEXPORT static jint
Java_amsip_amoptionsetvideoprofile( JNIEnv* env, jobject thiz,
					jstring profile )
{
  jboolean iscopy;
  int i;
  const char *cstr = (*env)->GetStringUTFChars(env, 
	  profile, &iscopy);
  i = am_option_set_option(AMSIP_OPTION_SET_VIDEO_RTP_PROFILE, (void *)cstr);
  (*env)->ReleaseStringUTFChars(env, profile, cstr);
  return i;
}

JNIEXPORT static jint
Java_amsip_amoptionsettextprofile( JNIEnv* env, jobject thiz,
					jstring profile )
{
  jboolean iscopy;
  int i;
  const char *cstr = (*env)->GetStringUTFChars(env, 
	  profile, &iscopy);
  i = am_option_set_option(AMSIP_OPTION_SET_TEXT_RTP_PROFILE, (void *)cstr);
  (*env)->ReleaseStringUTFChars(env, profile, cstr);
  return i;
}

JNIEXPORT static jint
Java_amsip_amoptionsetudpftpprofile( JNIEnv* env, jobject thiz,
					jstring profile )
{
  jboolean iscopy;
  int i;
  const char *cstr = (*env)->GetStringUTFChars(env, 
	  profile, &iscopy);
  i = am_option_set_option(AMSIP_OPTION_SET_UDPFTP_RTP_PROFILE, (void *)cstr);
  (*env)->ReleaseStringUTFChars(env, profile, cstr);
  return i;
}

JNIEXPORT static jint
Java_amsip_amoptionenablesessiontimers( JNIEnv* env, jobject thiz,
					jint sessionexpires)
{
  return am_option_set_option(AMSIP_OPTION_SET_SESSIONTIMERS, (void *)&sessionexpires);
}

JNIEXPORT static jint
Java_amsip_amoptionenablesymmetricrtp( JNIEnv* env, jobject thiz,
					jint enable)
{
  return am_option_set_option(AMSIP_OPTION_ENABLE_SYMMETRICRTP, &enable);
}

JNIEXPORT static jint
Java_amsip_amoptionselectinsoundcard( JNIEnv* env, jobject thiz,
					jint card)
{
  return am_option_select_in_sound_card(card);
}

JNIEXPORT static jint
Java_amsip_amoptionselectoutsoundcard( JNIEnv* env, jobject thiz,
					jint card)
{
  return am_option_select_out_sound_card(card);
}

JNIEXPORT static jint
Java_amsip_amoptionsetvolumeoutsoundcard( JNIEnv* env, jobject thiz,
					jint card, jint mixer, jint percent)
{
  return am_option_set_volume_out_sound_card(card, mixer, percent);
}

JNIEXPORT static jint
Java_amsip_amoptiongetvolumeoutsoundcard( JNIEnv* env, jobject thiz,
					jint card, jint mixer)
{
  return am_option_get_volume_out_sound_card(card, mixer);
}

JNIEXPORT static jint
Java_amsip_amoptionsetvolumeinsoundcard( JNIEnv* env, jobject thiz,
					jint card, jint percent)
{
  return am_option_set_volume_in_sound_card(card, percent);
}

JNIEXPORT static jint
Java_amsip_amoptiongetvolumeinsoundcard( JNIEnv* env, jobject thiz,
					jint card)
{
  return am_option_get_volume_in_sound_card(card);
}

JNIEXPORT static jint
Java_amsip_amoptionsetmuteoutsoundcard( JNIEnv* env, jobject thiz,
					jint card, jint mixer, jint val)
{
  return am_option_set_mute_out_sound_card(card, mixer, val);
}

JNIEXPORT static jint
Java_amsip_amoptionsetmuteinsoundcard( JNIEnv* env, jobject thiz,
					jint card, jint val)
{
  return am_option_set_mute_in_sound_card(card, val);
}

JNIEXPORT static jint
Java_amsip_amoptionenablewebrtcapm( JNIEnv* env, jobject thiz,
					jint enable,
					jint aecm, jint aecm_comfort_noise, jint aecm_routing_mode,
					jint ns, jint ns_level,
					jint agc, jint agc_mode, jint agc_target_level_dbfs, jint agc_compression_gain_db,
					jint high_pass_filter)
{
  struct am_option_webrtc_apm wapm;
  memset(&wapm, 0, sizeof(wapm));
  wapm.enable = enable;

  wapm.aecm = aecm;
  wapm.aecm_comfort_noise = aecm_comfort_noise;
  wapm.aecm_routing_mode = aecm_routing_mode;

  wapm.agc = agc;
  wapm.agc_mode = agc_mode;
  wapm.agc_target_level_dbfs = agc_target_level_dbfs;
  wapm.agc_compression_gain_db = agc_compression_gain_db;

  wapm.ns = ns;
  wapm.ns_level = ns_level;

  wapm.high_pass_filter = high_pass_filter;

  return am_option_conference_set_audio_option (0, AMSIP_OPTION_AUDIO_ENABLE_WEBRTC_APM, (void*)&wapm);
}

JNIEXPORT static jint
Java_amsip_amoptionenableechocanceller( JNIEnv* env, jobject thiz,
					jint enable, jint framesize, jint taillength)
{
  struct am_option_aec val;
  memset(&val, 0, sizeof(val));
  val.enable = enable;
  val.frame_size = framesize;
  val.tail_length = taillength;

  return am_option_conference_set_audio_option (0, AMSIP_OPTION_AUDIO_ENABLE_AEC, (void*)&val);
}

JNIEXPORT static jint
Java_amsip_amoptionenableagc( JNIEnv* env, jobject thiz,
					jint enable, jint agclevel, jint maxgain)
{
  struct am_option_audio_agc val;
  memset(&val, 0, sizeof(val));
  val.enable = enable;
  val.agc_level = agclevel;
  val.max_gain = maxgain;

  return am_option_conference_set_audio_option (0, AMSIP_OPTION_AUDIO_ENABLE_AGC, (void*)&val);
}

JNIEXPORT static jint
Java_amsip_amoptionsetjittermode( JNIEnv* env, jobject thiz,
					jint mode)
{
  struct am_option_audio_jitter jitter_option;
  memset(&jitter_option, 0, sizeof(jitter_option));
  jitter_option.mode=mode;

  return am_option_conference_set_audio_option (0, AMSIP_OPTION_AUDIO_SET_JITTER, (void*)&jitter_option);
}

JNIEXPORT static jint
Java_amsip_amoptionvideosetjittermode( JNIEnv* env, jobject thiz,
					jint mode)
{
  struct am_option_audio_jitter jitter_option;
  memset(&jitter_option, 0, sizeof(jitter_option));
  jitter_option.mode=mode;

  return am_option_conference_set_video_option (0, AMSIP_OPTION_VIDEO_SET_JITTER, (void*)&jitter_option);
}

JNIEXPORT static jint
Java_amsip_amoptionsetpassword( JNIEnv* env, jobject thiz,
					jstring realm, jstring login, jstring passwd)
{
  jboolean iscopy;
  int i;
  const char *cstr_realm = (*env)->GetStringUTFChars(env, 
	  realm, &iscopy);
  const char *cstr_login = (*env)->GetStringUTFChars(env, 
	  login, &iscopy);
  const char *cstr_passwd = (*env)->GetStringUTFChars(env, 
	  passwd, &iscopy);
  i = am_option_set_password (cstr_realm, cstr_login, cstr_passwd);
  (*env)->ReleaseStringUTFChars(env, realm, cstr_realm);
  (*env)->ReleaseStringUTFChars(env, login, cstr_login);
  (*env)->ReleaseStringUTFChars(env, passwd, cstr_passwd);
  return i;
}

JNIEXPORT static jint
Java_amsip_amoptionloadplugins( JNIEnv* env, jobject thiz,
					jstring directory)
{
  jboolean iscopy;
  int i;
  const char *cstr = (*env)->GetStringUTFChars(env, 
	  directory, &iscopy);
  i =am_option_load_plugins(cstr);
  (*env)->ReleaseStringUTFChars(env, directory, cstr);
  return i;
}

JNIEXPORT static jint
Java_amsip_amoptionenableoptionnalencryption( JNIEnv* env, jobject thiz,
					jint optionnalencryption)
{
  return am_option_set_option(AMSIP_OPTION_ENABLE_OPTIONNAL_ENCRYPTION, (void*)&optionnalencryption);
}

JNIEXPORT static jint
Java_amsip_amoptionsetdscpvalue( JNIEnv* env, jobject thiz,
					jint dscp_value)
{
  return am_option_set_option(AMSIP_OPTION_SET_SIP_DSCP, (void*)&dscp_value);
}

JNIEXPORT static jint
Java_amsip_amoptionsetaudiodscp( JNIEnv* env, jobject thiz,
					jint dscp_value)
{
  return am_option_set_option(AMSIP_OPTION_SET_AUDIO_DSCP, (void*)&dscp_value);
}

JNIEXPORT static jint
Java_amsip_amoptionsetvideodscp( JNIEnv* env, jobject thiz,
					jint dscp_value)
{
  return am_option_set_option(AMSIP_OPTION_SET_VIDEO_DSCP, (void*)&dscp_value);
}

JNIEXPORT static jint
Java_amsip_amoptionsettextdscp( JNIEnv* env, jobject thiz,
					jint dscp_value)
{
  return am_option_set_option(AMSIP_OPTION_SET_TEXT_DSCP, (void*)&dscp_value);
}

JNIEXPORT static jint
Java_amsip_amoptionsetudpftpdscp( JNIEnv* env, jobject thiz,
					jint dscp_value)
{
  return am_option_set_option(AMSIP_OPTION_SET_UDPFTP_DSCP, (void*)&dscp_value);
}

JNIEXPORT static jint
Java_amsip_amoptionsetsupportedextensions( JNIEnv* env, jobject thiz,
					jstring supportedextensions)
{
  jboolean iscopy;
  int i;
  const char *cstr = (*env)->GetStringUTFChars(env, 
	  supportedextensions, &iscopy);
  i = am_option_set_option(AMSIP_OPTION_SET_HEADER_SUPPORTED, (void*)cstr);
  (*env)->ReleaseStringUTFChars(env, supportedextensions, cstr);
  return i;
}

JNIEXPORT static jint
Java_amsip_amoptionsetacceptedtypes( JNIEnv* env, jobject thiz,
					jstring acceptedtypes)
{
  jboolean iscopy;
  int i;
  const char *cstr = (*env)->GetStringUTFChars(env, 
	  acceptedtypes, &iscopy);
  i = am_option_set_option(AMSIP_OPTION_SET_HEADER_ACCEPT, (void*)cstr);
  (*env)->ReleaseStringUTFChars(env, acceptedtypes, cstr);
  return i;
}

JNIEXPORT static jint
Java_amsip_amoptionsetallowedmethods( JNIEnv* env, jobject thiz,
					jstring allowedmethods)
{
  jboolean iscopy;
  int i;
  const char *cstr = (*env)->GetStringUTFChars(env, 
	  allowedmethods, &iscopy);
  i = am_option_set_option(AMSIP_OPTION_SET_HEADER_ALLOWED, (void*)cstr);
  (*env)->ReleaseStringUTFChars(env, allowedmethods, cstr);
  return i;
}

JNIEXPORT static jint
Java_amsip_amoptionsetrate( JNIEnv* env, jobject thiz,
					jint _rate)
{
  /* make sure we set a "tested" rate. (tested in JNI_OnLoad */
  int def_rate=8000;
  if (rate[0]==_rate
      ||rate[1]==_rate
      ||rate[2]==_rate
      ||rate[3]==_rate)
    return am_option_conference_set_audio_option(0, AMSIP_OPTION_AUDIO_SET_RATE, (void*)&_rate);

  if (rate[0]>0)
    return am_option_conference_set_audio_option(0, AMSIP_OPTION_AUDIO_SET_RATE, (void*)&rate[0]);
  if (rate[1]>0)
    return am_option_conference_set_audio_option(0, AMSIP_OPTION_AUDIO_SET_RATE, (void*)&rate[1]);
  if (rate[2]>0)
    return am_option_conference_set_audio_option(0, AMSIP_OPTION_AUDIO_SET_RATE, (void*)&rate[2]);
  if (rate[3]>0)
    return am_option_conference_set_audio_option(0, AMSIP_OPTION_AUDIO_SET_RATE, (void*)&rate[3]);

  return am_option_conference_set_audio_option(0, AMSIP_OPTION_AUDIO_SET_RATE, (void*)&def_rate);
}

JNIEXPORT static jint
Java_amsip_amoptionsetvolumegain( JNIEnv* env, jobject thiz,
					jfloat capturegain, jfloat playbackgain)
{
  am_option_conference_set_audio_option(0, AMSIP_OPTION_AUDIO_SET_VOLUME_CAPTURE_GAIN, (void*)&capturegain);
  return am_option_conference_set_audio_option(0, AMSIP_OPTION_AUDIO_SET_VOLUME_PLAYBACK_GAIN, (void*)&playbackgain);
}

JNIEXPORT static jint
Java_amsip_amoptionsetecholimitation( JNIEnv* env, jobject thiz,
					jint enabled,
					jfloat threshold,
					jfloat speed,
					jfloat force,
					jint sustain)
{
  struct am_option_echo_limitation val;
  memset(&val, 0, sizeof(val));
  val.enabled = enabled;
  val.threshold = threshold;
  val.speed = speed;
  val.force = force;
  val.sustain = sustain;

  return am_option_conference_set_audio_option(0, AMSIP_OPTION_AUDIO_ENABLE_EL, (void*)&val);
}

JNIEXPORT static jlong
Java_amsip_ameventget( JNIEnv* env, jobject thiz)
{
	eXosip_event_t *evt;
	evt = osip_malloc(sizeof(eXosip_event_t));
	if (AMSIP_TIMEOUT==am_event_get(evt))
	{
		osip_free(evt);
		return 0;
	}
	return (jlong)evt;
}

JNIEXPORT static jlong
Java_amsip_ameventwait( JNIEnv* env, jobject thiz,
					jint tvs, jint tvms)
{
	eXosip_event_t *evt;
	evt = osip_malloc(sizeof(eXosip_event_t));
	if (AMSIP_TIMEOUT==am_event_wait(evt, tvs, tvms))
	{
		osip_free(evt);
		return 0;
	}
	return (jlong)evt;
}

JNIEXPORT static int
Java_amsip_ameventgettype( JNIEnv* env, jobject thiz,
					jlong evt)
{
	eXosip_event_t *_evt = (eXosip_event_t *)evt;
	return _evt->type;
}

JNIEXPORT static int
Java_amsip_ameventgettid( JNIEnv* env, jobject thiz,
					jlong evt)
{
	eXosip_event_t *_evt = (eXosip_event_t *)evt;
	return _evt->tid;
}

JNIEXPORT static int
Java_amsip_ameventgetcid( JNIEnv* env, jobject thiz,
					jlong evt)
{
	eXosip_event_t *_evt = (eXosip_event_t *)evt;
	return _evt->cid;
}

JNIEXPORT static int
Java_amsip_ameventgetdid( JNIEnv* env, jobject thiz,
					jlong evt)
{
	eXosip_event_t *_evt = (eXosip_event_t *)evt;
	return _evt->did;
}

JNIEXPORT static int
Java_amsip_ameventgetrid( JNIEnv* env, jobject thiz,
					jlong evt)
{
	eXosip_event_t *_evt = (eXosip_event_t *)evt;
	return _evt->rid;
}

JNIEXPORT static int
Java_amsip_ameventgetnid( JNIEnv* env, jobject thiz,
					jlong evt)
{
	eXosip_event_t *_evt = (eXosip_event_t *)evt;
	return _evt->nid;
}

JNIEXPORT static int
Java_amsip_ameventgetsid( JNIEnv* env, jobject thiz,
					jlong evt)
{
	eXosip_event_t *_evt = (eXosip_event_t *)evt;
	return _evt->sid;
}

JNIEXPORT static jstring
Java_amsip_ameventgetmethod(JNIEnv* env, jobject thiz,
			    jlong evt)
{                     
  eXosip_event_t *_evt = (eXosip_event_t *)evt;
  if (_evt->request==NULL || _evt->request->sip_method==NULL)
    return NULL;      
                      
  return (*env)->NewStringUTF(env, _evt->request->sip_method);
}

JNIEXPORT static jstring
Java_amsip_ameventgetreason(JNIEnv* env, jobject thiz,
						jlong evt)
{
  eXosip_event_t *_evt = (eXosip_event_t *)evt;
  if (_evt->response==NULL || _evt->response->reason_phrase==NULL)
    return NULL;

  return (*env)->NewStringUTF(env, _evt->response->reason_phrase);
}

JNIEXPORT static int
Java_amsip_ameventgetstatuscode(JNIEnv* env, jobject thiz,
						jlong evt)
{
  eXosip_event_t *_evt = (eXosip_event_t *)evt;
  if (_evt->response==NULL)
    return 0;

  return _evt->response->status_code;
}

JNIEXPORT static jstring
Java_amsip_ameventgetrequestheader(JNIEnv* env, jobject thiz,
						       jlong evt, jstring hname, int n)
{
  eXosip_event_t *_evt = (eXosip_event_t *)evt;
  const char *chname;
  jboolean iscopy;
  char *chvalue=NULL;
  jstring hvalue;
  if (_evt->request==NULL)
    return NULL;

  chname = (*env)->GetStringUTFChars(env, 
	  hname, &iscopy);

  if (osip_strcasecmp(chname, "from") == 0) {

    osip_from_t *from;
    int i = osip_from_clone(_evt->request->from, &from);

    if (i == 0) {
      int pos = 0;
      osip_uri_header_t *u_header;
      osip_uri_param_t *u_param;

      while (!osip_list_eol(&from->gen_params, 0)) {
                                u_param =
				  (osip_uri_param_t *) osip_list_get(&from->gen_params,
								     0);
                                osip_list_remove(&from->gen_params, 0);
                                osip_uri_param_free(u_param);
      }
      while (!osip_list_eol(&from->url->url_params, 0)) {
                                u_param =
				  (osip_uri_param_t *) osip_list_get(&from->url->
								     url_params, 0);
                                osip_list_remove(&from->url->url_params, 0);
                                osip_uri_param_free(u_param);
      }
      while (!osip_list_eol(&from->url->url_headers, pos)) {
                                u_header =
				  (osip_uri_header_t *) osip_list_get(&from->url->
								      url_headers, pos);
                                osip_list_remove(&from->url->url_headers, pos);
                                osip_uri_header_free(u_header);
      }

      i = osip_from_to_str(from, &chvalue);
      osip_from_free(from);
    }
  } else if (osip_strcasecmp(chname, "to") == 0) {
    osip_from_t *to;
    int i = osip_to_clone(_evt->request->to, &to);

    if (i == 0) {
      int pos = 0;
      osip_uri_header_t *u_header;
      osip_uri_param_t *u_param;

      while (!osip_list_eol(&to->gen_params, 0)) {
                                u_param =
				  (osip_uri_param_t *) osip_list_get(&to->gen_params, 0);
                                osip_list_remove(&to->gen_params, 0);
                                osip_uri_param_free(u_param);
      }
      while (!osip_list_eol(&to->url->url_params, 0)) {
                                u_param =
				  (osip_uri_param_t *) osip_list_get(&to->url->
								     url_params, 0);
                                osip_list_remove(&to->url->url_params, 0);
                                osip_uri_param_free(u_param);
      }
      while (!osip_list_eol(&to->url->url_headers, pos)) {
                                u_header =
				  (osip_uri_header_t *) osip_list_get(&to->url->
								      url_headers, pos);
                                osip_list_remove(&to->url->url_headers, pos);
                                osip_uri_header_free(u_header);
      }

      i = osip_to_to_str(to, &chvalue);
      osip_to_free(to);
    }

  } else if (osip_strcasecmp(chname, "call-id") == 0) {
    osip_call_id_to_str(_evt->request->call_id, &chvalue);    
  } else if (osip_strcasecmp(chname, "cseq") == 0) {
    osip_cseq_to_str(_evt->request->cseq, &chvalue);
  } else if (osip_strcasecmp(chname, "via") == 0) {
    osip_via_t *via;
    via = (osip_via_t *) osip_list_get(&_evt->request->vias, n);
    if (via!=NULL)
      {
	osip_via_to_str(via, &chvalue);
      }
  } else if (osip_strcasecmp(chname, "contact") == 0) {
    osip_contact_t *co;
    co = (osip_contact_t *) osip_list_get(&_evt->request->contacts, n);
    if (co!=NULL)
      {
	osip_contact_to_str(co, &chvalue);
      }
  } else if (osip_strcasecmp(chname, "route") == 0) {
    osip_route_t *ro;
    ro = (osip_route_t *) osip_list_get(&_evt->request->routes, n);
    if (ro!=NULL)
      {
	osip_contact_to_str(ro, &chvalue);
      }
  } else if (osip_strcasecmp(chname, "content-type") == 0) {
    osip_content_type_to_str(_evt->request->content_type, &chvalue);
  } else {
    osip_header_t *_header=NULL;
    osip_message_header_get_byname(_evt->request, chname, n,
				   &_header);
    if (_header!=NULL)
      {
	osip_header_to_str(_header, &chvalue);
      }
  }


  (*env)->ReleaseStringUTFChars(env, hname, chname);

  if (chvalue==NULL)
    return NULL;

  hvalue = (*env)->NewStringUTF(env, chvalue);
  osip_free(chvalue);

  return hvalue;
}

JNIEXPORT static jstring
Java_amsip_ameventgetresponseheader(JNIEnv* env, jobject thiz,
						       jlong evt, jstring hname, int n)
{
  eXosip_event_t *_evt = (eXosip_event_t *)evt;
  jboolean iscopy;
  const char *chname;
  char *chvalue=NULL;
  jstring hvalue;
  if (_evt->response==NULL)
    return NULL;

  chname = (*env)->GetStringUTFChars(env, 
	  hname, &iscopy);

  if (osip_strcasecmp(chname, "from") == 0) {
    osip_from_t *from;
    int i = osip_from_clone(_evt->response->from, &from);

    if (i == 0) {
      int pos = 0;
      osip_uri_header_t *u_header;
      osip_uri_param_t *u_param;

      while (!osip_list_eol(&from->gen_params, 0)) {
                                u_param =
				  (osip_uri_param_t *) osip_list_get(&from->gen_params,
								     0);
                                osip_list_remove(&from->gen_params, 0);
                                osip_uri_param_free(u_param);
      }
      while (!osip_list_eol(&from->url->url_params, 0)) {
                                u_param =
				  (osip_uri_param_t *) osip_list_get(&from->url->
								     url_params, 0);
                                osip_list_remove(&from->url->url_params, 0);
                                osip_uri_param_free(u_param);
      }
      while (!osip_list_eol(&from->url->url_headers, pos)) {
                                u_header =
				  (osip_uri_header_t *) osip_list_get(&from->url->
								      url_headers, pos);
                                osip_list_remove(&from->url->url_headers, pos);
                                osip_uri_header_free(u_header);
      }

      i = osip_from_to_str(from, &chvalue);
      osip_from_free(from);
    }
  } else if (osip_strcasecmp(chname, "to") == 0) {
    osip_from_t *to;
    int i = osip_to_clone(_evt->response->to, &to);

    if (i == 0) {
      int pos = 0;
      osip_uri_header_t *u_header;
      osip_uri_param_t *u_param;

      while (!osip_list_eol(&to->gen_params, 0)) {
                                u_param =
				  (osip_uri_param_t *) osip_list_get(&to->gen_params, 0);
                                osip_list_remove(&to->gen_params, 0);
                                osip_uri_param_free(u_param);
      }
      while (!osip_list_eol(&to->url->url_params, 0)) {
                                u_param =
				  (osip_uri_param_t *) osip_list_get(&to->url->
								     url_params, 0);
                                osip_list_remove(&to->url->url_params, 0);
                                osip_uri_param_free(u_param);
      }
      while (!osip_list_eol(&to->url->url_headers, pos)) {
                                u_header =
				  (osip_uri_header_t *) osip_list_get(&to->url->
								      url_headers, pos);
                                osip_list_remove(&to->url->url_headers, pos);
                                osip_uri_header_free(u_header);
      }

      i = osip_to_to_str(to, &chvalue);
      osip_to_free(to);
    }
  } else if (osip_strcasecmp(chname, "call-id") == 0) {
    osip_call_id_to_str(_evt->response->call_id, &chvalue);    
  } else if (osip_strcasecmp(chname, "cseq") == 0) {
    osip_cseq_to_str(_evt->response->cseq, &chvalue);
  } else if (osip_strcasecmp(chname, "via") == 0) {
    osip_via_t *via;
    via = (osip_via_t *) osip_list_get(&_evt->response->vias, n);
    if (via!=NULL)
      {
	osip_via_to_str(via, &chvalue);
      }
  } else if (osip_strcasecmp(chname, "contact") == 0) {
    osip_contact_t *co;
    co = (osip_contact_t *) osip_list_get(&_evt->response->contacts, n);
    if (co!=NULL)
      {
	osip_contact_to_str(co, &chvalue);
      }
  } else if (osip_strcasecmp(chname, "route") == 0) {
    osip_route_t *ro;
    ro = (osip_route_t *) osip_list_get(&_evt->response->routes, n);
    if (ro!=NULL)
      {
	osip_contact_to_str(ro, &chvalue);
      }
  } else if (osip_strcasecmp(chname, "content-type") == 0) {
    osip_content_type_to_str(_evt->response->content_type, &chvalue);
  } else {
    osip_header_t *_header=NULL;
    osip_message_header_get_byname(_evt->response, chname, n,
				   &_header);
    if (_header!=NULL)
      {
	osip_header_to_str(_header, &chvalue);
      }
  }


  (*env)->ReleaseStringUTFChars(env, hname, chname);

  if (chvalue==NULL)
    return NULL;

  hvalue = (*env)->NewStringUTF(env, chvalue);
  osip_free(chvalue);

  return hvalue;
}

JNIEXPORT static void
Java_amsip_ameventrelease( JNIEnv* env, jobject thiz,
					jlong evt)
{
  am_event_release((eXosip_event_t *)evt);
  osip_free((eXosip_event_t *)evt);
}

JNIEXPORT static jstring
Java_amsip_amurigetusername(JNIEnv* env, jobject thiz,
						       jstring uri_string)
{
  jboolean iscopy;
  const char *uri_str;
  jstring val;
  osip_to_t *uri;
  int i;

  uri_str = (*env)->GetStringUTFChars(env, 
	  uri_string, &iscopy);

  osip_to_init(&uri);
  i = osip_to_parse(uri, uri_str);
  (*env)->ReleaseStringUTFChars(env, uri_string, uri_str);
      
  if (i!=0 || uri==NULL || uri->url==NULL || uri->url->username==NULL)
    {

      osip_to_free(uri);
      return NULL;
    }

  val = (*env)->NewStringUTF(env, uri->url->username);
  osip_to_free(uri);

  return val;
}

JNIEXPORT static jstring
Java_amsip_amurigetdomain(JNIEnv* env, jobject thiz,
						       jstring uri_string)
{
  jboolean iscopy;
  const char *uri_str;
  jstring val;
  osip_to_t *uri;
  int i;

  uri_str = (*env)->GetStringUTFChars(env, 
	  uri_string, &iscopy);

  osip_to_init(&uri);
  i = osip_to_parse(uri, uri_str);
  (*env)->ReleaseStringUTFChars(env, uri_string, uri_str);
      
  if (i!=0 || uri==NULL || uri->url==NULL || uri->url->host==NULL)
    {

      osip_to_free(uri);
      return NULL;
    }

  val = (*env)->NewStringUTF(env, uri->url->host);
  osip_to_free(uri);

  return val;
}

JNIEXPORT static jstring
Java_amsip_amurigetdisplayname(JNIEnv* env, jobject thiz,
						       jstring uri_string)
{
  jboolean iscopy;
  const char *uri_str;
  jstring val;
  osip_to_t *uri;
  int i;

  uri_str = (*env)->GetStringUTFChars(env, 
	  uri_string, &iscopy);

  osip_to_init(&uri);
  i = osip_to_parse(uri, uri_str);
  (*env)->ReleaseStringUTFChars(env, uri_string, uri_str);
      
  if (i!=0 || uri==NULL || uri->displayname==NULL)
    {

      osip_to_free(uri);
      return NULL;
    }

  val = (*env)->NewStringUTF(env, uri->displayname);
  osip_to_free(uri);

  return val;
}

JNIEXPORT static jbyteArray
Java_amsip_ameventgetrequestbody( JNIEnv* env, jobject thiz,
				  jlong evt, int n)
{
  eXosip_event_t *_evt = (eXosip_event_t *)evt;
  jbyteArray val;
  am_bodyinfo_t binfo;
  int i;

  if (_evt->request==NULL)
    return NULL;

  memset (&binfo, 0, sizeof (am_bodyinfo_t));
  i = am_message_get_bodyinfo (_evt->request, n, &binfo);
  if (i < 0) {
    return NULL;
  }
  val = (*env)->NewByteArray(env, binfo.content_length);
  (*env)->SetByteArrayRegion(env, val, 0, binfo.content_length, (jbyte*) binfo.attachment);

  am_message_release_bodyinfo (&binfo);

  return val;
}

JNIEXPORT static jint
Java_amsip_amnetworkguessip( JNIEnv* env, jobject thiz,
					jint family, jstring address, jint size)
{
  return -1;
}

JNIEXPORT static jstring
Java_amsip_amnetworkgetnatinfo(JNIEnv* env, jobject thiz,
			       jstring stunserver, jint stun_port)
{
  jboolean iscopy;
  const char *stunserver_str;
  jstring val;
  char *info;
  int i;

  stunserver_str = (*env)->GetStringUTFChars(env, 
	  stunserver, &iscopy);

  info = am_network_get_nat_info(stunserver_str, stun_port);

  (*env)->ReleaseStringUTFChars(env, stunserver, stunserver_str);
      
  if (info==NULL || info[0]=='\0')
    {
      return NULL;
    }

  val = (*env)->NewStringUTF(env, info);

  return val;
}

JNIEXPORT static jint
Java_amsip_amnetworkmasquerade( JNIEnv* env, jobject thiz,
					jstring ip, jint port)
{
  jboolean iscopy;
  int i;
  const char *cstr = (*env)->GetStringUTFChars(env, 
	  ip, &iscopy);
  i =am_network_masquerade(cstr, port);
  (*env)->ReleaseStringUTFChars(env, ip, cstr);
  return i;
}

JNIEXPORT static jint
Java_amsip_amoptionsettlscertificate( JNIEnv* env, jobject thiz,
				      jstring certificate, jstring priv_key, jstring root_ca)
{
  jboolean iscopy;
  int i;
  const char *cstr_cert = (*env)->GetStringUTFChars(env, 
	  certificate, &iscopy);
  const char *cstr_key = (*env)->GetStringUTFChars(env, 
	  priv_key, &iscopy);
  const char *cstr_root_ca = (*env)->GetStringUTFChars(env, 
	  root_ca, &iscopy);

  am_tls_ctx_t tls_ctx;
  i=1;

  am_option_set_option(AMSIP_OPTION_TLS_CHECK_CERTIFICATE, &i);
  memset(&tls_ctx, 0, sizeof(am_tls_ctx_t));
  snprintf (tls_ctx.client.cert, sizeof(tls_ctx.client.cert), "%s", cstr_cert);
  snprintf (tls_ctx.client.priv_key, sizeof(tls_ctx.client.priv_key), "%s", cstr_key);
  snprintf (tls_ctx.root_ca_cert, sizeof(tls_ctx.root_ca_cert), "%s", cstr_root_ca);

  i = am_option_set_option(AMSIP_OPTION_TLS_SET_CERTIFICATES, &tls_ctx);

  (*env)->ReleaseStringUTFChars(env, certificate, cstr_cert);
  (*env)->ReleaseStringUTFChars(env, priv_key, cstr_key);
  (*env)->ReleaseStringUTFChars(env, root_ca, cstr_root_ca);
  return i;
}

JNIEXPORT static jint
Java_amsip_amnetworkstart( JNIEnv* env, jobject thiz,
					jstring transport, jint port)
{
  jboolean iscopy;
  int i;
  const char *cstr = (*env)->GetStringUTFChars(env, 
	  transport, &iscopy);
  i =am_network_start(cstr, port);
  (*env)->ReleaseStringUTFChars(env, transport, cstr);
  return i;
}

JNIEXPORT static jint
Java_amsip_amregisterstart( JNIEnv* env, jobject thiz,
						       jstring identity, jstring proxy,
						       jstring outboundproxy, int expires)
{
  jboolean iscopy;
  int i;
  const char *cstr_identity = (*env)->GetStringUTFChars(env, 
	  identity, &iscopy);
  const char *cstr_proxy = (*env)->GetStringUTFChars(env, 
	  proxy, &iscopy);
  const char *cstr_outboundproxy=NULL;

  if (outboundproxy!=NULL)
      cstr_outboundproxy = (*env)->GetStringUTFChars(env, outboundproxy, &iscopy);

  i =am_register_start(cstr_identity, cstr_proxy, cstr_outboundproxy, expires);

  (*env)->ReleaseStringUTFChars(env, identity, cstr_identity);
  (*env)->ReleaseStringUTFChars(env, proxy, cstr_proxy);
  if (outboundproxy!=NULL)
    (*env)->ReleaseStringUTFChars(env, outboundproxy, cstr_outboundproxy);
  return i;
}

JNIEXPORT static jint
Java_amsip_amregisterrefresh( JNIEnv* env, jobject thiz,
				       int rid, int expires)
{
  return am_register_refresh(rid, expires);
}

JNIEXPORT static jint
Java_amsip_amregisterstop( JNIEnv* env, jobject thiz,
					jint rid)
{
  int i;
  i =am_register_stop(rid);
  return i;
}

JNIEXPORT static jint
Java_amsip_amsessionstart( JNIEnv* env, jobject thiz,
					jstring identity, jstring target, jstring proxy, jstring outboundproxy)
{
  enum am_media_type media_table[3] = { AMSIP_MEDIA_AUDIO, AMSIP_MEDIA_NONE };
  jboolean iscopy;
  int i;
  const char *cstr_identity = (*env)->GetStringUTFChars(env, 
	  identity, &iscopy);
  const char *cstr_target= (*env)->GetStringUTFChars(env, 
	  target, &iscopy);
  const char *cstr_proxy = (*env)->GetStringUTFChars(env, 
	  proxy, &iscopy);
  const char *cstr_outboundproxy=NULL;
  if (outboundproxy!=NULL)
    cstr_outboundproxy = (*env)->GetStringUTFChars(env, outboundproxy, &iscopy);

  i =am_session_start_media(cstr_identity, cstr_target, cstr_proxy, cstr_outboundproxy, media_table);
  (*env)->ReleaseStringUTFChars(env, identity, cstr_identity);
  (*env)->ReleaseStringUTFChars(env, target, cstr_target);
  (*env)->ReleaseStringUTFChars(env, proxy, cstr_proxy);
  if (outboundproxy!=NULL)
    (*env)->ReleaseStringUTFChars(env, outboundproxy, cstr_outboundproxy);
  return i;
}

#ifdef ENABLE_VIDEO

JNIEXPORT static jint
Java_amsip_amsessionstartwithvideo( JNIEnv* env, jobject thiz,
					jstring identity, jstring target, jstring proxy, jstring outboundproxy)
{
  jboolean iscopy;
  int i;
  enum am_media_type media_table[3] = { AMSIP_MEDIA_AUDIO, AMSIP_MEDIA_VIDEO, AMSIP_MEDIA_NONE };
  const char *cstr_identity = (*env)->GetStringUTFChars(env, 
	  identity, &iscopy);
  const char *cstr_target= (*env)->GetStringUTFChars(env, 
	  target, &iscopy);
  const char *cstr_proxy = (*env)->GetStringUTFChars(env, 
	  proxy, &iscopy);
  const char *cstr_outboundproxy=NULL;
  if (outboundproxy!=NULL)
    cstr_outboundproxy = (*env)->GetStringUTFChars(env, outboundproxy, &iscopy);

  i =am_session_start_media(cstr_identity, cstr_target, cstr_proxy, cstr_outboundproxy, media_table);
  (*env)->ReleaseStringUTFChars(env, identity, cstr_identity);
  (*env)->ReleaseStringUTFChars(env, target, cstr_target);
  (*env)->ReleaseStringUTFChars(env, proxy, cstr_proxy);
  if (outboundproxy!=NULL)
    (*env)->ReleaseStringUTFChars(env, outboundproxy, cstr_outboundproxy);
  return i;
}

JNIEXPORT static jint
Java_amsip_amsessionaddvideo( JNIEnv* env, jobject thiz,
					      jint did)
{
  return am_session_add_video(did);
}

JNIEXPORT static jint
Java_amsip_amsessionstopvideo( JNIEnv* env, jobject thiz,
					      jint did)
{
  return am_session_stop_video(did);
}

JNIEXPORT static jint
Java_amsip_amsessionadaptvideobitrate( JNIEnv* env, jobject thiz,
				       jint did, jint percent)
{
  return am_session_adapt_video_bitrate (did, percent);
}

#else

JNIEXPORT static jint
Java_amsip_amsessionstartwithvideo( JNIEnv* env, jobject thiz,
					jstring identity, jstring target, jstring proxy, jstring outboundproxy)
{
  return -1;
}

JNIEXPORT static jint
Java_amsip_amsessionaddvideo( JNIEnv* env, jobject thiz,
					      jint did)
{
  return -1;
}

JNIEXPORT static jint
Java_amsip_amsessionstopvideo( JNIEnv* env, jobject thiz,
					      jint did)
{
  return -1;
}

JNIEXPORT static jint
Java_amsip_amsessionadaptvideobitrate( JNIEnv* env, jobject thiz,
				       jint did, jint percent)
{
  return -1;
}

#endif

JNIEXPORT static jint
Java_amsip_ammessagegetrequestaudiortpdirection( JNIEnv* env, jobject thiz,
								     jlong evt)
{
  eXosip_event_t *_evt = (eXosip_event_t *)evt;
  return am_message_get_audio_rtpdirection(_evt->request);
}

JNIEXPORT static jint
Java_amsip_ammessagegetrequestvideortpdirection( JNIEnv* env, jobject thiz,
								     jlong evt)
{
  eXosip_event_t *_evt = (eXosip_event_t *)evt;
  return am_message_get_video_rtpdirection(_evt->request);
}

JNIEXPORT static jint
Java_amsip_ammessagegetresponsevideortpdirection( JNIEnv* env, jobject thiz,
								     jlong evt)
{
  eXosip_event_t *_evt = (eXosip_event_t *)evt;
  if (_evt->response==NULL)
    return -1;
  return am_message_get_video_rtpdirection(_evt->response);
}

JNIEXPORT static jint
Java_amsip_amsessionstop( JNIEnv* env, jobject thiz,
					      jint cid, jint did, jint code)
{
	return am_session_stop(cid, did, code);
}

JNIEXPORT static jint
Java_amsip_amsessionanswer( JNIEnv* env, jobject thiz,
						   jint tid, jint did, jint code, jint enable_audio)
{
  return am_session_answer(tid, did, code, enable_audio);
}

JNIEXPORT static jint
Java_amsip_amsessionhold( JNIEnv* env, jobject thiz,
						 jint did, jstring holdmusic)
{
  jboolean iscopy;
  int i;
  const char *cstr_holdmusic = (*env)->GetStringUTFChars(env, 
	  holdmusic, &iscopy);
  i =am_session_hold(did, cstr_holdmusic);
  (*env)->ReleaseStringUTFChars(env, holdmusic, cstr_holdmusic);
  return i;

}

JNIEXPORT static jint
Java_amsip_amsessionoffhold( JNIEnv* env, jobject thiz,
						   jint did)
{
  return am_session_off_hold(did);
}

JNIEXPORT static jint
Java_amsip_amsessionmute( JNIEnv* env, jobject thiz,
						   jint did)
{
  return am_session_mute(did);
}

JNIEXPORT static jint
Java_amsip_amsessionunmute( JNIEnv* env, jobject thiz,
						   jint did)
{
  return am_session_unmute(did);
}

static jint Java_am_session_refer(JNIEnv* env, jobject thiz, jint did, jstring url, jstring referred_by)
{
  jboolean iscopy;
  const char *cstr_url;
  const char *cstr_referred_by;
  int i;
 
  if (url==NULL)
    return -1;
 
  if (referred_by==NULL)
    return -1;
 
  cstr_url = (*env)->GetStringUTFChars(env, url, &iscopy);
  cstr_referred_by = (*env)->GetStringUTFChars(env, referred_by, &iscopy);
 
  am_session_refer(did, cstr_url, cstr_referred_by);
  (*env)->ReleaseStringUTFChars(env, url, cstr_url);
  (*env)->ReleaseStringUTFChars(env, referred_by, cstr_referred_by);
 
  return i;
}

static int update_band_stats=0;
static struct am_bandwidth_stats band_stats;

JNIEXPORT static jfloat
Java_amsip_amsessiongetaudiouploadbandwidth(JNIEnv* env, jobject thiz,
			   jint did)
{
  int i;
  if (update_band_stats==0 || update_band_stats==1)
  {
    memset(&band_stats, 0, sizeof(band_stats));
    i = am_session_get_audio_bandwidth(did, &band_stats);
    if (i>=0)
      {	
	update_band_stats=1;
	return band_stats.upload_rate*1e-3;
      }
    return -1;
  }
  return band_stats.upload_rate*1e-3;
}

JNIEXPORT static jfloat
Java_amsip_amsessiongetaudiodownloadbandwidth(JNIEnv* env, jobject thiz,
			   jint did)
{
  int i;
  if (update_band_stats==0 || update_band_stats==2)
  {
    memset(&band_stats, 0, sizeof(band_stats));
    i = am_session_get_audio_bandwidth(did, &band_stats);
    if (i>=0)
      {
	update_band_stats=2;
	return band_stats.download_rate*1e-3;
      }
    return -1;
  }
  return band_stats.download_rate*1e-3;
}

JNIEXPORT static jfloat
Java_amsip_amsessiongetaudiopacketloss(JNIEnv* env, jobject thiz,
			   jint did)
{
  int i;
  if (update_band_stats==0 || update_band_stats==3)
  {
    memset(&band_stats, 0, sizeof(band_stats));
    i = am_session_get_audio_bandwidth(did, &band_stats);
    if (i>=0)
      {
	update_band_stats=3;
	if (band_stats.incoming_received>0)
	  return 100 - (((float)(band_stats.incoming_received * 100))
			/(float)(band_stats.incoming_received + band_stats.incoming_packetloss));
	return 0;
      }
    return -1;
  }
  if (band_stats.incoming_received>0)
    return 100 - (((float)(band_stats.incoming_received * 100))
		  /(float)(band_stats.incoming_received + band_stats.incoming_packetloss));
  return 0;

}

static float rtcp_stream_process(mblk_t *m){
  do{
    if (rtcp_is_APP(m)){
      ms_message("RTCP APP received");
    } else if (rtcp_is_BYE(m)){
      ms_message("RTCP BYE received");
    } else if (rtcp_is_SDES(m)){
      ms_message("RTCP SDES received");
    } else if (rtcp_is_SR(m)){
      const report_block_t *rb;
      rb=rtcp_SR_get_report_block(m,0);
      if (rb){
	unsigned int ij;
	float flost;
	ij=report_block_get_interarrival_jitter(rb);
	flost=(float)(100.0*report_block_get_fraction_lost(rb)/256.0);
	ms_message("RTCP SR: remote stat: interarrival jitter=%u , lost packets percentage since last report=%f ",ij,flost);
	return flost;
      }
    }
  }while(rtcp_next_packet(m));
  return -1;
}

JNIEXPORT static jfloat
Java_amsip_amsessiongetaudioremotepacketloss(JNIEnv* env, jobject thiz,
			   jint did)
{
  OrtpEvent *ev=am_session_get_audio_rtp_events(did);
  while (ev!=NULL){
    float flost=-1;
    if (ortp_event_get_type(ev)==ORTP_EVENT_ZRTP_SAS){
      OrtpEventData *evd=ortp_event_get_data(ev);

    } else if (ortp_event_get_type(ev)==ORTP_EVENT_RTCP_PACKET_RECEIVED){
      OrtpEventData *evd=ortp_event_get_data(ev);
      flost = rtcp_stream_process(evd->packet);
    }
    ortp_event_destroy(ev);
    if (flost>=0)
      return flost;
    ev=am_session_get_audio_rtp_events(did);
  }
  return -2;
}

static int update_video_band_stats=0;
static struct am_bandwidth_stats video_band_stats;

JNIEXPORT static jfloat
Java_amsip_amsessiongetvideouploadbandwidth(JNIEnv* env, jobject thiz,
			   jint did)
{
  int i;
  if (update_video_band_stats==0 || update_video_band_stats==1)
  {
    memset(&video_band_stats, 0, sizeof(video_band_stats));
    i = am_session_get_video_bandwidth(did, &video_band_stats);
    if (i>=0)
      {	
	update_video_band_stats=1;
	return video_band_stats.upload_rate*1e-3;
      }
    return -1;
  }
  return video_band_stats.upload_rate*1e-3;
}

JNIEXPORT static jfloat
Java_amsip_amsessiongetvideodownloadbandwidth(JNIEnv* env, jobject thiz,
			   jint did)
{
  int i;
  if (update_video_band_stats==0 || update_video_band_stats==2)
  {
    memset(&video_band_stats, 0, sizeof(video_band_stats));
    i = am_session_get_video_bandwidth(did, &video_band_stats);
    if (i>=0)
      {
	update_video_band_stats=2;
	return video_band_stats.download_rate*1e-3;
      }
    return -1;
  }
  return video_band_stats.download_rate*1e-3;
}

JNIEXPORT static jfloat
Java_amsip_amsessiongetvideopacketloss(JNIEnv* env, jobject thiz,
			   jint did)
{
  int i;
  if (update_video_band_stats==0 || update_video_band_stats==3)
  {
    memset(&video_band_stats, 0, sizeof(video_band_stats));
    i = am_session_get_video_bandwidth(did, &video_band_stats);
    if (i>=0)
      {
	update_video_band_stats=3;
	if (video_band_stats.incoming_received>0)
	  return 100 - (((float)(video_band_stats.incoming_received * 100))
			/(float)(video_band_stats.incoming_received + video_band_stats.incoming_packetloss));
	return 0;
      }
    return -1;
  }
  if (video_band_stats.incoming_received>0)
    return 100 - (((float)(video_band_stats.incoming_received * 100))
		  /(float)(video_band_stats.incoming_received + video_band_stats.incoming_packetloss));
  return 0;

}

JNIEXPORT static jfloat
Java_amsip_amsessiongetvideoremotepacketloss(JNIEnv* env, jobject thiz,
			   jint did)
{
  OrtpEvent *ev=am_session_get_video_rtp_events(did);
  while (ev!=NULL){
    float flost=-1;
    if (ortp_event_get_type(ev)==ORTP_EVENT_ZRTP_SAS){
      OrtpEventData *evd=ortp_event_get_data(ev);

    } else if (ortp_event_get_type(ev)==ORTP_EVENT_RTCP_PACKET_RECEIVED){
      OrtpEventData *evd=ortp_event_get_data(ev);
      flost = rtcp_stream_process(evd->packet);
    }
    ortp_event_destroy(ev);
    if (flost>=0)
      return flost;
    ev=am_session_get_video_rtp_events(did);
  }
  return -2;
}

JNIEXPORT static jint
Java_amsip_amsessionanswerrequest( JNIEnv* env, jobject thiz,
						   jint tid, jint did, jint code)
{
  return am_session_answer_request(tid, did, code);
}

JNIEXPORT static jint
Java_amsip_amsessionsenddtmfwithduration(JNIEnv* env, jobject thiz,
							     jint did, jstring dtmf_number, jint duration)
{
  jboolean iscopy;
  const char *cstr = (*env)->GetStringUTFChars(env,
					       dtmf_number, &iscopy);
  int i = am_session_send_dtmf_with_duration(did, cstr[0], duration);
  (*env)->ReleaseStringUTFChars(env, dtmf_number, cstr);
  return i;
}

JNIEXPORT static jint
Java_amsip_amsessionsendinbanddtmf(JNIEnv* env, jobject thiz,
                                                             jint did, jstring dtmf_number)
{
  jboolean iscopy;
  const char *cstr = (*env)->GetStringUTFChars(env,
                                               dtmf_number, &iscopy);
  int i = am_session_send_inband_dtmf(did, cstr[0]);
  (*env)->ReleaseStringUTFChars(env, dtmf_number, cstr);
  return i;
}

JNIEXPORT static jint
Java_amsip_amsessionsendrtpdtmf(JNIEnv* env, jobject thiz,
							   jint did, jstring dtmf_number)
{
  jboolean iscopy;
  const char *cstr = (*env)->GetStringUTFChars(env,
                                               dtmf_number, &iscopy);
  int i = am_session_send_rtp_dtmf(did, cstr[0]);
  (*env)->ReleaseStringUTFChars(env, dtmf_number, cstr);
  return i;
}

JNIEXPORT static int
Java_amsip_amexecuteuri(JNIEnv* env, jobject thiz,
					  jstring identity, jstring target,
					  jstring proxy, jstring outboundproxy,
					  jstring body)
{
  jboolean iscopy;
  int i;
  const char *cstr_identity = (*env)->GetStringUTFChars(env, identity, &iscopy);
  const char *cstr_target= (*env)->GetStringUTFChars(env, target, &iscopy);
  const char *cstr_proxy = (*env)->GetStringUTFChars(env, proxy, &iscopy);
  const char *cstr_outboundproxy=NULL;
  const char *cstr_body=NULL;
  osip_message_t *message=NULL;

  if (body!=NULL)
    cstr_body = (*env)->GetStringUTFChars(env, body, &iscopy);

  if (outboundproxy!=NULL)
    cstr_outboundproxy = (*env)->GetStringUTFChars(env, outboundproxy, &iscopy);

  i =am_message_execute_uri(&message, cstr_identity, cstr_target, cstr_proxy, cstr_outboundproxy, cstr_body);
  if (i>=0 && message!=NULL)
    {
      i = ams_message_send(message);
    }
  (*env)->ReleaseStringUTFChars(env, identity, cstr_identity);
  (*env)->ReleaseStringUTFChars(env, target, cstr_target);
  (*env)->ReleaseStringUTFChars(env, proxy, cstr_proxy);
  if (outboundproxy!=NULL)
    (*env)->ReleaseStringUTFChars(env, outboundproxy, cstr_outboundproxy);
  if (body!=NULL)
    (*env)->ReleaseStringUTFChars(env, body, cstr_body);
  return i;  
}

JNIEXPORT static int
Java_amsip_ammessagesend(JNIEnv* env, jobject thiz,
					  jstring identity, jstring target,
					  jstring proxy, jstring outboundproxy,
					  jstring body)
{
  jboolean iscopy;
  int i;
  const char *cstr_identity = (*env)->GetStringUTFChars(env, identity, &iscopy);
  const char *cstr_target= (*env)->GetStringUTFChars(env, target, &iscopy);
  const char *cstr_proxy = (*env)->GetStringUTFChars(env, proxy, &iscopy);
  const char *cstr_outboundproxy=NULL;
  const char *cstr_body=NULL;

  if (body!=NULL)
    cstr_body = (*env)->GetStringUTFChars(env, body, &iscopy);

  if (outboundproxy!=NULL)
    cstr_outboundproxy = (*env)->GetStringUTFChars(env, outboundproxy, &iscopy);

  i =am_message_send(cstr_identity, cstr_target, cstr_proxy, cstr_outboundproxy, cstr_body);

  (*env)->ReleaseStringUTFChars(env, identity, cstr_identity);
  (*env)->ReleaseStringUTFChars(env, target, cstr_target);
  (*env)->ReleaseStringUTFChars(env, proxy, cstr_proxy);
  if (outboundproxy!=NULL)
    (*env)->ReleaseStringUTFChars(env, outboundproxy, cstr_outboundproxy);
  if (body!=NULL)
    (*env)->ReleaseStringUTFChars(env, body, cstr_body);
  return i;  
}


JNIEXPORT static jint
Java_amsip_ammessageanswer( JNIEnv* env, jobject thiz,
						   jint tid, jint code)
{
  return am_message_answer(tid, code);
}

#include <android/bitmap.h>

ms_mutex_t vd_mutex;
jobject mAndroidBitmap=0;
AndroidBitmapInfo info;
jobject gVideoDisplay = 0;
jclass videodisplay_myclz = 0;
jmethodID videodisplay_lockIncomingImage = 0;
jmethodID videodisplay_unlockIncomingImage = 0;

JNIEXPORT static jint
Java_amsip_setvideodisplay( JNIEnv* env, jobject thiz,
						  jobject lVideoDisplay)
{
  ms_mutex_lock(&vd_mutex);
  memset(&info, 0, sizeof(AndroidBitmapInfo));
  if (gVideoDisplay!=0)
    {
      (*env)->DeleteGlobalRef(env, gVideoDisplay);
    }
  gVideoDisplay=0;
  if (lVideoDisplay!=0)
    gVideoDisplay = (*env)->NewGlobalRef(env, lVideoDisplay);
  
  if (mAndroidBitmap!=0)
    {
      (*env)->DeleteGlobalRef(env, mAndroidBitmap);
    }
  mAndroidBitmap=0;

  ms_mutex_unlock(&vd_mutex);
  return 0;
}

#include "mediastreamer2/mssndcard.h"

JavaVM *jvm = NULL;
jclass audioinput_myclz = 0;
jmethodID audioinput_cons = 0;
jmethodID audioinput_cons_read_bytes = 0;
jmethodID audioinput_cons_halt = 0;

jclass audiooutput_myclz = 0;
jmethodID audiooutput_cons = 0;
jmethodID audiooutput_cons_write_bytes = 0;
jmethodID audiooutput_cons_halt = 0;

#ifdef ENABLE_VIDEO
extern jclass H264MediaCodecEncoder_myclz;
extern jclass H264MediaCodecDecoder_myclz;
#endif

extern MSFilterDesc androidsnd_read_desc;
extern MSFilterDesc androidsnd_write_desc;
extern MSSndCardDesc androidsnd_card_desc;

JNIEXPORT static void Java_amsip_registeraudio(JNIEnv* env, jobject thiz){
	MSSndCardManager *cm;

	if (jvm == NULL) return;

	ms_filter_register(&androidsnd_read_desc);
	ms_filter_register(&androidsnd_write_desc);

	cm=ms_snd_card_manager_get();
	ms_snd_card_manager_register_desc(cm,&androidsnd_card_desc);

}

JNIEXPORT static jint Java_amsip_registermsh264mediaencoder( JNIEnv* env, jobject thiz, jint version_sdk)
{
#ifdef ENABLE_VIDEO
  if (version_sdk>=16 && H264MediaCodecEncoder_myclz!=0) {
    static int done=0;
    if (done==0) /* do this only one */    
      libmsandroidmediacodecenc_init();
    done++;
    return 0;
  }
#endif

  return -1;
}

JNIEXPORT static jint Java_amsip_registermsh264mediadecoder( JNIEnv* env, jobject thiz, jint version_sdk)
{
#ifdef ENABLE_VIDEO
  if (version_sdk>=16 && H264MediaCodecDecoder_myclz!=0) {
    static int done=0;
    if (done==0) /* do this only one */    
      libmsandroidmediacodecdec_init();
    done++;
    return 0;
  }
#endif

  return -1;
}

JNIEXPORT static jint Java_amsip_amoptionenablefilter( JNIEnv* env, jobject thiz, jstring filter_name)
{
  jboolean iscopy;
  int i;
  const char *cstr_filter_name;

  if (filter_name==NULL)
    return -1;

  cstr_filter_name = (*env)->GetStringUTFChars(env, filter_name, &iscopy);

  i = am_option_set_option(AMSIP_OPTION_ENABLE_FILTER, (void*)cstr_filter_name);

  (*env)->ReleaseStringUTFChars(env, filter_name, cstr_filter_name);
  return i;
}

JNIEXPORT static jint Java_amsip_amoptiondisablefilter( JNIEnv* env, jobject thiz, jstring filter_name)
{
  jboolean iscopy;
  int i;
  const char *cstr_filter_name;

  if (filter_name==NULL)
    return -1;

  cstr_filter_name = (*env)->GetStringUTFChars(env, filter_name, &iscopy);

  i = am_option_set_option(AMSIP_OPTION_DISABLE_FILTER, (void*)cstr_filter_name);

  (*env)->ReleaseStringUTFChars(env, filter_name, cstr_filter_name);
  return i;  
}

static const JNINativeMethod methods[] = {
  {"aminit",  "(I)I", (void*)Java_amsip_aminit},
  {"amreset",  "(I)I", (void*)Java_amsip_amreset},
  {"amquit",  "()I", (void*)Java_amsip_amquit},
  {"amcodecinfomodify",  "(IILjava/lang/String;III)I", (void*)Java_amsip_amcodecinfomodify},
  {"amvideocodecinfomodify",  "(IILjava/lang/String;III)I", (void*)Java_amsip_amvideocodecinfomodify},
  {"amvideocodecattrmodify",  "(II)I", (void*)Java_amsip_amvideocodecattrmodify},
  {"amcodecattrmodify",  "(II)I", (void*)Java_amsip_amcodecattrmodify},
  {"amoptiongetversion",  "()Ljava/lang/String;", (void*)Java_amsip_amoptiongetversion},
  {"amoptionsetuseragent",  "(Ljava/lang/String;)I", (void*)Java_amsip_amoptionsetuseragent},
  {"amoptionsetinitialaudioport",  "(I)I", (void*)Java_amsip_amoptionsetinitialaudioport},
  {"amoptionenablestunserver",  "(Ljava/lang/String;I)I", (void*)Java_amsip_amoptionenablestunserver},
  {"amoptionenableturnserver",  "(Ljava/lang/String;I)I", (void*)Java_amsip_amoptionenableturnserver},
  {"amoptionsetipv4forgateway",  "(Ljava/lang/String;)I", (void*)Java_amsip_amoptionsetipv4forgateway},
  {"amoptionenablerport",  "(I)I", (void*)Java_amsip_amoptionenablerport},
  {"amoptionsetdnscapabilities",  "(I)I", (void*)Java_amsip_amoptionsetdnscapabilities},
  {"amoptionenablekeepalive",  "(I)I", (void*)Java_amsip_amoptionenablekeepalive},
  {"amoptionsetaudioprofile",  "(Ljava/lang/String;)I", (void*)Java_amsip_amoptionsetaudioprofile},
  {"amoptionsetvideoprofile",  "(Ljava/lang/String;)I", (void*)Java_amsip_amoptionsetvideoprofile},
  {"amoptionsettextprofile",  "(Ljava/lang/String;)I", (void*)Java_amsip_amoptionsettextprofile},
  {"amoptionsetudpftpprofile",  "(Ljava/lang/String;)I", (void*)Java_amsip_amoptionsetudpftpprofile},
  {"amoptionenablesessiontimers",  "(I)I", (void*)Java_amsip_amoptionenablesessiontimers},

  {"amoptionenablesymmetricrtp",  "(I)I", (void*)Java_amsip_amoptionenablesymmetricrtp},
  {"amoptionselectinsoundcard",  "(I)I", (void*)Java_amsip_amoptionselectinsoundcard},
  {"amoptionselectoutsoundcard",  "(I)I", (void*)Java_amsip_amoptionselectoutsoundcard},
  {"amoptionsetvolumeoutsoundcard",  "(III)I", (void*)Java_amsip_amoptionsetvolumeoutsoundcard},
  {"amoptiongetvolumeoutsoundcard",  "(II)I", (void*)Java_amsip_amoptiongetvolumeoutsoundcard},
  {"amoptionsetvolumeinsoundcard",  "(II)I", (void*)Java_amsip_amoptionsetvolumeinsoundcard},
  {"amoptiongetvolumeinsoundcard",  "(I)I", (void*)Java_amsip_amoptiongetvolumeinsoundcard},
  {"amoptionsetmuteoutsoundcard",  "(III)I", (void*)Java_amsip_amoptionsetmuteoutsoundcard},
  {"amoptionsetmuteinsoundcard",  "(II)I", (void*)Java_amsip_amoptionsetmuteinsoundcard},
  {"amoptionenablewebrtcapm",  "(IIIIIIIIIII)I", (void*)Java_amsip_amoptionenablewebrtcapm},
  {"amoptionenableechocanceller",  "(III)I", (void*)Java_amsip_amoptionenableechocanceller},
  {"amoptionenableagc",  "(III)I", (void*)Java_amsip_amoptionenableagc},
  {"amoptionsetjittermode", "(I)I", (void*)Java_amsip_amoptionsetjittermode},
  {"amoptionvideosetjittermode", "(I)I", (void*)Java_amsip_amoptionvideosetjittermode},
  {"amoptionsetpassword",  "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I", (void*)Java_amsip_amoptionsetpassword},
  {"amoptionloadplugins",  "(Ljava/lang/String;)I", (void*)Java_amsip_amoptionloadplugins},
  {"amoptionenableoptionnalencryption",  "(I)I", (void*)Java_amsip_amoptionenableoptionnalencryption},
  {"amoptionsetdscpvalue",  "(I)I", (void*)Java_amsip_amoptionsetdscpvalue},
  {"amoptionsetaudiodscp",  "(I)I", (void*)Java_amsip_amoptionsetaudiodscp},
  {"amoptionsetvideodscp",  "(I)I", (void*)Java_amsip_amoptionsetvideodscp},
  {"amoptionsettextdscp",  "(I)I", (void*)Java_amsip_amoptionsettextdscp},
  {"amoptionsetudpftpdscp",  "(I)I", (void*)Java_amsip_amoptionsetudpftpdscp},
  {"amoptionsetsupportedextensions",  "(Ljava/lang/String;)I", (void*)Java_amsip_amoptionsetsupportedextensions},
  {"amoptionsetacceptedtypes",  "(Ljava/lang/String;)I", (void*)Java_amsip_amoptionsetacceptedtypes},
  {"amoptionsetallowedmethods",  "(Ljava/lang/String;)I", (void*)Java_amsip_amoptionsetallowedmethods},
  {"amoptionsetrate",  "(I)I", (void*)Java_amsip_amoptionsetrate},
  {"amoptionsetvolumegain",  "(FF)I", (void*)Java_amsip_amoptionsetvolumegain},
  {"amoptionsetecholimitation",  "(IFFFI)I", (void*)Java_amsip_amoptionsetecholimitation},

  {"ameventget",  "()J", (void*)Java_amsip_ameventget},
  {"ameventwait",  "(II)J", (void*)Java_amsip_ameventwait},
  {"ameventgettype",  "(J)I", (void*)Java_amsip_ameventgettype},
  {"ameventgettid",  "(J)I", (void*)Java_amsip_ameventgettid},
  {"ameventgetcid",  "(J)I", (void*)Java_amsip_ameventgetcid},
  {"ameventgetdid",  "(J)I", (void*)Java_amsip_ameventgetdid},
  {"ameventgetrid",  "(J)I", (void*)Java_amsip_ameventgetrid},
  {"ameventgetnid",  "(J)I", (void*)Java_amsip_ameventgetnid},
  {"ameventgetsid",  "(J)I", (void*)Java_amsip_ameventgetsid},
  {"ameventgetmethod",  "(J)Ljava/lang/String;", (void*)Java_amsip_ameventgetmethod},
  {"ameventgetreason",  "(J)Ljava/lang/String;", (void*)Java_amsip_ameventgetreason},
  {"ameventgetstatuscode",  "(J)I", (void*)Java_amsip_ameventgetstatuscode},

  {"ameventgetrequestheader",  "(JLjava/lang/String;I)Ljava/lang/String;", (void*)Java_amsip_ameventgetrequestheader},
  {"ameventgetresponseheader",  "(JLjava/lang/String;I)Ljava/lang/String;", (void*)Java_amsip_ameventgetresponseheader},
  {"ameventrelease",  "(J)V", (void*)Java_amsip_ameventrelease},
  {"amurigetusername",  "(Ljava/lang/String;)Ljava/lang/String;", (void*)Java_amsip_amurigetusername},
  {"amurigetdomain",  "(Ljava/lang/String;)Ljava/lang/String;", (void*)Java_amsip_amurigetdomain},
  {"amurigetdisplayname",  "(Ljava/lang/String;)Ljava/lang/String;", (void*)Java_amsip_amurigetdisplayname},
  {"ameventgetrequestbody",  "(JI)[B", (void*)Java_amsip_ameventgetrequestbody},
  {"amnetworkmasquerade",  "(Ljava/lang/String;I)I", (void*)Java_amsip_amnetworkmasquerade},
  {"amnetworkgetnatinfo",  "(Ljava/lang/String;I)Ljava/lang/String;", (void*)Java_amsip_amnetworkgetnatinfo},
  {"amoptionsettlscertificate", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I", (void*)Java_amsip_amoptionsettlscertificate},
  {"amnetworkstart",  "(Ljava/lang/String;I)I", (void*)Java_amsip_amnetworkstart},
  {"amregisterstart",  "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)I", (void*)Java_amsip_amregisterstart},
  {"amregisterrefresh",  "(II)I", (void*)Java_amsip_amregisterrefresh},
  {"amregisterstop",  "(I)I", (void*)Java_amsip_amregisterstop},
  {"amsessionstart",  "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I", (void*)Java_amsip_amsessionstart},
  {"amsessionstartwithvideo",  "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I", (void*)Java_amsip_amsessionstartwithvideo},
  {"amsessionaddvideo",  "(I)I", (void*)Java_amsip_amsessionaddvideo},
  {"amsessionstopvideo",  "(I)I", (void*)Java_amsip_amsessionstopvideo},
  {"amsessionadaptvideobitrate", "(II)I", (void*)Java_amsip_amsessionadaptvideobitrate},
  {"ammessagegetrequestaudiortpdirection",  "(J)I", (void*)Java_amsip_ammessagegetrequestaudiortpdirection},
  {"ammessagegetrequestvideortpdirection",  "(J)I", (void*)Java_amsip_ammessagegetrequestvideortpdirection},
  {"ammessagegetresponsevideortpdirection",  "(J)I", (void*)Java_amsip_ammessagegetresponsevideortpdirection},
  {"amsessionstop",  "(III)I", (void*)Java_amsip_amsessionstop},
  {"amsessionanswer",  "(IIII)I", (void*)Java_amsip_amsessionanswer},

  {"amsessionhold",  "(ILjava/lang/String;)I", (void*)Java_amsip_amsessionhold},
  {"amsessionoffhold",  "(I)I", (void*)Java_amsip_amsessionoffhold},

  {"amsessionmute",  "(I)I", (void*)Java_amsip_amsessionmute},
  {"amsessionunmute",  "(I)I", (void*)Java_amsip_amsessionunmute},
  {"amsessionrefer",  "(ILjava/lang/String;Ljava/lang/String;)I", (void*)Java_am_session_refer},
  {"amsessiongetaudiouploadbandwidth",  "(I)F", (void*)Java_amsip_amsessiongetaudiouploadbandwidth},
  {"amsessiongetaudiodownloadbandwidth",  "(I)F", (void*)Java_amsip_amsessiongetaudiodownloadbandwidth},
  {"amsessiongetaudiopacketloss",  "(I)F", (void*)Java_amsip_amsessiongetaudiopacketloss},
  {"amsessiongetaudioremotepacketloss",  "(I)F", (void*)Java_amsip_amsessiongetaudioremotepacketloss},
  {"amsessiongetvideouploadbandwidth",  "(I)F", (void*)Java_amsip_amsessiongetvideouploadbandwidth},
  {"amsessiongetvideodownloadbandwidth",  "(I)F", (void*)Java_amsip_amsessiongetvideodownloadbandwidth},
  {"amsessiongetvideopacketloss",  "(I)F", (void*)Java_amsip_amsessiongetvideopacketloss},
  {"amsessiongetvideoremotepacketloss",  "(I)F", (void*)Java_amsip_amsessiongetvideoremotepacketloss},

  {"amsessionanswerrequest",  "(III)I", (void*)Java_amsip_amsessionanswerrequest},


  {"amsessionsenddtmfwithduration",  "(ILjava/lang/String;I)I", (void*)Java_amsip_amsessionsenddtmfwithduration},
  {"amsessionsendinbanddtmf",  "(ILjava/lang/String;)I", (void*)Java_amsip_amsessionsendinbanddtmf},
  {"amsessionsendrtpdtmf",  "(ILjava/lang/String;)I", (void*)Java_amsip_amsessionsendrtpdtmf},
  {"amexecuteuri",  "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I", (void*)Java_amsip_amexecuteuri},
  {"ammessagesend",  "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I", (void*)Java_amsip_ammessagesend},
  {"ammessageanswer",  "(II)I", (void*)Java_amsip_ammessageanswer},
  
  {"setvideodisplay",  "(Ljava/lang/Object;)I", (void*)Java_amsip_setvideodisplay},
  {"registeraudio",  "()V", (void*)Java_amsip_registeraudio},
  {"registermsh264mediaencoder",  "(I)I", (void*)Java_amsip_registermsh264mediaencoder},
  {"registermsh264mediadecoder",  "(I)I", (void*)Java_amsip_registermsh264mediadecoder},
  {"amoptionenablefilter",  "(Ljava/lang/String;)I", (void*)Java_amsip_amoptionenablefilter},
  {"amoptiondisablefilter",  "(Ljava/lang/String;)I", (void*)Java_amsip_amoptiondisablefilter},

};

static const char* const kClassPathName = "com/antisip/amsip/AmsipTask";

JNIEXPORT static int register_methods(JNIEnv* env)
{
  jclass clazz;

  clazz = (*env)->FindClass(env, kClassPathName);
  if (clazz == NULL) {
    printf("Native registration unable to find class '%s'\n", kClassPathName);
    return -1;
  }
  return (*env)->RegisterNatives(env, clazz, methods, sizeof(methods)/sizeof(JNINativeMethod));
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) { 
	JNIEnv* env; 
	JNINativeMethod meth; 
	jint ijvm; 
	ijvm = (*vm)->GetEnv(vm, (void**)&env, JNI_VERSION_1_4); 
	//printf("JNI_OnLoad: done!");

	register_methods(env);

	jvm = vm;
	//printf("JNI_OnLoad: done!");

#ifdef ENABLE_VIDEO
	H264MediaCodecEncoder_myclz = (*env)->NewGlobalRef(env, (*env)->FindClass(env, "com/antisip/amsip/H264MediaCodecEncoder"));
	if (H264MediaCodecEncoder_myclz==0)
	  printf("H264MediaCodecEncState: H264MediaCodecEncoder_myclz NOT loaded");
	else
	  printf("H264MediaCodecEncState: H264MediaCodecEncoder_myclz loaded");

	H264MediaCodecDecoder_myclz = (*env)->NewGlobalRef(env, (*env)->FindClass(env, "com/antisip/amsip/H264MediaCodecDecoder"));
	if (H264MediaCodecDecoder_myclz==0)
	  printf("H264MediaCodecDecState: H264MediaCodecDecoder_myclz NOT loaded");
	else
	  printf("H264MediaCodecDecState: H264MediaCodecDecoder_myclz loaded");
#endif


	audioinput_myclz = (*env)->NewGlobalRef(env, 
		(*env)->FindClass(env, "com/antisip/amsip/AudioInput")
	);

	audioinput_cons = (*env)->GetMethodID(env, audioinput_myclz, "<init>", 
										  "(I)V");
	audioinput_cons_read_bytes = (*env)->GetMethodID(env, audioinput_myclz, "read_bytes", 
									  "([BI)I");
	audioinput_cons_halt = (*env)->GetMethodID(env, audioinput_myclz, "stop", 
									  "()I");

	audiooutput_myclz = (*env)->NewGlobalRef(env, 
		(*env)->FindClass(env, "com/antisip/amsip/AudioOutput")
	);
	audiooutput_cons = (*env)->GetMethodID(env, audiooutput_myclz, "<init>", 
										  "(I)V");
	audiooutput_cons_write_bytes = (*env)->GetMethodID(env, audiooutput_myclz, "write_bytes", 
									  "([BI)I");
	audiooutput_cons_halt = (*env)->GetMethodID(env, audiooutput_myclz, "stop", 
									  "()I");

	/* check all rate supported by stack */
	jmethodID audiorecord_getMinBufferSize;
	jclass audiorecord_myclz = (*env)->NewGlobalRef(env,
						(*env)->FindClass(env, "android/media/AudioRecord")
						);

	audiorecord_getMinBufferSize=(*env)->GetStaticMethodID(env, audiorecord_myclz, "getMinBufferSize", "(III)I");

	if ((*env)->CallStaticIntMethod(env, audiorecord_myclz, audiorecord_getMinBufferSize, 8000, 2, 2)>0)
	  rate[0]=8000;
	if ((*env)->CallStaticIntMethod(env, audiorecord_myclz, audiorecord_getMinBufferSize, 16000, 2, 2)>0)
	  rate[1]=16000;
	if ((*env)->CallStaticIntMethod(env, audiorecord_myclz, audiorecord_getMinBufferSize, 32000, 2, 2)>0)
	  rate[2]=32000;
	if ((*env)->CallStaticIntMethod(env, audiorecord_myclz, audiorecord_getMinBufferSize, 48000, 2, 2)>0)
	  rate[3]=48000;
	(*env)->DeleteGlobalRef(env, audiorecord_myclz);


	videodisplay_myclz = (*env)->NewGlobalRef(env,
						  (*env)->FindClass(env, "com/antisip/vbyantisip/VideoDisplay"));
	videodisplay_lockIncomingImage = (*env)->GetMethodID(env, videodisplay_myclz, "lockIncomingImage",
							     "(II)Landroid/graphics/Bitmap;");
	videodisplay_unlockIncomingImage = (*env)->GetMethodID(env, videodisplay_myclz, "unlockIncomingImage",
							       "()V");

	ms_mutex_init(&vd_mutex,NULL);
	return(JNI_VERSION_1_4);
}
