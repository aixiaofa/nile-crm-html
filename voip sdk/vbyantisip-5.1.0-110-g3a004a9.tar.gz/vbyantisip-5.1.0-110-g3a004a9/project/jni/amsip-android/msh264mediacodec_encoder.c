/*
  amsip is a SIP library for softphone (SIP -rfc3261-)
  Copyright (C) 2010-2012 Aymeric MOIZARD - <amoizard@gmail.com>
*/

#include <string.h>
#include <jni.h>

#include <math.h>

#include <mediastreamer2/msfilter.h>
#include <mediastreamer2/rfc3984.h>
#include <mediastreamer2/msvideo.h>
#include <mediastreamer2/msticker.h>

#include <libavcodec/avcodec.h>
#include <libswscale/swscale.h>

#include <ortp/b64.h>

#ifdef _MSC_VER
#include <stdint.h>
#endif

#define FORCE_MODE

extern JavaVM *jvm;

static pthread_key_t key;
static pthread_once_t once_control = PTHREAD_ONCE_INIT;

static MSPixFmt ffmpeg_pix_fmt_to_ms(int fmt){
	switch(fmt){
		case PIX_FMT_YUV420P:
			return MS_YUV420P;
		case PIX_FMT_YUYV422:
			return MS_YUYV;     /* same as MS_YUY2 */
		case PIX_FMT_RGB24:
			return MS_RGB24;
		case PIX_FMT_BGR24:
			return MS_RGB24_REV;
		case PIX_FMT_UYVY422:
			return MS_UYVY;
		case PIX_FMT_RGBA:
			return MS_RGBA;
		case PIX_FMT_NV21:
			return MS_NV21;
		case PIX_FMT_NV12:
			return MS_NV12;
		case PIX_FMT_ABGR:
			return MS_ABGR;
		case PIX_FMT_ARGB:
			return MS_ARGB;
		case PIX_FMT_RGB565:
			return MS_RGB565;
		case PIX_FMT_BGRA:
			return MS_BGRA;
    case PIX_FMT_YUVJ420P:
			return MS_YUV420P; /* default */
		default:
			ms_error("format not supported.");
			return MS_YUV420P; /* default */
	}
	return MS_YUV420P; /* default */
}


typedef struct _H264MediaCodecEncState{
  JNIEnv* jenv;
  jobject* jobj; /* global ref on H264MediaCodecEncoder */
  jbyteArray jdata_h264;
  jbyteArray jdata_nv12;

  MSVideoSize vsize;
  int bitrate;
  float fps;
  int mode;
  int profile_idc;
  uint64_t framenum;
  Rfc3984Context packer;
  mblk_t *sav_sps;
  mblk_t *sav_pps;
  int reset;
  int _send_idr;

  MSPicture outbuf;
  struct MSScalerContext *sws_ctx;
  mblk_t *nv12_msg;
  int codec_format;

}H264MediaCodecEncState;

static void enc_init(MSFilter *f){
  H264MediaCodecEncState *d=ms_new0(H264MediaCodecEncState,1);
  d->jobj=NULL;
  d->jenv=NULL;

  d->bitrate=384000;
  d->vsize.width=MS_VIDEO_SIZE_CIF_W;
  d->vsize.height=MS_VIDEO_SIZE_CIF_H;
  d->fps=30;
  d->mode=0;
  d->profile_idc=13;
  d->framenum=0;
  d->sav_sps=NULL;
  d->sav_pps=NULL;
  d->reset=1;
  d->_send_idr = 0;
  d->codec_format = -1;
  f->data=d;
}

static void enc_close(MSFilter *f, JNIEnv *env);

static void enc_uninit(MSFilter *f){
	H264MediaCodecEncState *d=(H264MediaCodecEncState*)f->data;
	JNIEnv* env;
	if ((*jvm)->GetEnv(jvm, (void**)&env, JNI_VERSION_1_4) != JNI_OK) {
	  ms_error("H264MediaCodecEnc: GetVm failed!");
	  return;
	}

	enc_close(f, env);
	d->jobj=NULL;

	if (d->jdata_h264!=NULL)
	  (*env)->DeleteGlobalRef(env, d->jdata_h264);

	if (d->jdata_nv12!=NULL)
	  (*env)->DeleteGlobalRef(env, d->jdata_nv12);

	if (d->sws_ctx!=NULL){
	  ms_video_scalercontext_free(d->sws_ctx);
	  d->sws_ctx=NULL;
	}
	if (d->nv12_msg) freemsg(d->nv12_msg);
	ms_free(d);
}

static void enc_preprocess(MSFilter *f){
	H264MediaCodecEncState *d=(H264MediaCodecEncState*)f->data;
	rfc3984_init(&d->packer);
#ifdef FORCE_MODE
	d->mode=1;
#endif
	rfc3984_set_mode(&d->packer,d->mode);

	d->framenum=0;
	d->sav_pps=NULL;
	d->sav_sps=NULL;
}

static void h264_nals_to_msgb(MSFilter *f, mblk_t *buf, MSQueue * nalus){
  H264MediaCodecEncState *d=(H264MediaCodecEncState*)f->data;
  int i;
  mblk_t *m;
  unsigned char *beg=NULL;
  unsigned char *end=buf->b_rptr;

  while (end+4<buf->b_wptr) {
    if (end[0]==0 && end[1]==0 && end[2]==0 && end[3]==1) {
      if (beg==NULL) {	
	beg=end+4;
	end=beg;
	continue;
      } else if (end==beg) {
	beg=end+4;
	end=beg;
	continue;
      } else {
	m=allocb(end-beg, 0);
	memcpy(m->b_rptr, beg, end-beg);
	m->b_wptr=m->b_rptr+(end-beg);

#if 0
	if (xnals[i].i_type==7) {
	  ms_message("H264MediaCodecEnc: A SPS is being sent.");
	  if (d->sav_sps!=NULL)
	    freeb(d->sav_sps);
	  d->sav_sps=dupb(m);
	}else if (xnals[i].i_type==8) {
	  ms_message("H264MediaCodecEnc: A PPS is being sent.");
	  if (d->sav_pps!=NULL)
	    freeb(d->sav_pps);
	  d->sav_pps=dupb(m);
	}
#endif
	ms_queue_put(nalus,m);
	beg=end+4;
	end=beg;
	continue;
      }
    }

    end++;
  }

  if (beg!=NULL && buf->b_wptr-beg>0) {
    m=allocb(buf->b_wptr-beg, 0);
    memcpy(m->b_rptr, beg, buf->b_wptr-beg);
    m->b_wptr=m->b_rptr+(buf->b_wptr-beg);
    ms_queue_put(nalus,m);
  }

  freeb(buf);
}

static void enc_postprocess(MSFilter *f){
	H264MediaCodecEncState *d=(H264MediaCodecEncState*)f->data;
	rfc3984_uninit(&d->packer);
	if (d->sav_sps!=NULL)
		freeb(d->sav_sps);
	d->sav_sps=NULL;
	if (d->sav_pps!=NULL)
		freeb(d->sav_pps);
	d->sav_pps=NULL;
}

static mblk_t *get_as_nv12msg(MSFilter *f, H264MediaCodecEncState *s, MSPicture *orig){
  
  if (s->outbuf.w!=orig->w || s->outbuf.h!=orig->h){
    int total_size;
    if (s->sws_ctx!=NULL){
      ms_video_scalercontext_free(s->sws_ctx);
      s->sws_ctx=NULL;
      freemsg(s->nv12_msg);
      s->nv12_msg=NULL;
    }
    ms_message("H264MediaCodecEnc: Getting %i picture of %ix%i",s->codec_format,orig->w,orig->h);

    s->nv12_msg=allocb(orig->w * orig->h * 3/2, 0);
    total_size = yuv_buf_init_with_format(&s->outbuf, s->codec_format, orig->w, orig->h, (uint8_t*)s->nv12_msg->b_rptr);
    s->nv12_msg->b_wptr = s->nv12_msg->b_rptr+total_size;

    s->outbuf.w=orig->w;
    s->outbuf.h=orig->h;
    s->sws_ctx=ms_video_scalercontext_init(orig->w,orig->h,MS_YUV420P,
					   orig->w,orig->h,s->codec_format,MS_YUVFAST,
					   NULL, NULL, NULL);
  }
  if (ms_video_scalercontext_convert(s->sws_ctx,orig->planes,orig->strides, 0,
				     orig->h, s->outbuf.planes, s->outbuf.strides)<0){
    ms_error("H264MediaCodecEnc: error in ms_video_scalercontext_convert().");
  }
  return dupmsg(s->nv12_msg);
}

static void jni_detach_thread(void *data){
  JNIEnv* env=(JNIEnv*)pthread_getspecific(key);
  ms_message("H264MediaCodecEnc: jni_detach_thread");
  if (env != NULL) {
    (*jvm)->DetachCurrentThread(jvm);
    pthread_setspecific(key,NULL);
  }
}

static void make_key(){
  (void) pthread_key_create(&key, jni_detach_thread);
}

static void jni_attach_thread(MSFilter *f)
{
  H264MediaCodecEncState *d=(H264MediaCodecEncState*)f->data;
  JNIEnv *env=NULL;

  pthread_once(&once_control, make_key);
  env=(JNIEnv*)pthread_getspecific(key);
  if (env==NULL)
    {
      int res = (*jvm)->AttachCurrentThread(jvm, &d->jenv, NULL);
      if (res!=0)
	{
	  ms_error("H264MediaCodecEnc: AttachCurrentThread failed! %i", res);
	  d->jenv=NULL;
	  return;
	}
      pthread_setspecific(key,d->jenv);
      ms_message("H264MediaCodecEnc: jni_attach_thread");
      return;
    }
  d->jenv=env;
  return;
}

jclass H264MediaCodecEncoder_myclz = 0;
jmethodID H264MediaCodecEncoder_cons = 0;
jmethodID H264MediaCodecEncoder_get_format = 0;
jmethodID H264MediaCodecEncoder_get_ms_format = 0;
jmethodID H264MediaCodecEncoder_close = 0;
jmethodID H264MediaCodecEncoder_encode_data = 0;
jmethodID H264MediaCodecEncoder_get_h264_data = 0;

static void enc_open(MSFilter *f) {
  H264MediaCodecEncState *d=(H264MediaCodecEncState*)f->data;
  int i;

  ms_message("H264MediaCodecEnc: enc_open");

  d->jobj = (*d->jenv)->NewGlobalRef(d->jenv, (*d->jenv)->NewObject(d->jenv, H264MediaCodecEncoder_myclz, H264MediaCodecEncoder_cons));
  ms_message("H264MediaCodecEnc: New Java Object H264MediaCodecEncoder allocated");

  if (d->jobj==NULL)
    {
      ms_message("H264MediaCodecEnc: Failed to allocate Java Object H264MediaCodecEncoder");
      return ;
    }
}

static void enc_close(MSFilter *f, JNIEnv *env) {
  H264MediaCodecEncState *d=(H264MediaCodecEncState*)f->data;
  int i;
  ms_message("H264MediaCodecEnc: enc_close");
  if (d->jobj==NULL)
    return;
  i = (*env)->CallIntMethod(env, d->jobj, H264MediaCodecEncoder_close);
  (*env)->DeleteGlobalRef(env, d->jobj);
  d->jobj=NULL;
  ms_message("H264MediaCodecEnc: calling destructor for H264MediaCodecEncState!");
}

static void enc_setup_methods(JNIEnv *env) {
  if (H264MediaCodecEncoder_myclz==0)
    H264MediaCodecEncoder_myclz = (*env)->NewGlobalRef(env, (*env)->FindClass(env, "com/antisip/amsip/H264MediaCodecEncoder"));

  if (H264MediaCodecEncoder_myclz==0)
    ms_message("H264MediaCodecEnc: H264MediaCodecEncoder_myclz NOT loaded");
  else
    ms_message("H264MediaCodecEnc: H264MediaCodecEncoder_myclz loaded");
  if (H264MediaCodecEncoder_myclz==0)
    return;

  if (H264MediaCodecEncoder_cons==0)
    H264MediaCodecEncoder_cons = (*env)->GetMethodID(env, H264MediaCodecEncoder_myclz, "<init>", "()V");
  if (H264MediaCodecEncoder_cons==0) {
    ms_message("H264MediaCodecEnc: missing method: H264MediaCodecEncoder_cons");
    return;
  }

  if (H264MediaCodecEncoder_get_format==0)
    H264MediaCodecEncoder_get_format = (*env)->GetStaticMethodID(env, H264MediaCodecEncoder_myclz, "get_format", "()I");
  if (H264MediaCodecEncoder_get_format==0) {
    ms_message("H264MediaCodecEnc: missing method: H264MediaCodecEncoder_get_format");
    return;
  }

  if (H264MediaCodecEncoder_get_ms_format==0)
    H264MediaCodecEncoder_get_ms_format = (*env)->GetStaticMethodID(env, H264MediaCodecEncoder_myclz, "get_ms_format", "()I");
  if (H264MediaCodecEncoder_get_ms_format==0) {
    ms_message("H264MediaCodecEnc: missing method: H264MediaCodecEncoder_get_ms_format");
    return;
  }

  if (H264MediaCodecEncoder_close==0)
    H264MediaCodecEncoder_close = (*env)->GetMethodID(env, H264MediaCodecEncoder_myclz, "close", "()I");
  if (H264MediaCodecEncoder_close==0) {
    ms_message("H264MediaCodecEnc: missing method: H264MediaCodecEncoder_close");
    return;
  }

  if (H264MediaCodecEncoder_encode_data==0)
    H264MediaCodecEncoder_encode_data = (*env)->GetMethodID(env, H264MediaCodecEncoder_myclz, "encode_data", "(IIII[BI)I");
  if (H264MediaCodecEncoder_encode_data==0) {
    ms_message("H264MediaCodecEnc: missing method: H264MediaCodecEncoder_encode_data");
    return;
  }

  if (H264MediaCodecEncoder_get_h264_data==0)
    H264MediaCodecEncoder_get_h264_data = (*env)->GetMethodID(env, H264MediaCodecEncoder_myclz, "get_h264_data", "([BI)I");
  if (H264MediaCodecEncoder_get_h264_data==0) {
    ms_message("H264MediaCodecEnc: missing method: H264MediaCodecEncoder_get_h264_data");
    return;
  }
}

static void enc_process(MSFilter *f){
  H264MediaCodecEncState *d=(H264MediaCodecEncState*)f->data;
  uint32_t ts=(uint32_t)(f->ticker->time*90LL);
  mblk_t *im;
  MSPicture pic;
  int i;

  jni_attach_thread(f);

  if (d->jenv==NULL) {
    ms_message("H264MediaCodecEnc: d->jenv is NULL?");
    return;
  }

  if (H264MediaCodecEncoder_get_h264_data==0) {
    ms_queue_flush(f->inputs[0]);
    return;
  }

  if (d->jdata_h264==NULL) {
    d->jdata_h264 = (*d->jenv)->NewByteArray(d->jenv, 70000);
    d->jdata_h264 = (jbyteArray)(*d->jenv)->NewGlobalRef(d->jenv, d->jdata_h264);
  }
  if (d->jdata_h264==NULL) {
    ms_queue_flush(f->inputs[0]);
    return;
  }

  if (d->codec_format==-1) {
    i = (*d->jenv)->CallStaticIntMethod(d->jenv, H264MediaCodecEncoder_myclz, H264MediaCodecEncoder_get_format);
    if (i==19) /* COLOR_FormatYUV420Planar */
      d->codec_format = MS_YUV420P;
    else if (i==20) /* COLOR_FormatYUV420PackedPlanar */
      d->codec_format = MS_YUV420P;
    else if (i==2130706688) /* COLOR_TI_FormatYUV420PackedSemiPlanar */
      d->codec_format = MS_NV12;
    else if (i==0x7f000001) /* COLOR_TI_FormatYUV420PackedSemiPlanarInterlaced */
      d->codec_format = MS_NV12;
    else if (i==2141391872) /* COLOR_QCOM_FormatYUV420SemiPlanar */
      d->codec_format = MS_NV12;
    else if (i==21) /* COLOR_FormatYUV420SemiPlanar */ 
      d->codec_format = MS_NV12;

    //Let the java side decide the format: NV_21 instead of MS_NV12 detected on samsung s3... (any other?)
    d->codec_format = (*d->jenv)->CallStaticIntMethod(d->jenv, H264MediaCodecEncoder_myclz, H264MediaCodecEncoder_get_ms_format);
  }
  
  if (d->codec_format<0) {
    ms_queue_flush(f->inputs[0]);
    return;
  }

  while((im=ms_queue_get(f->inputs[0]))!=NULL){
    if (yuv_buf_init_from_mblk(&pic,im)==0){
      
      mblk_t *nv12 = get_as_nv12msg(f, d, &pic);

      if (d->vsize.width!=pic.w || d->vsize.height!=pic.h || d->reset==1)
	{
	  d->vsize.width=pic.w;
	  d->vsize.height=pic.h;
	  enc_postprocess(f);

	  enc_close(f, d->jenv);
	  enc_open(f);


	  enc_preprocess(f);
	  ms_message("H264MediaCodecEnc: new setting applied (%ix%i)", pic.w, pic.h);
	  d->reset=0;

	  if (d->jdata_nv12!=NULL)
	    (*d->jenv)->DeleteGlobalRef(d->jenv, d->jdata_nv12);
	  d->jdata_nv12=NULL;
	}

      if (d->jdata_nv12==NULL) {
	d->jdata_nv12 = (*d->jenv)->NewByteArray(d->jenv, msgdsize(nv12));
	d->jdata_nv12 = (jbyteArray)(*d->jenv)->NewGlobalRef(d->jenv, d->jdata_nv12);
      }
      if (d->jdata_nv12==NULL) {
	ms_queue_flush(f->inputs[0]);
	continue;
      }
      
      //jbyteArray jdata_nv12 = (*d->jenv)->NewByteArray(d->jenv, msgdsize(nv12));
      (*d->jenv)->SetByteArrayRegion(d->jenv, d->jdata_nv12, 0, msgdsize(nv12), (jbyte*)nv12->b_rptr);

      i = (*d->jenv)->CallIntMethod(d->jenv, d->jobj, H264MediaCodecEncoder_encode_data,
				    d->vsize.width, d->vsize.height, (int)d->fps, d->bitrate, d->jdata_nv12, msgdsize(nv12));

      freemsg(nv12);

    }      
    freemsg(im);
  }

  {
    MSQueue nalus;
    int h264_len = (*d->jenv)->CallIntMethod(d->jenv, d->jobj, H264MediaCodecEncoder_get_h264_data, d->jdata_h264, 70000);
    ms_queue_init(&nalus);
    while (h264_len>0) {
      mblk_t *om=allocb(h264_len,0);
      memset(om->b_wptr,0,h264_len);
      
      (*d->jenv)->GetByteArrayRegion(d->jenv, d->jdata_h264, 0, h264_len, (jbyte*)om->b_wptr);
      om->b_wptr+=h264_len;
      
      h264_nals_to_msgb(f, om, &nalus);
      rfc3984_pack(&d->packer,&nalus,f->outputs[0],ts);
      d->framenum++;

      h264_len = (*d->jenv)->CallIntMethod(d->jenv, d->jobj, H264MediaCodecEncoder_get_h264_data, d->jdata_h264, 70000);
    }
  }

}

static int enc_set_br(MSFilter *f, void *arg){
  H264MediaCodecEncState *d=(H264MediaCodecEncState*)f->data;
  d->bitrate=*(int*)arg;
  if (d->bitrate>=512000){
    d->vsize.width=MS_VIDEO_SIZE_VGA_W;
    d->vsize.height=MS_VIDEO_SIZE_VGA_H;
    d->fps=15;
  }else if (d->bitrate>=64000){
    d->vsize.width=MS_VIDEO_SIZE_QVGA_W;
    d->vsize.height=MS_VIDEO_SIZE_QVGA_H;
    d->fps=15;
  }else if (d->bitrate>=20000){
    /* for static images */
    d->vsize.width=MS_VIDEO_SIZE_CIF_W;
    d->vsize.height=MS_VIDEO_SIZE_CIF_H;
    d->fps=1;
  }
  if (d->jobj!=NULL)
    d->reset=1;
  return 0;
}

static int enc_set_fps(MSFilter *f, void *arg){
	H264MediaCodecEncState *d=(H264MediaCodecEncState*)f->data;
	d->fps=*(float*)arg;
	return 0;
}

static int enc_get_fps(MSFilter *f, void *arg){
	H264MediaCodecEncState *d=(H264MediaCodecEncState*)f->data;
	*(float*)arg=d->fps;
	return 0;
}

static int enc_get_vsize(MSFilter *f, void *arg){
	H264MediaCodecEncState *d=(H264MediaCodecEncState*)f->data;
	*(MSVideoSize*)arg=d->vsize;
	return 0;
}

static int enc_add_fmtp(MSFilter *f, void *arg){
	H264MediaCodecEncState *d=(H264MediaCodecEncState*)f->data;
	const char *fmtp=(const char *)arg;
	char value[12];
	if (fmtp_get_value(fmtp,"packetization-mode",value,sizeof(value))){
		d->mode=atoi(value);
		ms_message("H264MediaCodecEnc: packetization-mode set to %i",d->mode);
	}
	if (fmtp_get_value(fmtp,"profile-level-id",value,sizeof(value))){
		if (value[0]!='\0' && strlen(value)==6)
		{
			d->profile_idc=0;
			if (value[4] >= '0' && value[4] <= '9')
	            d->profile_idc = (d->profile_idc << 4) + (value[4] - '0');
			else if (value[4] >= 'A' && value[4] <= 'F')
	            d->profile_idc = (d->profile_idc << 4) + (value[4] - 'A' + 10);
			else if (value[4] >= 'a' && value[4] <= 'f')
	            d->profile_idc = (d->profile_idc << 4) + (value[4] - 'a' + 10);

			if (value[5] >= '0' && value[5] <= '9')
	            d->profile_idc = (d->profile_idc << 4) + (value[5] - '0');
			else if (value[5] >= 'A' && value[5] <= 'F')
	            d->profile_idc = (d->profile_idc << 4) + (value[5] - 'A' + 10);
			else if (value[5] >= 'a' && value[5] <= 'f')
	            d->profile_idc = (d->profile_idc << 4) + (value[5] - 'a' + 10);
		}
	}
	return 0;
}

static int enc_req_vfu(MSFilter *f, void *arg){
  H264MediaCodecEncState *d=(H264MediaCodecEncState*)f->data;
  d->_send_idr=1;
}


static MSFilterMethod enc_methods[]={
  {MS_FILTER_SET_FPS	,	enc_set_fps	},
  {MS_FILTER_SET_BITRATE	,	enc_set_br	},
  {MS_FILTER_GET_FPS	,	enc_get_fps	},
  {MS_FILTER_GET_VIDEO_SIZE,	enc_get_vsize	},
  {MS_FILTER_ADD_FMTP	,	enc_add_fmtp	},
  {MS_FILTER_REQ_VFU, enc_req_vfu},
  {	0	,			NULL		}
};

MSFilterDesc h264mediacodec_enc_desc={
  MS_FILTER_PLUGIN_ID,
  "MSH264MediaCodecEnc",
  "A H264 encoder based on MediaCodec android API.",
  MS_FILTER_ENCODER,
  "H264",
  1,
  1,
  enc_init,
  enc_preprocess,
  enc_process,
  enc_postprocess,
  enc_uninit,
  enc_methods,
  MS_FILTER_PRIORITY_BIT2|MS_FILTER_PRIORITY_BIT3
};

#ifdef WIN32
#define GLOBAL_LINKAGE __declspec(dllexport)
#else
#define GLOBAL_LINKAGE
#endif

GLOBAL_LINKAGE void libmsandroidmediacodecenc_init(void);

GLOBAL_LINKAGE void libmsandroidmediacodecenc_init(void){
  JNIEnv *env;
  if ((*jvm)->GetEnv(jvm, (void**)&env, JNI_VERSION_1_4) != JNI_OK) {
    ms_error("H264MediaCodecEnc: GetVm failed!");
    return;
  }  
  if (H264MediaCodecEncoder_get_h264_data==0)
    enc_setup_methods(env);
  
  if (H264MediaCodecEncoder_get_h264_data==0)
    return;

  ms_filter_register(&h264mediacodec_enc_desc);
}
