/*
  amsip is a SIP library for softphone (SIP -rfc3261-)
  Copyright (C) 2003,2004,2005,2006,2007,2008,2009,2010  Aymeric MOIZARD - <amoizard@gmail.com>
*/

#ifdef HAVE_CONFIG_H
#include "mediastreamer-config.h"
#endif

#include "mediastreamer2/msfilter.h"
#include "mediastreamer2/msvideo.h"
#include "mediastreamer2/msticker.h"

#include "../amsip/mediastreamer2/src/rfc2429.h"
#include "mediastreamer2/rfc3984.h"

#define REMOVE_PREVENTING_BYTES 1
#define FORCE_MODE 0 //-1

static bool_t android_initialized=FALSE;

extern int video_fd;

void ms_android_check_init(){
	if(!android_initialized){
		android_initialized=TRUE;
	}
}

enum video_codec {
  CODEC_ID_H263,
  CODEC_ID_H263P,
  CODEC_ID_MPEG4,
  CODEC_ID_H264,
};

typedef struct EncState{
	int socket;
	int socket_fd;
	enum video_codec codec;
	mblk_t *inm;
	MSVideoSize vsize;
	int mtu;	/* network maximum transmission unit in bytes */
	int profile;
	float fps;
	int maxbr;
	uint32_t framenum;
	bool_t req_vfu;

	Rfc3984Context _packer;
	int mode; /* save mode after detach/attach operation */
}EncState;

static int enc_set_fps(MSFilter *f, void *arg){
	EncState *s=(EncState*)f->data;
	s->fps=*(float*)arg;
	return 0;
}

static int enc_get_fps(MSFilter *f, void *arg){
	EncState *s=(EncState*)f->data;
	*(float*)arg=s->fps;
	return 0;
}

static int enc_set_vsize(MSFilter *f,void *arg){
	EncState *s=(EncState*)f->data;
	s->vsize=*(MSVideoSize*)arg;
	return 0;
}

static int enc_get_vsize(MSFilter *f,void *arg){
	EncState *s=(EncState*)f->data;
	*(MSVideoSize*)arg=s->vsize;
	return 0;
}

static int enc_set_mtu(MSFilter *f,void *arg){
	EncState *s=(EncState*)f->data;
	s->mtu=*(int*)arg;
	return 0;
}

static bool_t parse_video_fmtp(const char *fmtp, float *fps, MSVideoSize *vsize){
	char *tmp=ms_strdup(fmtp);
	char *semicolon;
	char *equal;
	bool_t ret=TRUE;

	ms_message("AmsipService parsing %s",fmtp);
	/*extract first pair */
	if ((semicolon=strchr(tmp,';'))!=NULL){
		*semicolon='\0';
	}
	if ((equal=strchr(tmp,'='))!=NULL){
		int divider;
		*equal='\0';
		if (strcasecmp(tmp,"CIF")==0){
			if (vsize->width>=MS_VIDEO_SIZE_CIF_W){
				vsize->width=MS_VIDEO_SIZE_CIF_W;
				vsize->height=MS_VIDEO_SIZE_CIF_H;
			}
		}else if (strcasecmp(tmp,"QCIF")==0){
			vsize->width=MS_VIDEO_SIZE_QCIF_W;
			vsize->height=MS_VIDEO_SIZE_QCIF_H;
		}else{
			ms_warning("unsupported video size %s",tmp);
			ret=FALSE;
		}
		divider=atoi(equal+1);
		if (divider!=0){
			float newfps=29.97/divider;
			if (*fps>newfps) *fps=newfps;
		}else{
			ms_warning("Could not find video fps");
			ret=FALSE;
		}
	}else ret=FALSE;
	ms_free(tmp);
	return ret;
}

static int enc_add_fmtp(MSFilter *f,void *arg){
	EncState *s=(EncState*)f->data;
	const char *fmtp=(const char*)arg;
	char val[10];
	if (fmtp_get_value(fmtp,"packetization-mode",val,sizeof(val))){
		if (FORCE_MODE<0)
		{
			s->mode=atoi(val);
			rfc3984_set_mode(&s->_packer,s->mode);
		}
	}else if (fmtp_get_value(fmtp,"profile",val,sizeof(val))){
		s->profile=atoi(val);
	}else parse_video_fmtp(fmtp,&s->fps,&s->vsize);
	return 0;
}

static int enc_req_vfu(MSFilter *f, void *unused){
	EncState *s=(EncState*)f->data;
	s->req_vfu=TRUE;
	return 0;
}

static void enc_init(MSFilter *f, enum video_codec codec)
{
	EncState *s=(EncState *)ms_new(EncState,1);
	f->data=s;
	ms_android_check_init();
	s->socket=0;
	s->socket_fd=0;
	s->profile=0;/*always default to profile 0*/
	s->fps=15;
	s->mtu=ms_get_payload_max_size()-2;/*-2 for the H263 payload header*/
	s->maxbr=500000;
	s->codec=codec;
	s->vsize.width=MS_VIDEO_SIZE_CIF_W;
	s->vsize.height=MS_VIDEO_SIZE_CIF_H;
	s->req_vfu=FALSE;
	s->framenum=0;
	s->inm=NULL;

	rfc3984_init(&s->_packer);
	rfc3984_set_mode(&s->_packer,0); /* default mode */
	s->mode=0;
	if (FORCE_MODE>=0)
	{
		rfc3984_set_mode(&s->_packer,FORCE_MODE);
		s->mode=FORCE_MODE;
	}

}

static void enc_h263_init(MSFilter *f){
	enc_init(f,CODEC_ID_H263P);
}

static void enc_h264_init(MSFilter *f){
	enc_init(f,CODEC_ID_H264);
}

static void enc_mpeg4_init(MSFilter *f){
	enc_init(f,CODEC_ID_MPEG4);
}

static void prepare(EncState *s){
}

static void prepare_h263(EncState *s){

	if (s->profile==0){
		s->codec=CODEC_ID_H263;
	}else{
		s->codec=CODEC_ID_H263P;
	}
}

static void prepare_h264(EncState *s){
}

static void prepare_mpeg4(EncState *s){

}


static void enc_uninit(MSFilter  *f){
	EncState *s=(EncState*)f->data;
	if (s->inm!=NULL)
	  freemsg(s->inm);
	s->inm=NULL;
	ms_free(s);
}

static void enc_open_server_socket(MSFilter *f)
{
  EncState *s=(EncState*)f->data;

  if (s->socket<=0)
    {
      struct sockaddr_in servaddr;
      char header_3gp[32];
      int flags;
      int alen;
      int i;
      
      memset (&servaddr, 0, sizeof (servaddr));
      
      servaddr.sin_port = htons((short) 5678);
      servaddr.sin_family = AF_INET;
      servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
      
      //strcpy( servaddr.sun_path, "AmsipVideoEncodedData" );
      s->socket = socket( AF_INET, SOCK_STREAM, IPPROTO_TCP ); /* Create the client's endpoint. */
      if (s->socket<0) {
	close(s->socket);
	s->socket=0;
	return;
      }
      
      //ms_message("AmsipService connecting socket %i", i);
      alen = sizeof(servaddr);
      i = bind(s->socket, (struct sockaddr *) &servaddr, alen);
      if (i<0) {
	ms_message("AmsipService failure binding socket %s", strerror(errno));
	close(s->socket);
	s->socket=0;
	return;
      }
      
      i = listen(s->socket, 1);
      if (i<0) {
	ms_message("AmsipService failure listen socket %s", strerror(errno));
	close(s->socket);
	s->socket=0;
	return;
      }
      
      if (-1 == (flags = fcntl(s->socket, F_GETFL, 0)))
	flags = 0;
      i = fcntl(s->socket, F_SETFL, flags | O_NONBLOCK);
      if (i<0) {
	ms_message("AmsipService set O_NONBLOCK on socket %s", strerror(errno));
	close(s->socket);
	s->socket=0;
	return;
      }
      ms_message("AmsipService videoenc server socket ready");
    }
  return;
}

static void enc_preprocess(MSFilter *f){
        EncState *s=(EncState*)f->data;
	prepare(s);
	if (s->codec==CODEC_ID_H263P || s->codec==CODEC_ID_H263) {
		prepare_h263(s);
                ms_message("AmsipService enc_preprocess: prepare for stream");
	}else if (s->codec==CODEC_ID_H264) {
                prepare_h264(s);
                ms_message("AmsipService enc_preprocess: prepare for stream");
	}else if (s->codec==CODEC_ID_MPEG4) {
		prepare_mpeg4(s);
                ms_message("AmsipService enc_preprocess: prepare for stream");
	}else {
		ms_error("AmsipService Unsupported codec id %i",s->codec);
		return;
	}

	enc_open_server_socket(f);
}


static void enc_postprocess(MSFilter *f){
	EncState *s=(EncState*)f->data;

	ms_message("AmsipService resetting socket");
	if (s->socket>0){
	  close(s->socket);
	  s->socket=0;
	}
	if (s->socket_fd>0){
	  close(s->socket_fd);
	  s->socket_fd=0;
	}

	rfc3984_uninit(&s->_packer);
	rfc3984_init(&s->_packer);
}

#if 0
static void add_rfc2190_header(mblk_t **packet, AVCodecContext *context){
	mblk_t *header;
	header = allocb(4, 0);
	memset(header->b_wptr, 0, 4);
	// CIF and QCIF support are mandatory, but other CIF format are allowed.
	if (context->width == MS_VIDEO_SIZE_CIF_W && context->height == MS_VIDEO_SIZE_CIF_H)
		header->b_wptr[1] = 0x60;
	else if (context->width == MS_VIDEO_SIZE_QCIF_W && context->height == MS_VIDEO_SIZE_QCIF_H)
		header->b_wptr[1] = 0x40;
	else if (context->width == MS_VIDEO_SIZE_SQCIF_W && context->height == MS_VIDEO_SIZE_SQCIF_H)
		header->b_wptr[1] = 0x20;
	else if (context->width == MS_VIDEO_SIZE_4CIF_W && context->height == MS_VIDEO_SIZE_4CIF_H)
		header->b_wptr[1] = 0x80;
	else if (context->width == MS_VIDEO_SIZE_16CIF_W && context->height == MS_VIDEO_SIZE_16CIF_H)
		header->b_wptr[1] = 0xA0;
	if (context->coded_frame->pict_type != FF_I_TYPE) header->b_wptr[1] |= 0x10;
	header->b_wptr += 4;
	header->b_cont = *packet;
	*packet = header;
}
#endif

static int get_gbsc_bytealigned(uint8_t *begin, uint8_t *end){
	int i;
	int len = end - begin;
	for (i = len - 2;  /*len + length of scan window*/
	   i > 2 + 2; /*length of scan window + 2 avoidance of 1st gob or psc*/
	   i--){
		if(*(begin + i) == 0 &&
		   *(begin + i+1) == 0 &&
		   (*(begin + i+2) & 0x80) == 0x80){
		  /*ms_message("JV psc/gob found! %2x %2x %2x", *(begin + i), *(begin + i+1), *(begin + i + 2));*/
		  return i;
		}
	}
	/*ms_message("JV no psc or gob found!");*/
	return len;
}

static void rfc2190_generate_packets(MSFilter *f, EncState *s, mblk_t *frame, uint32_t timestamp){
	mblk_t *packet=NULL;
	
	while (frame->b_rptr<frame->b_wptr){
		packet=dupb(frame);
		frame->b_rptr = packet->b_wptr =
			packet->b_rptr + get_gbsc_bytealigned(packet->b_rptr, MIN(packet->b_rptr+s->mtu,frame->b_wptr));
		//already there on android? add_rfc2190_header(&packet, &s->av_context);
		mblk_set_timestamp_info(packet,timestamp);
		ms_queue_put(f->outputs[0],packet);
	}
	/* the marker bit is set on the last packet, if any.*/
	mblk_set_marker_info(packet,TRUE);
}

void  push_nalu(MSQueue *nalus, uint8_t *begin, uint8_t *end){
	mblk_t *m;
	uint8_t *src=begin;
	m=allocb(end-begin,0);
	uint8_t nalu_type=(*begin) & ((1<<5)-1);
#ifdef REMOVE_PREVENTING_BYTES
	*m->b_wptr++=*src++;
	while(src<end-3){
		if (src[0]==0 && src[1]==0 && src[2]==3){
			*m->b_wptr++=0;
			*m->b_wptr++=0;
			src+=3;
			continue;
		}
		*m->b_wptr++=*src++;
	}
	*m->b_wptr++=*src++;
	*m->b_wptr++=*src++;
	*m->b_wptr++=*src++;
#else
	memcpy(m->b_wptr,begin,end-begin);
	m->b_wptr+=(end-begin);
#endif
	if (nalu_type==5) {
		ms_message("A IDR is being sent.");
	}else if (nalu_type==7) {
		ms_message("A SPS is being sent.");
	}
	else if (nalu_type==8) {
		ms_message("A PPS is being sent.");
	}
	ms_queue_put(nalus,m);	
}

static uint32_t AV_RB32(const void *p)
{
  uint32_t v;
  __asm__ ("ldr  %0, %1" : "=r"(v) : "m"(*(const uint32_t *)p));
  return v;
}

void  get_nalus(uint8_t *frame, int frame_size, MSQueue *nalus){
	int i;
	uint8_t *p,*begin=NULL;
	uint32_t size;
	int zeroes=0;
	
	for(i=0,p=frame;i<frame_size;++i){
		if (*p==0){
			++zeroes;
		}else if (zeroes>=2 && *p==1 ){
		  size = AV_RB32(p);
		  ms_message("AmsipService NALU internal size=%i", size); 
		  if (begin){
		    ms_message("AmsipService TRUE CONT NALU size %i - %x %x %x %i %i %i %i %i %i",p-zeroes-begin,
			       (*p) & ((1<<5)-1),
			       (*(p+1)) & ((1<<5)-1),
			       (*(p+2)) & ((1<<5)-1),
			       (*p) & ((1<<5)-1),
			       (*(p+1)) & ((1<<5)-1),
			       (*(p+2)) & ((1<<5)-1),
			       (*p), *(p+1), *(p+2)
			       );
		    push_nalu(nalus,begin,p-zeroes);
		  }
		  else
		    ms_message("AmsipService TRUE START NALU size %i - %x %x %x %i %i %i %i %i %i",p+1-frame,
			       (*p) & ((1<<5)-1),
			       (*(p+1)) & ((1<<5)-1),
			       (*(p+2)) & ((1<<5)-1),
			       (*p) & ((1<<5)-1),
			       (*(p+1)) & ((1<<5)-1),
			       (*(p+2)) & ((1<<5)-1),
			       (*p), *(p+1), *(p+2)
			       );
		  begin=p+1;
		}else {
		  if (zeroes>=2)
		    {
		      size = AV_RB32(p);
		      ms_message("AmsipService NALU internal size=%i", size); 
		    }
		  if (zeroes>=2 && begin==NULL)
		    ms_message("AmsipService FALSE START NALU size %i *p==%x - %x %x %x %i %i %i %i %i %i",p-zeroes-frame, *p,
			       (*p) & ((1<<5)-1),
			       (*(p+1)) & ((1<<5)-1),
			       (*(p+2)) & ((1<<5)-1),
			       (*p) & ((1<<5)-1),
			       (*(p+1)) & ((1<<5)-1),
			       (*(p+2)) & ((1<<5)-1),
			       (*p), *(p+1), *(p+2)
			       );
		  else if (zeroes>=2)
		    ms_message("AmsipService FALSE CONT NALU size %i *p==%x - %x %x %x %i %i %i %i %i %i",p-zeroes-begin, *p,
			       (*p) & ((1<<5)-1),
			       (*(p+1)) & ((1<<5)-1),
			       (*(p+2)) & ((1<<5)-1),
			       (*p) & ((1<<5)-1),
			       (*(p+1)) & ((1<<5)-1),
			       (*(p+2)) & ((1<<5)-1),
			       (*p), *(p+1), *(p+2)
			       );
		  zeroes=0;
		}
		++p;
	}
	if (begin){
	  ms_message("AmsipService NALU size -end- %i",p-begin);
	  push_nalu(nalus,begin,p);
	}
}

static void mpeg4_fragment_and_send(MSFilter *f,EncState *s,mblk_t *frame, uint32_t timestamp){
	uint8_t *rptr;
	mblk_t *packet=NULL;
	int len;
	for (rptr=frame->b_rptr;rptr<frame->b_wptr;){
		len=MIN(s->mtu,(frame->b_wptr-rptr));
		packet=dupb(frame);
		packet->b_rptr=rptr;
		packet->b_wptr=rptr+len;
		mblk_set_timestamp_info(packet,timestamp);
		ms_queue_put(f->outputs[0],packet);
		rptr+=len;
	}
	/*set marker bit on last packet*/
	mblk_set_marker_info(packet,TRUE);
}

static void rfc4629_generate_follow_on_packets(MSFilter *f, EncState *s, mblk_t *frame, uint32_t timestamp, uint8_t *psc, uint8_t *end, bool_t last_packet){
	mblk_t *packet;
	mblk_t *header;
	int len=end-psc;
	
	packet=dupb(frame);	
	packet->b_rptr=psc;
	packet->b_wptr=end;

	//header=allocb(2,0);
	//header->b_wptr[0]=0;
	//header->b_wptr[1]=0;
	//rfc2429_set_P(header->b_wptr,1);
	//header->b_wptr+=2;
	//header->b_cont=packet;
	//packet=header;

	//ms_message("AmsipService generating packet of size %i",end-psc);
	rfc2429_set_P(psc,1);
	mblk_set_timestamp_info(packet,timestamp);

	
	if (len>s->mtu){
		/*need to slit the packet using "follow-on" packets */
		/*compute the number of packets need (rounded up)*/
		int num=(len+s->mtu-1)/s->mtu;
		int i;
		uint8_t *pos;
		/*adjust the first packet generated*/
		pos=packet->b_wptr=packet->b_rptr+s->mtu;
		ms_queue_put(f->outputs[0],packet);
		//ms_message("AmsipService generating %i follow-on packets",num);
		for (i=1;i<num;++i){
			packet=dupb(frame);
			packet->b_rptr=pos;
			pos=packet->b_wptr=MIN(pos+s->mtu,end);
			header=allocb(2,0);
			header->b_wptr[0]=0;
			header->b_wptr[1]=0;
			header->b_wptr+=2;
			/*no P bit is set */
			header->b_cont=packet;
			packet=header;
			mblk_set_timestamp_info(packet,timestamp);
			ms_queue_put(f->outputs[0],packet);
		}
	}else ms_queue_put(f->outputs[0],packet);
	/* the marker bit is set on the last packet, if any.*/
	mblk_set_marker_info(packet,last_packet);
}

/* returns the last psc position just below packet_size */
static uint8_t *get_psc(uint8_t *begin,uint8_t *end, int packet_size){
	int i;
	uint8_t *ret=NULL;
	uint8_t *p;
	if (begin==end) return NULL;
	for(i=1,p=begin+1;p<end;++i,++p){
		if (p[-1]==0 && p[0]==0){
		  //if (i>=packet_size && ret!=NULL)
		  ret=p-1;
		  break;
		}
		p++;/* to skip possible 0 after the PSC that would make a double detection */
	}
	return ret;
}


static void split_and_send(MSFilter *f, EncState *s, mblk_t *frame){
	uint8_t *lastpsc;
	uint8_t *psc;
	uint32_t timestamp=f->ticker->time*90LL;
	
	if (s->codec==CODEC_ID_MPEG4)
	{
		mpeg4_fragment_and_send(f,s,frame,timestamp);
		return;
	}

	
	//ms_message("AmsipService processing frame of size %i (mtu=%i)",frame->b_wptr-frame->b_rptr, s->mtu);
	if (f->desc->id==MS_H263_ENC_ID){
		lastpsc=frame->b_rptr;
		while(1){
		  psc=get_psc(lastpsc+2,frame->b_wptr,s->mtu);
			if (psc!=NULL){
				rfc4629_generate_follow_on_packets(f,s,frame,timestamp,lastpsc,psc,TRUE);
				lastpsc=psc;
				break;
			}else break;
		}
		/* send the end of frame */
		//rfc4629_generate_follow_on_packets(f,s,frame, timestamp,lastpsc,frame->b_wptr,TRUE);
		frame->b_rptr=lastpsc;
	}else if (f->desc->id==MS_H263_OLD_ENC_ID){
		rfc2190_generate_packets(f,s,frame,timestamp);
	}else if (f->desc->id==MS_FILTER_PLUGIN_ID){
		lastpsc=frame->b_rptr;
		while(1){
		  psc=get_psc(lastpsc+2,frame->b_wptr,frame->b_wptr-lastpsc);
			if (psc!=NULL){
				MSQueue nalus;
				ms_queue_init(&nalus);
				ms_message("AmsipService next NALU: %i",psc-lastpsc);
				get_nalus(lastpsc,psc-lastpsc,&nalus);
				rfc3984_pack(&s->_packer,&nalus,f->outputs[0],timestamp);

				//rfc4629_generate_follow_on_packets(f,s,frame,timestamp,lastpsc,psc,TRUE);
				lastpsc=psc;
				break;
			}else break;
		}
		/* send the end of frame */
		//rfc4629_generate_follow_on_packets(f,s,frame, timestamp,lastpsc,frame->b_wptr,TRUE);
		frame->b_rptr=lastpsc;
	}else{
		ms_fatal("Ca va tres mal.");
	}
}

static void process_frame(MSFilter *f, mblk_t *inm){
	EncState *s=(EncState*)f->data;

	if (s->framenum==(int)(s->fps*2.0) || s->framenum==(int)(s->fps*4.0)){
		/*sends an I frame at 2 seconds and 4 seconds after the beginning of the call*/
		s->req_vfu=TRUE;
	}
	if (s->req_vfu){
		s->req_vfu=FALSE;
	}

	s->framenum++;
	split_and_send(f,s,inm);
	//freemsg(inm);
}

#include <sys/un.h> /* for Unix domain sockets */

static void enc_process(MSFilter *f){
	EncState *s=(EncState*)f->data;
	int i;

	enc_open_server_socket(f);

	if (s->socket<=0)
	  {
	    //ms_message("AmsipService: no server socket for video encoding filter");
	    return;
	  }

	if (s->socket_fd<=0) {
	  struct timeval tv;
	  fd_set readfds;
	  int flags;
	  int res;
	  int i;
	  FD_ZERO(&readfds);
	  FD_SET(s->socket, &readfds);
	  tv.tv_sec = 0;
	  tv.tv_usec = 0;

	  res = select(s->socket + 1, &readfds, NULL, NULL, &tv);
	  if (res < 0) {
	    /* error: should not happen */
	    ms_message("AmsipService failure accept socket %s", strerror(errno));
	    return ;
	  } else if (res > 0) {
	    /* data available */
	  } else {
	    /* timeout */
	    return;
	  }

	  i = accept(s->socket, NULL, NULL);
	  if (i<0) {
	    ms_message("AmsipService failure accept socket %s", strerror(errno));
	    return;
	  }
	  s->socket_fd = i;
	  ms_message("AmsipService AmsipVideoEncodedData socket connected");

	  if (-1 == (flags = fcntl(s->socket_fd, F_GETFL, 0)))
	    flags = 0;
	  i = fcntl(s->socket_fd, F_SETFL, flags | O_NONBLOCK);
	  if (i<0) {
	    ms_message("AmsipService set O_NONBLOCK on socket_fd %s", strerror(errno));
	    close(s->socket_fd);
	    s->socket_fd=0;
	    return;
	  }

	  if (s->inm!=NULL)
	    freemsg(s->inm);
	  s->inm=NULL;
	}

	ms_filter_lock(f);

	if (s->inm==NULL)
	  {
	    s->inm=allocb(20000, 0);
	  }
	msgpullup(s->inm, 20000);

	//ms_message("AmsipService will read %i", 20000-msgdsize(s->inm));
	int len=1400;
	if (20000-msgdsize(s->inm)<1400)
	  len = 20000-msgdsize(s->inm);

	if (len==0)
	  {
	    process_frame(f,s->inm);
	    msgpullup(s->inm, 20000);

	    if (msgdsize(s->inm)==20000)
	      {
		//no 00 in stream? (close to force restart)
		ms_message("AmsipService broken stream with no PSC detected");
		close(s->socket_fd);
		s->socket_fd=0;
		if (s->inm!=NULL)
		  freemsg(s->inm);
		s->inm=NULL;
	      }
	    ms_filter_unlock(f);
	    return;
	  }

	while((i=recv(s->socket_fd, s->inm->b_wptr, len, 0))>0){
	    s->inm->b_wptr=s->inm->b_wptr+i;
	    //ms_message("AmsipService read %i", i);
	    process_frame(f,s->inm);
	    msgpullup(s->inm, 20000);
	    len=1400;
	    if (20000-msgdsize(s->inm)<1400)
	      len = 20000-msgdsize(s->inm);
	    if (len==0)
	      break;
	}

	//if (f->last_tick%6==0 && msgdsize(s->inm)>0)
	//  {
	//    process_frame(f,s->inm);
	//    msgpullup(s->inm, 20000);
	//  }

	ms_filter_unlock(f);

	if (msgdsize(s->inm)==20000)
	  ms_error("AmsipService wrong video data format");

	if (i<0 && errno!=EAGAIN)
	  {
	    ms_message("AmsipService broken socket %s", strerror(errno));
	    close(s->socket_fd);
	    s->socket_fd=0;
	  }
	else if (i==0)
	  {
	    ms_message("AmsipService end of stream socket %i", i);
	    close(s->socket_fd);
	    s->socket_fd=0;
	  }
}

static int enc_get_br(MSFilter *f, void *arg){
	EncState *s=(EncState*)f->data;
	*(int*)arg=s->maxbr;
	return 0;
}

static int enc_set_br(MSFilter *f, void *arg){
	EncState *s=(EncState*)f->data;
	bool_t h263=((s->codec==CODEC_ID_H263P)||(s->codec==CODEC_ID_H263));
	s->maxbr=*(int*)arg;
	if (s->maxbr>=1024000 && !h263){
		s->vsize.width = MS_VIDEO_SIZE_SVGA_W;
		s->vsize.height = MS_VIDEO_SIZE_SVGA_H;
		s->fps=25;
	}else if (s->maxbr>=1024000 && h263){
		s->vsize.width = MS_VIDEO_SIZE_4CIF_W;
		s->vsize.height = MS_VIDEO_SIZE_4CIF_H;
		s->fps=25;
		s->maxbr=s->maxbr*4;
	}else if (s->maxbr>=800000 && !h263){
		s->vsize.width = MS_VIDEO_SIZE_VGA_W;
		s->vsize.height = MS_VIDEO_SIZE_VGA_H;
		s->fps=25;
	}else if (s->maxbr>=512000){
		s->vsize.width=MS_VIDEO_SIZE_CIF_W;
		s->vsize.height=MS_VIDEO_SIZE_CIF_H;
		s->fps=25;
	}else if (s->maxbr>=256000){
		s->vsize.width=MS_VIDEO_SIZE_CIF_W;
		s->vsize.height=MS_VIDEO_SIZE_CIF_H;
		s->fps=10;
	}else if (s->maxbr>=128000){
		s->vsize.width=MS_VIDEO_SIZE_QCIF_W;
		s->vsize.height=MS_VIDEO_SIZE_QCIF_H;
		s->fps=10;
	}else if (s->maxbr>=64000){
		s->vsize.width=MS_VIDEO_SIZE_QCIF_W;
		s->vsize.height=MS_VIDEO_SIZE_QCIF_H;
		s->fps=5;
	}else if (s->maxbr==20000){
		s->vsize.width=MS_VIDEO_SIZE_CIF_W;
		s->vsize.height=MS_VIDEO_SIZE_CIF_H;
		s->fps=2;
		s->maxbr=256000;
	}else{
		s->vsize.width=MS_VIDEO_SIZE_QCIF_W;
		s->vsize.height=MS_VIDEO_SIZE_QCIF_H;
		s->fps=5;
	}
	//if (s->socket>0){
	//	/*apply new settings dynamically*/
	//	ms_filter_lock(f);
	//	enc_postprocess(f);
	//	enc_preprocess(f);
	//	ms_filter_unlock(f);
	//}
	return 0;
}

static int get_statistics(MSFilter *f, void *arg){
	int i;
	ms_warning("filter: %s[%i->%i]", f->desc->name,
		f->desc->ninputs, f->desc->noutputs);
	for (i=0;i<f->desc->ninputs;i++) {
		if (f->inputs[i]!=NULL) ms_warning("filter: %s in[%i]=%i", f->desc->name,
			i, f->inputs[i]->q.q_mcount);
	}
	for (i=0;i<f->desc->noutputs;i++) {
		if (f->outputs[i]!=NULL) ms_warning("filter: %s out[%i]=%i", f->desc->name,
			i, f->outputs[i]->q.q_mcount);
	}
	return 0;
}

static MSFilterMethod methods[]={
	{	MS_FILTER_SET_FPS	,	enc_set_fps	},
	{	MS_FILTER_GET_FPS	,	enc_get_fps	},
	{	MS_FILTER_SET_VIDEO_SIZE ,	enc_set_vsize },
	{	MS_FILTER_GET_VIDEO_SIZE ,	enc_get_vsize },
	{	MS_FILTER_ADD_FMTP	,	enc_add_fmtp },
	{	MS_FILTER_SET_BITRATE	,	enc_set_br	},
	{	MS_FILTER_GET_BITRATE	,	enc_get_br	},
	{	MS_FILTER_SET_MTU	,	enc_set_mtu	},
	{	MS_FILTER_REQ_VFU	,	enc_req_vfu	},
	{	MS_FILTER_GET_STATISTICS, get_statistics },
	{	0			,	NULL	}
};

#ifdef _MSC_VER

MSFilterDesc ms_h263_enc_desc={
	MS_H263_ENC_ID,
	"MSH263Enc",
	N_("A video H.263 encoder using android opencore."),
	MS_FILTER_ENCODER,
	"H263-1998",
	0,
	1,
	enc_h263_init,
	enc_preprocess,
	enc_process,
	enc_postprocess,
	enc_uninit,
	methods
};

MSFilterDesc ms_h264_enc_desc={
        MS_FILTER_PLUGIN_ID, //MS_H264_ENC_ID,
	"MSH264Enc",
	N_("A video H.264 encoder using android opencore"),
	MS_FILTER_ENCODER,
	"H264",
	0,
	1,
	enc_h264_init,
	enc_preprocess,
	enc_process,
	enc_postprocess,
	enc_uninit,
	methods
};

MSFilterDesc ms_h263_old_enc_desc={
	MS_H263_OLD_ENC_ID,
	"MSH263OldEnc",
	N_("A video H.263 encoder using android opencore It is compliant with old RFC2190 spec."),
	MS_FILTER_ENCODER,
	"H263",
	0,
	1,
	enc_h263_init,
	enc_preprocess,
	enc_process,
	enc_postprocess,
	enc_uninit,
	methods
};

MSFilterDesc ms_mpeg4_enc_desc={
	MS_MPEG4_ENC_ID,
	"MSMpeg4Enc",
	N_("A video MPEG4 encoder using android opencore"),
	MS_FILTER_ENCODER,
	"MP4V-ES",
	0,
	1,
	enc_mpeg4_init,
	enc_preprocess,
	enc_process,
	enc_postprocess,
	enc_uninit,
	methods
};

#else

MSFilterDesc ms_h263_enc_desc={
	.id=MS_H263_ENC_ID,
	.name="MSH263Enc",
	.text=N_("A video H.263 encoder using android opencore"),
	.category=MS_FILTER_ENCODER,
	.enc_fmt="H263-1998",
	.ninputs=0,
	.noutputs=1,
	.init=enc_h263_init,
	.preprocess=enc_preprocess,
	.process=enc_process,
	.postprocess=enc_postprocess,
	.uninit=enc_uninit,
	.methods=methods
};

MSFilterDesc ms_h264_enc_desc={
        .id=MS_FILTER_PLUGIN_ID, //.id=MS_H264_ENC_ID,
	.name="MSH264Enc",
	.text=N_("A video H.264 encoder using android opencore"),
	.category=MS_FILTER_ENCODER,
	.enc_fmt="H264",
	.ninputs=0,
	.noutputs=1,
	.init=enc_h264_init,
	.preprocess=enc_preprocess,
	.process=enc_process,
	.postprocess=enc_postprocess,
	.uninit=enc_uninit,
	.methods=methods
};

MSFilterDesc ms_h263_old_enc_desc={
	.id=MS_H263_OLD_ENC_ID,
	.name="MSH263Enc",
	.text=N_("A video H.263 encoder using ffmpeg library, compliant with old RFC2190 spec."),
	.category=MS_FILTER_ENCODER,
	.enc_fmt="H263",
	.ninputs=0,
	.noutputs=1,
	.init=enc_h263_init,
	.preprocess=enc_preprocess,
	.process=enc_process,
	.postprocess=enc_postprocess,
	.uninit=enc_uninit,
	.methods=methods
};

MSFilterDesc ms_mpeg4_enc_desc={
	.id=MS_MPEG4_ENC_ID,
	.name="MSMpeg4Enc",
	.text=N_("A video MPEG4 encoder using android opencore"),
	.category=MS_FILTER_ENCODER,
	.enc_fmt="MP4V-ES",
	.ninputs=0,
	.noutputs=1,
	.init=enc_mpeg4_init,
	.preprocess=enc_preprocess,
	.process=enc_process,
	.postprocess=enc_postprocess,
	.uninit=enc_uninit,
	.methods=methods
};

#endif

void am_filter_register_android(void){
	ms_android_check_init();

	ms_message("Adding H263-1998 encoder support");
	ms_filter_register(&ms_h263_enc_desc);
	//ms_filter_register(&ms_h264_enc_desc);
	//ms_filter_register(&ms_h263_old_enc_desc);
}

