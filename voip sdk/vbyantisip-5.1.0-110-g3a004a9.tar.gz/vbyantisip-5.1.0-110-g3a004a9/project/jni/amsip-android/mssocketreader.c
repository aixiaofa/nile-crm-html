/*
  amsip is a SIP library for softphone (SIP -rfc3261-)
  Copyright (C) 2003, 2004, 2005, 2006, 2007, 2008, 2009 Aymeric MOIZARD - <jack@atosc.org>
*/

#ifdef ENABLE_VIDEO

#include "amsip/am_options.h"
#include "amsip/am_filter.h"

typedef struct MSSocketReader {
  int socket;
  int socket_fd;
  mblk_t *inm;
  int inm_size;
  int mStat_dropped;

  ms_mutex_t mutex;
} MSSocketReader;

static void sr_init(MSFilter * f)
{
  MSSocketReader *d = (MSSocketReader *) ms_new0(MSSocketReader, 1);

  d->socket=0;
  d->socket_fd=0;
  d->inm=NULL;
  d->inm_size=0;
  d->mStat_dropped=0;

  ms_mutex_init(&d->mutex, NULL);

  f->data = d;
}

static void sr_uninit(MSFilter * f)
{
  MSSocketReader *d = (MSSocketReader *) f->data;

  if (d->socket>0){
    close(d->socket);
    d->socket=0;
  }
  if (d->socket_fd>0){
    close(d->socket_fd);
    d->socket_fd=0;
  }

  if (d->inm)
    freemsg(d->inm);

  ms_mutex_destroy(&d->mutex);
  ms_free(f->data);
  f->data = NULL;
}

static void enc_open_server_socket(MSFilter *f)
{
  MSSocketReader *d = (MSSocketReader *)f->data;

  if (d->socket<=0)
    {
      struct sockaddr_in servaddr;
      char header_3gp[32];
      int flags;
      int alen;
      int i;
      
      memset (&servaddr, 0, sizeof (servaddr));
      
      servaddr.sin_port = htons((short) 5676);
      servaddr.sin_family = AF_INET;
      servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
      
      //strcpy( servaddr.sun_path, "AmsipVideoEncodedData" );
      d->socket = socket( AF_INET, SOCK_STREAM, IPPROTO_TCP ); /* Create the client's endpoint. */
      if (d->socket<0) {
	close(d->socket);
	d->socket=0;
	return;
      }
      
      //ms_message("AmsipServiceVideoEnc connecting socket %i", i);
      alen = sizeof(servaddr);
      i = bind(d->socket, (struct sockaddr *) &servaddr, alen);
      if (i<0) {
	ms_message("AmsipServiceVideoEnc failure binding socket %s", strerror(errno));
	close(d->socket);
	d->socket=0;
	return;
      }
      
      i = listen(d->socket, 1);
      if (i<0) {
	ms_message("AmsipServiceVideoEnc failure listen socket %s", strerror(errno));
	close(d->socket);
	d->socket=0;
	return;
      }
      
      if (-1 == (flags = fcntl(d->socket, F_GETFL, 0)))
	flags = 0;
      i = fcntl(d->socket, F_SETFL, flags | O_NONBLOCK);
      if (i<0) {
	ms_message("AmsipServiceVideoEnc set O_NONBLOCK on socket %s", strerror(errno));
	close(d->socket);
	d->socket=0;
	return;
      }
      ms_message("AmsipServiceVideoEnc videoenc server socket ready");
    }
  return;
}

static void sr_process(MSFilter * f)
{
  MSSocketReader*d = (MSSocketReader *) f->data;

  struct timeval tv;
  fd_set readfds;
  int flags;
  int res;
  int i;  

  enc_open_server_socket(f);

  if (d->socket<=0)
    {
      return;
    }

  
  if (d->socket_fd<=0) {
    struct timeval tv;
    fd_set readfds;
    int flags;
    int res;
    int i;
    FD_ZERO(&readfds);
    FD_SET(d->socket, &readfds);
    tv.tv_sec = 0;
    tv.tv_usec = 0;
    
    res = select(d->socket + 1, &readfds, NULL, NULL, &tv);
    if (res < 0) {
      /* error: should not happen */
      ms_message("AmsipServiceVideoEnc failure accept socket %s", strerror(errno));
      return ;
    } else if (res > 0) {
      /* data available */
    } else {
      /* timeout */
      return;
    }
    
    i = accept(d->socket, NULL, NULL);
    if (i<0) {
      ms_message("AmsipServiceVideoEnc failure accept socket %s", strerror(errno));
      return;
    }
    d->socket_fd = i;
    ms_message("AmsipServiceVideoEnc AmsipVideoEncodedData socket connected");
    
    if (-1 == (flags = fcntl(d->socket_fd, F_GETFL, 0)))
      flags = 0;
    i = fcntl(d->socket_fd, F_SETFL, flags | O_NONBLOCK);
    if (i<0) {
      ms_message("AmsipServiceVideoEnc set O_NONBLOCK on socket_fd %s", strerror(errno));
      close(d->socket_fd);
      d->socket_fd=0;
      return;
    }
    
    if (d->inm!=NULL)
      freemsg(d->inm);
    d->inm=NULL;
    d->inm_size=0;
  }
  
  ms_filter_lock(f);

  while (1)
    {
      if (d->inm_size==0)
	{
	  int32_t val;
	  i=recv(d->socket_fd, &val, 4, 0);
	  if (i<=0)
	    {
	      break;
	    }
	  if (i!=4) {
	    ms_warning("Please write full 4 byte header for len in one write operation");
	    if (errno!=EAGAIN) {
	      ms_warning("too late?");
	      errno=0;
	    }
	    i=-1;
	    break;
	  }
	  if (val<=0 || val>2000000)
	    {
	      i=-1; /* ? */
	      break;
	    }
	  d->inm = allocb(val+6, 0);
	  if (d->inm==NULL)
	    {
	      i=-1; /* ? */
	      break;
	    }
	  d->inm_size = val + 6;
	}
      if (d->inm_size>0)
	{
	  i=recv(d->socket_fd, d->inm->b_wptr, d->inm_size, 0);	  
	  if (i<=0)
	    {
	      break;
	    }
	  d->inm->b_wptr=d->inm->b_wptr+i;
	  d->inm_size = d->inm_size-i;
	  if (d->inm_size==0)
	    {
	      /* complete packet */
	      if (f->outputs[0]->q.q_mcount>=1)
		{
		  d->mStat_dropped++;
		  if (d->mStat_dropped%50==0)
		    ms_message("AmsipServiceVideoEnc: stat: drop extra packets %i", d->mStat_dropped);
		  freemsg(d->inm);
		  d->inm=NULL;
		}
	      else
		{
		  short *buf=(short*)d->inm->b_rptr;
		  uint8_t in_ms_fmt = *d->inm->b_rptr;
		  uint8_t rotation = *(d->inm->b_rptr+1);
		  short w = *(buf+1);
		  short h = *(buf+2);
		  MSPixFmt in_fmt = in_ms_fmt;
 		  mblk_set_video_width(d->inm, w);
		  mblk_set_video_height(d->inm, h);
		  mblk_set_video_format(d->inm, in_fmt);
		  mblk_set_payload_type(d->inm, rotation);
		  d->inm->b_rptr+=6;

		  //ms_message("AmsipServiceVideoEnc: webcam image info: %ix%i:%i:%i", w, h, in_ms_fmt, rotation);
		  ms_queue_put(f->outputs[0],d->inm);
		}
	      d->inm=NULL;
	    }
	  continue;
	}
    }

  ms_filter_unlock(f);
  
  if (i<0 && errno!=EAGAIN)
    {
      ms_message("AmsipServiceVideoEnc broken socket %s", strerror(errno));
      close(d->socket_fd);
      d->socket_fd=0;
    }
  else if (i==0)
    {
      ms_message("AmsipServiceVideoEnc end of stream socket %i", i);
      close(d->socket_fd);
      d->socket_fd=0;
    }
  
}

MSFilterDesc ms_socket_reader_desc = {
	MS_FILTER_PLUGIN_ID,
	"socket_reader",
	"A filter for retreiving data from a socket.",
	MS_FILTER_OTHER,
	NULL,
	0,
	1,
	sr_init,
	NULL,
	sr_process,
	NULL,
	sr_uninit,
	NULL
};

#ifdef _MSC_VER
#define MS_PLUGIN_DECLARE(type) __declspec(dllexport) type
#else
#define MS_PLUGIN_DECLARE(type) type
#endif

MS_PLUGIN_DECLARE(void) libmssocketreader_init()
{
  ms_filter_register(&ms_socket_reader_desc);
}

#endif
