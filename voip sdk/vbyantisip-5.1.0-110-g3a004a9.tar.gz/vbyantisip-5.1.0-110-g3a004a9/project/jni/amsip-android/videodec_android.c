/*
  amsip is a SIP library for softphone (SIP -rfc3261-)
  Copyright (C) 2003,2004,2005,2006,2007,2008,2009,2010  Aymeric MOIZARD - <amoizard@gmail.com>
*/

#ifdef HAVE_CONFIG_H
#include "mediastreamer-config.h"
#endif

#include "mediastreamer2/msticker.h"
#include "mediastreamer2/msfilter.h"
#include "mediastreamer2/msvideo.h"

#include "../amsip/mediastreamer2/src/rfc2429.h"

enum video_codec {
  CODEC_ID_H263,
  CODEC_ID_H263P,
  CODEC_ID_MPEG4,
  CODEC_ID_H264,
};

typedef struct DecState{
	enum video_codec codec;
	mblk_t *input;
	YuvBuf outbuf;
	mblk_t *yuv_msg;
	uint8_t dci[512];
	int dci_size;

        uint32_t tsoff;
        int rate;
        RtpProfile *rtsp_profile;
        RtpSession *rtsp_session;
        int frame_count;
        int initial_timestamp;
}DecState;


static void dec_init(MSFilter *f, enum video_codec cid){
	DecState *s=(DecState *)ms_new0(DecState,1);
	
	s->codec=cid;
	s->input=NULL;
	s->yuv_msg=NULL;
	s->outbuf.w=0;
	s->outbuf.h=0;

	s->tsoff=0;
	s->rate=90000;
	s->rtsp_profile=NULL;
	s->rtsp_session=NULL;
	s->frame_count=0;
	s->initial_timestamp=-1;
	f->data=s;

}

static void dec_h263_init(MSFilter *f){
	dec_init(f,CODEC_ID_H263);
}

static void dec_h264_init(MSFilter *f){
	dec_init(f,CODEC_ID_H264);
}

static void dec_h263p_init(MSFilter *f){
	dec_init(f,CODEC_ID_H263P);
}

static void dec_mpeg4_init(MSFilter *f){
	dec_init(f,CODEC_ID_MPEG4);
}

static void dec_uninit(MSFilter *f){
	DecState *s=(DecState*)f->data;
	if (s->input!=NULL) freemsg(s->input);
	if (s->yuv_msg!=NULL) freemsg(s->yuv_msg);
	ms_free(s);
}

static int dec_add_fmtp(MSFilter *f, void *data){
	const char *fmtp=(const char*)data;
	DecState *s=(DecState*)f->data;
	char config[512];
	if (fmtp_get_value(fmtp,"config",config,sizeof(config))){
		/*convert hexa decimal config string into a bitstream */
		int i,j,max=strlen(config);
		char octet[3];
		octet[2]=0;
		for(i=0,j=0;i<max;i+=2,++j){
			octet[0]=config[i];
			octet[1]=config[i+1];
			s->dci[j]=(uint8_t)strtol(octet,NULL,16);
		}
		s->dci_size=j;
		ms_message("Got mpeg4 config string: %s",config);
	}
	return 0;
}

static void dec_preprocess(MSFilter *f){
	DecState *s=(DecState*)f->data;

	ms_message("AmsipService Video Decoder rtsp session : dec_preprocess");
	s->frame_count=-1;
	s->initial_timestamp=-1;
	s->rtsp_profile = (RtpProfile *) rtp_profile_new("RtspProfileVideo");
	rtp_profile_set_payload(s->rtsp_profile,
				95,
				payload_type_clone
				(&payload_type_h263));
	rtp_profile_set_payload(s->rtsp_profile,
				96,
				payload_type_clone
				(&payload_type_h263_1998));
	rtp_profile_set_payload(s->rtsp_profile,
				97,
				payload_type_clone
				(&payload_type_h264));
	rtp_profile_set_payload(s->rtsp_profile,
				99,
				payload_type_clone
				(&payload_type_mp4v));
	
	if (s->rtsp_session==NULL)
	  {
	    ms_message("AmsipService Creating Rtsp Session");
	    s->rtsp_session = rtp_session_new(RTP_SESSION_SENDONLY);
	    rtp_session_set_symmetric_rtp(s->rtsp_session, 1);
	    rtp_session_set_recv_buf_size(s->rtsp_session, UDP_MAX_SIZE * 3);
	    rtp_session_set_profile(s->rtsp_session, s->rtsp_profile);
	    rtp_session_set_rtp_socket_recv_buffer_size(s->rtsp_session,2000000);
	    rtp_session_set_rtp_socket_send_buffer_size(s->rtsp_session,2000000);
	    rtp_session_set_local_addr(s->rtsp_session, "0.0.0.0", 16970);
	    rtp_session_set_remote_addr(s->rtsp_session, "127.0.0.1", 10268); //TODO... Get the port number?
	    rtp_session_set_dscp(s->rtsp_session, 0x28);
	    rtp_session_set_scheduling_mode(s->rtsp_session, 0);
	    rtp_session_set_blocking_mode(s->rtsp_session, 0);

	    rtp_session_set_ssrc(s->rtsp_session, 0xAC288726);

	    rtp_session_set_jitter_compensation(s->rtsp_session, 50);
	    rtp_session_enable_adaptive_jitter_compensation(s->rtsp_session, TRUE);
	    rtp_session_enable_jitter_buffer(s->rtsp_session, FALSE);

	    if (s->codec==CODEC_ID_H263)
	      rtp_session_set_send_payload_type(s->rtsp_session, 95);
	    else if (s->codec==CODEC_ID_H263P)
	      rtp_session_set_send_payload_type(s->rtsp_session, 96);
	    else if (s->codec==CODEC_ID_H264)
	      rtp_session_set_send_payload_type(s->rtsp_session, 97);
	    else if (s->codec==CODEC_ID_MPEG4)
	      rtp_session_set_send_payload_type(s->rtsp_session, 99);
	      
	  }

}

static void dec_postprocess(MSFilter *f){
	DecState *s=(DecState*)f->data;

	if (s->rtsp_session!=NULL)
	  {
	    rtp_session_destroy(s->rtsp_session);
	    s->rtsp_session=NULL;
	  }

	if (s->rtsp_profile!=NULL)
	  {
	    rtp_profile_destroy(s->rtsp_profile);
	    s->rtsp_profile=NULL;
	  }
}

static void dec_process(MSFilter *f){
        static int count=0;
	DecState *d = (DecState *) f->data;

	mblk_t *inm;

	count++;

	ms_filter_lock(f);

	//read anyway data
	{
	  uint32_t timestamp = (uint32_t) (f->ticker->time * (d->rate/1000));
	  //instantaneous symmetric RTP.
	  RtpStream *rtpstream=&d->rtsp_session->rtp;
	  rtp_stats_t *stats=&rtpstream->stats;
	    stats->packet_recv=0;
	  while ((inm = rtp_session_recvm_with_ts(d->rtsp_session, timestamp)) != NULL) {
	    //rtsp client ip:port is sending non RTP data and can
	    //change if we restart the rtsp server. This trick allow
	    freemsg(inm);
	    if (rtp_session_get_last_recv_error_code(d->rtsp_session)>0)
	      {
		rtp_session_clear_recv_error_code(d->rtsp_session);
		//d->errs++;
	      }
	  }
	  if (stats->packet_recv>0)
	    {
	      ms_message("AmsipService Video Decoder rtsp server detected");
	      d->frame_count=0;
	    }
	  if (stats->bad>0)
	    {
	      ms_message("AmsipService Video Decoder rtsp server detected -empty packet detected-");
	      d->frame_count=0;
	      stats->bad=0;
	    }
	}


	while((inm=ms_queue_get(f->inputs[0]))!=0){
	  uint32_t timestamp;
	  mblk_t *header;
	  int pt = rtp_session_get_send_payload_type(d->rtsp_session);;

	  header = rtp_session_create_packet(d->rtsp_session, 12, NULL, 0);

	  if (pt>0)
	    rtp_set_payload_type(header, pt);

	  rtp_set_markbit(header, mblk_get_marker_info(inm));
	  header->b_cont = inm;
	  
	  if (d->frame_count==-1)
	    {
	      ms_message("AmsipService Video Decoder / rtsp server started (payload=%i)", pt);
	      continue;
	    }

	  d->frame_count++;

#if 1
	  if (d->frame_count==1)
	    {
	      d->initial_timestamp=mblk_get_timestamp_info(inm);
	      ms_message("AmsipService Video Decoder adjust timestamp (payload=%i)", pt);
	      rtp_session_sendm_with_ts(d->rtsp_session, header, mblk_get_timestamp_info(inm)-90000*4);
	      continue;
	    }

	  if (d->frame_count==2)
	    {
	      rtp_session_sendm_with_ts(d->rtsp_session, header, mblk_get_timestamp_info(inm));
	      continue;
	    }
	  if (mblk_get_timestamp_info(inm)<d->initial_timestamp+90000*4)
	    {
	      rtp_session_sendm_with_ts(d->rtsp_session, header, d->initial_timestamp);
	      continue;
	    }

	  rtp_session_sendm_with_ts(d->rtsp_session, header, mblk_get_timestamp_info(inm)-90000*4);
#else
	  if (d->frame_count==0)
	    d->initial_timestamp=mblk_get_timestamp_info(inm);
	  rtp_session_sendm_with_ts(d->rtsp_session, header, mblk_get_timestamp_info(inm)-d->initial_timestamp);
#endif
	  
	  if (count%1000==0)
	    {
	      ms_message("AmsipService Video Decoder Packet Sent for Rtsp Session");
	      rtp_stats_display(&d->rtsp_session->rtp.stats,
				"stat for rtsp video session");
	    }

	}
	ms_filter_unlock(f);
}

static int get_statistics(MSFilter *f, void *arg){
	int i;
	ms_warning("filter: %s[%i->%i]", f->desc->name,
		f->desc->ninputs, f->desc->noutputs);
	for (i=0;i<f->desc->ninputs;i++) {
		if (f->inputs[i]!=NULL) ms_warning("filter: %s in[%i]=%i", f->desc->name,
			i, f->inputs[i]->q.q_mcount);
	}
	for (i=0;i<f->desc->noutputs;i++) {
		if (f->outputs[i]!=NULL) ms_warning("filter: %s out[%i]=%i", f->desc->name,
			i, f->outputs[i]->q.q_mcount);
	}
	return 0;
}

static MSFilterMethod methods[]={
	{	MS_FILTER_ADD_FMTP		,	dec_add_fmtp	},
	{	MS_FILTER_GET_STATISTICS, get_statistics },
	{		0		,		NULL			}
};

#ifdef _MSC_VER

MSFilterDesc ms_h263_dec_desc={
	MS_H263_DEC_ID,
	"MSH263Dec",
	N_("A H.263 decoder using android opencore"),
	MS_FILTER_DECODER,
	"H263-1998",
	1,
	0,
	dec_h263p_init,
	dec_preprocess,
	dec_process,
	dec_postprocess,
	dec_uninit,
	methods
};

MSFilterDesc ms_h264_dec_desc={
        MS_FILTER_PLUGIN_ID, //MS_H264_DEC_ID,
	"MSH264Dec",
	N_("A H.264 decoder using android opencore"),
	MS_FILTER_DECODER,
	"H264",
	1,
	0,
	dec_h264_init,
	dec_preprocess,
	dec_process,
	dec_postprocess,
	dec_uninit,
	methods
};

MSFilterDesc ms_h263_old_dec_desc={
	MS_H263_OLD_DEC_ID,
	"MSH263OldDec",
	N_("A H.263 decoder using android opencore"),
	MS_FILTER_DECODER,
	"H263",
	1,
	0,
	dec_h263_init,
	dec_preprocess,
	dec_process,
	dec_postprocess,
	dec_uninit,
	methods
};


MSFilterDesc ms_mpeg4_dec_desc={
	MS_MPEG4_DEC_ID,
	"MSMpeg4Dec",
	N_("A MPEG4 decoder using android opencore"),
	MS_FILTER_DECODER,
	"MP4V-ES",
	1,
	0,
	dec_mpeg4_init,
	dec_preprocess,
	dec_process,
	dec_postprocess,
	dec_uninit,
	methods
};

#else

MSFilterDesc ms_h263_dec_desc={
	.id=MS_H263_DEC_ID,
	.name="MSH263Dec",
	.text=N_("A H.263 decoder using android opencore"),
	.category=MS_FILTER_DECODER,
	.enc_fmt="H263-1998",
	.ninputs=1,
	.noutputs=0,
	.init=dec_h263p_init,
	.preprocess=dec_preprocess,
	.process=dec_process,
	.postprocess=dec_postprocess,
	.uninit=dec_uninit,
	.methods= methods
};

MSFilterDesc ms_h264_dec_desc={
        .id=MS_FILTER_PLUGIN_ID, //MS_H264_DEC_ID,
	.name="MSH264Dec",
	.text=N_("A H.264 decoder using android opencore"),
	.category=MS_FILTER_DECODER,
	.enc_fmt="H264",
	.ninputs=1,
	.noutputs=0,
	.init=dec_h264_init,
	.preprocess=dec_preprocess,
	.process=dec_process,
	.postprocess=dec_postprocess,
	.uninit=dec_uninit,
	.methods= methods
};

MSFilterDesc ms_h263_old_dec_desc={
	.id=MS_H263_OLD_DEC_ID,
	.name="MSH263OldDec",
	.text=N_("A H.263 decoder using android opencore"),
	.category=MS_FILTER_DECODER,
	.enc_fmt="H263",
	.ninputs=1,
	.noutputs=0,
	.init=dec_h263_init,
	.preprocess=dec_preprocess,
	.process=dec_process,
	.postprocess=dec_postprocess,
	.uninit=dec_uninit,
	.methods= methods
};


MSFilterDesc ms_mpeg4_dec_desc={
	.id=MS_MPEG4_DEC_ID,
	.name="MSMpeg4Dec",
	.text="A MPEG4 decoder using android opencore",
	.category=MS_FILTER_DECODER,
	.enc_fmt="MP4V-ES",
	.ninputs=1,
	.noutputs=0,
	.init=dec_mpeg4_init,
	.preprocess=dec_preprocess,
	.process=dec_process,
	.postprocess=dec_postprocess,
	.uninit=dec_uninit,
	.methods= methods
};

#endif

MS_FILTER_DESC_EXPORT(ms_mpeg4_dec_desc)
MS_FILTER_DESC_EXPORT(ms_h264_dec_desc)
MS_FILTER_DESC_EXPORT(ms_h263_dec_desc)
MS_FILTER_DESC_EXPORT(ms_h263_old_dec_desc)
