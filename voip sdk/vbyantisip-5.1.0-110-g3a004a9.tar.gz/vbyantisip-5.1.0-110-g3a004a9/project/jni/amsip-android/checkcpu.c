/*
  amsip is a SIP library for softphone (SIP -rfc3261-)
  Copyright (C) 2003,2004,2005,2006,2007,2008,2009,2010  Aymeric MOIZARD - <amoizard@gmail.com>
*/

#include <string.h>
#include <jni.h>

#include <cpu-features.h>

static jint
Java_com_antisip_amsip_CheckCpu_getcpufamily( JNIEnv* env, jobject thiz)
{
  //ANDROID_CPU_FAMILY_ARM
  return android_getCpuFamily();
}

static jint
Java_com_antisip_amsip_CheckCpu_getcpufeatures( JNIEnv* env, jobject thiz)
{
  if (android_getCpuFamily()==ANDROID_CPU_FAMILY_ARM)
    {
      //contains neon? ANDROID_CPU_ARM_FEATURE_NEON
      return android_getCpuFeatures();
    }
  return -1;
}

static const JNINativeMethod methods[] = {
  {"getcpufamily",  "()I", (void*)Java_com_antisip_amsip_CheckCpu_getcpufamily},
  {"getcpufeatures",  "()I", (void*)Java_com_antisip_amsip_CheckCpu_getcpufeatures},
};

static const char* const kClassPathName = "com/antisip/amsip/CheckCpu";

static int register_methods(JNIEnv* env)
{
  jclass clazz;

  clazz = (*env)->FindClass(env, kClassPathName);
  if (clazz == NULL) {
    //printf("Native registration unable to find class '%s'\n", kClassPathName);
    return -1;
  }
  return (*env)->RegisterNatives(env, clazz, methods, 2);
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
  JNIEnv* env;
  jint ijvm;
  ijvm = (*vm)->GetEnv(vm, (void**)&env, JNI_VERSION_1_4);

  register_methods(env);

  return(JNI_VERSION_1_4);
}
