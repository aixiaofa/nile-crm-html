/*
  amsip is a SIP library for softphone (SIP -rfc3261-)
  Copyright (C) 2003,2004,2005,2006,2007,2008,2009,2010  Aymeric MOIZARD - <amoizard@gmail.com>
*/

#ifdef HAVE_CONFIG_H
#include "mediastreamer-config.h"
#endif

#ifdef VIDEO_ENABLED

#include "mediastreamer2/msfilter.h"
#include "mediastreamer2/msvideo.h"

typedef struct PixConvState{
	MSPicture outbuf;
	mblk_t *yuv_msg;
	struct MSScalerContext *sws_ctx;
	MSVideoSize size;
	MSVideoSize in_size;
	MSPixFmt in_fmt;
	MSPixFmt out_fmt;
	int reset;
}PixConvState;

static void pixconv_init(MSFilter *f){
	PixConvState *s=(PixConvState *)ms_new(PixConvState,1);
	s->yuv_msg=NULL;
	s->size.width = MS_VIDEO_SIZE_CIF_W;
	s->size.height = MS_VIDEO_SIZE_CIF_H;
	s->in_size.width = MS_VIDEO_SIZE_CIF_W;
	s->in_size.height = MS_VIDEO_SIZE_CIF_H;
	s->in_fmt=MS_YUV420P;
	s->out_fmt=MS_YUV420P;
	s->sws_ctx=NULL;
	s->reset=0;
	f->data=s;
}

static void pixconv_uninit(MSFilter *f){
	PixConvState *s=(PixConvState*)f->data;
	if (s->sws_ctx!=NULL){
		ms_video_scalercontext_free(s->sws_ctx);
		s->sws_ctx=NULL;
	}
	if (s->yuv_msg!=NULL) freemsg(s->yuv_msg);
	ms_free(s);
}

static mblk_t * pixconv_alloc_mblk(PixConvState *s){
	if (s->yuv_msg!=NULL){
		int ref=s->yuv_msg->b_datap->db_ref;
		if (ref==1){
			return dupmsg(s->yuv_msg);
		}else{
			/*the last msg is still referenced by somebody else*/
			ms_message("Somebody still retaining yuv buffer (ref=%i)",ref);
			freemsg(s->yuv_msg);
			s->yuv_msg=NULL;
		}
	}
	s->yuv_msg=yuv_buf_alloc(&s->outbuf,s->size.width,s->size.height);
	return dupmsg(s->yuv_msg);
}

static void pixconv_process(MSFilter *f){
  mblk_t *im,*om;
  PixConvState *s=(PixConvState*)f->data;
  
  ms_filter_lock(f);
  
  if (s->reset==1)
    {
      /* live change happen on incoming data */
      if (s->sws_ctx!=NULL){
	ms_video_scalercontext_free(s->sws_ctx);
	s->sws_ctx=NULL;
      }
      if (s->yuv_msg!=NULL) freemsg(s->yuv_msg);
      s->yuv_msg=NULL;
      ms_queue_flush(f->inputs[0]);
      s->reset=0;
    }
  
  while((im=ms_queue_get(f->inputs[0]))!=NULL){
    short w = mblk_get_video_width(im);
    short h = mblk_get_video_height(im);
    MSPixFmt in_fmt = mblk_get_video_format(im);
    
    if (in_fmt==s->out_fmt && (((im)->reserved2>>3)&0x7F)==0){
      om=im;
      if (om!=NULL) ms_queue_put(f->outputs[0],om);
    }else{
      
      MSPicture inbuf;
      int rotation=0;
      inbuf.w=0;
      inbuf.h=0;
      
      if (s->in_fmt!=in_fmt || w!=s->in_size.width || h!=s->in_size.height)
	{
	  /* restart */
	  if (s->sws_ctx!=NULL){
	    ms_video_scalercontext_free(s->sws_ctx);
	    s->sws_ctx=NULL;
	  }
	  if (s->yuv_msg!=NULL){
	    freemsg(s->yuv_msg);
	    s->yuv_msg=NULL;
	  }
	  s->in_size.width=w;
	  s->in_size.height=h;
	  s->in_fmt=in_fmt;

	  /* we want to KEEP the same size - or not too high image*/
	  s->size.width = w;
	  s->size.height = h;
	  while (s->size.width>MS_VIDEO_SIZE_VGA_W) {
	    s->size.width = s->size.width/2;
	    s->size.height = s->size.height/2;
	  }
	}

      if (s->in_size.width==0 || s->in_size.height==0)
	{
	  freemsg(im);
	  continue;
	}
      yuv_buf_init_with_format(&inbuf,s->in_fmt,s->in_size.width,s->in_size.height, im->b_rptr);

      
      om=pixconv_alloc_mblk(s);
      if (s->sws_ctx==NULL){
        s->sws_ctx=ms_video_scalercontext_init(s->in_size.width,s->in_size.height,
                                               s->in_fmt,s->size.width,s->size.height,
                                               s->out_fmt,MS_YUVFAST,
                                               NULL, NULL, NULL);
        
        ms_message("MSAndroidPixConv: conversion from %i:%ix%i -> %i:%ix%i. (size=%i)",
                   s->in_fmt,
		   s->in_size.width,s->in_size.height,
                   s->out_fmt,
                   s->size.width,s->size.height,
                   msgdsize(im));
        //freemsg(om);
        //freemsg(im);
        //continue;
      }
      if (s->in_fmt==MS_RGB24_REV){
				inbuf.planes[0]+=inbuf.strides[0]*(s->size.height-1);
        inbuf.strides[0]=-inbuf.strides[0];
      }
      if (ms_video_scalercontext_convert(s->sws_ctx,inbuf.planes,inbuf.strides, 0,
                                         s->in_size.height, s->outbuf.planes, s->outbuf.strides)<0){
        ms_error("MSAndroidPixConv: Error in ms_video_scalercontext_convert().");
        freemsg(om);
        freemsg(im);
        continue;
      }
      rotation = (((im)->reserved2>>3)&0x7F);
      freemsg(im);
      
      if (s->out_fmt==MS_YUV420P && (rotation==90||rotation==1))
      {
        MSPicture rotyuvbuf;
        int srcW=s->size.height;
        int srcH=s->size.width;
        mblk_t *out=yuv_buf_alloc(&rotyuvbuf,srcW,srcH);
        inbuf.w=0;
        inbuf.h=0;
        yuv_buf_init_with_format(&inbuf, s->out_fmt,s->size.width,s->size.height, om->b_rptr);
        ms_yuv_buf_rotate(&inbuf,&rotyuvbuf, 90);
        
        //ms_message("MSAndroidPixConv: rotation from %i:%ix%i -> %i:%ix%i.",
        //           s->in_fmt,
        //           s->size.width,s->size.height,
        //           s->out_fmt,
        //           srcW,srcH);
        freemsg(om);
        if (out!=NULL) ms_queue_put(f->outputs[0],out);
      } else if (s->out_fmt==MS_YUV420P && rotation==2) {
        MSPicture rotyuvbuf;
        int srcW=s->size.width;
        int srcH=s->size.height;
        mblk_t *out=yuv_buf_alloc(&rotyuvbuf,srcW,srcH);
        inbuf.w=0;
        inbuf.h=0;
        yuv_buf_init_with_format(&inbuf, s->out_fmt,s->size.width,s->size.height, om->b_rptr);
        ms_yuv_buf_rotate(&inbuf,&rotyuvbuf, 180);
        
        freemsg(om);
        if (out!=NULL) ms_queue_put(f->outputs[0],out);
      } else if (s->out_fmt==MS_YUV420P && rotation==3) {
        MSPicture rotyuvbuf;
        int srcW=s->size.height;
        int srcH=s->size.width;
        mblk_t *out=yuv_buf_alloc(&rotyuvbuf,srcW,srcH);
        inbuf.w=0;
        inbuf.h=0;
        yuv_buf_init_with_format(&inbuf, s->out_fmt,s->size.width,s->size.height, om->b_rptr);

        
        ms_yuv_buf_rotate(&inbuf,&rotyuvbuf, 270);
        
        freemsg(om);
        if (out!=NULL) ms_queue_put(f->outputs[0],out);
      } else {
        if (om!=NULL) ms_queue_put(f->outputs[0],om);
      }
      
		}
	}
	ms_filter_unlock(f);
}

static int pixconv_set_vsize(MSFilter *f, void*arg){
	PixConvState *s=(PixConvState*)f->data;
	MSVideoSize vsize=*(MSVideoSize*)arg;
	ms_filter_lock(f);
	if (vsize.width!=s->size.width || vsize.height!=s->size.height)
	{
		s->reset=1;
	}
	s->size=*(MSVideoSize*)arg;
	ms_filter_unlock(f);
	return 0;
}

static int pixconv_set_pixfmt(MSFilter *f, void *arg){
	MSPixFmt fmt=*(MSPixFmt*)arg;
	PixConvState *s=(PixConvState*)f->data;
	ms_filter_lock(f);
	if (s->in_fmt!=fmt)
	{
		s->reset=1;
	}
	s->in_fmt=fmt;
	ms_filter_unlock(f);
	return 0;
}

static int get_statistics(MSFilter *f, void *arg){
	int i;
	ms_warning("filter: %s[%i->%i]", f->desc->name,
		f->desc->ninputs, f->desc->noutputs);
	for (i=0;i<f->desc->ninputs;i++) {
		if (f->inputs[i]!=NULL) ms_warning("filter: %s in[%i]=%i", f->desc->name,
			i, f->inputs[i]->q.q_mcount);
	}
	for (i=0;i<f->desc->noutputs;i++) {
		if (f->outputs[i]!=NULL) ms_warning("filter: %s out[%i]=%i", f->desc->name,
			i, f->outputs[i]->q.q_mcount);
	}
	return 0;
}

static MSFilterMethod methods[]={
	{	MS_FILTER_SET_VIDEO_SIZE, pixconv_set_vsize	},
	{	MS_FILTER_SET_PIX_FMT,	pixconv_set_pixfmt	},
	{	MS_FILTER_GET_STATISTICS, get_statistics },
	{	0	,	NULL }
};

#ifdef _MSC_VER

MSFilterDesc ms_androidpix_conv_desc={
	MS_PIX_CONV_ID,
	"MSAndroidPixConv",
	N_("A pixel format converter for android"),
	MS_FILTER_OTHER,
	NULL,
	1,
	1,
	pixconv_init,
	NULL,
	pixconv_process,
	NULL,
	pixconv_uninit,
	methods
};

#else

MSFilterDesc ms_androidpix_conv_desc={
	.id=MS_PIX_CONV_ID,
	.name="MSAndroidPixConv",
	.text=N_("A pixel format converter for android"),
	.category=MS_FILTER_OTHER,
	.ninputs=1,
	.noutputs=1,
	.init=pixconv_init,
	.process=pixconv_process,
	.uninit=pixconv_uninit,
	.methods=methods
};

#endif

#ifdef _MSC_VER
#define MS_PLUGIN_DECLARE(type) __declspec(dllexport) type
#else
#define MS_PLUGIN_DECLARE(type) type
#endif

MS_PLUGIN_DECLARE(void) libmsandroidpixconv_init()
{
  ms_filter_register(&ms_androidpix_conv_desc);
}

#endif

