#!/bin/sh

cd project/jni/external/
svn checkout http://webrtc.googlecode.com/svn/trunk/ webrtc

mv webrtc/src/common_audio/signal_processing/complex_bit_reverse_arm.s webrtc/src/common_audio/signal_processing/complex_bit_reverse_arm.S
mv webrtc/src/common_audio/signal_processing/cross_correlation_neon.s webrtc/src/common_audio/signal_processing/cross_correlation_neon.S
mv webrtc/src/common_audio/signal_processing/downsample_fast_neon.s webrtc/src/common_audio/signal_processing/downsample_fast_neon.S
mv webrtc/src/common_audio/signal_processing/filter_ar_fast_q12_armv7.s webrtc/src/common_audio/signal_processing/filter_ar_fast_q12_armv7.S
mv webrtc/src/common_audio/signal_processing/min_max_operations_neon.s webrtc/src/common_audio/signal_processing/min_max_operations_neon.S
mv webrtc/src/common_audio/signal_processing/spl_sqrt_floor.s webrtc/src/common_audio/signal_processing/spl_sqrt_floor.S
mv webrtc/src/common_audio/signal_processing/vector_scaling_operations_neon.s webrtc/src/common_audio/signal_processing/vector_scaling_operations_neon.S
