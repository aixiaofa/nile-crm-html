#!/bin/bash -

# On Motorola Milestone, the "installer" doesn't
# install library from "libs/armeabi-v7a".
# However, the CPU is a "v7a" version and has neon
# support.

# To dismiss the issue, we copy the "v7a" libs into
# the "libs/armeabi/" directory so we will be able
# to access them after installation.

# side note about ICS bug up to 4.0.3, the library loader
# will load the library from "armeabi" instead of
# "armeabi-v7a": we don't mind here because the binary
# will be the "v7a" version even in libs/armeabi/.

# In all case, the checkcpu.c and CheckCpu.java code
# is responsible for trying to load the correct library
# name depending on architecture and neon support.

cp libs/armeabi-v7a/libvbyantisip* libs/armeabi/

