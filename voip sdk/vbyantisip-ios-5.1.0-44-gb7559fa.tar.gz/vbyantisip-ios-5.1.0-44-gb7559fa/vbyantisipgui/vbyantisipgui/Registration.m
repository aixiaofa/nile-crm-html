//
//  Registration.m
//  iamsip
//
//  Created by Aymeric MOIZARD on 10/04/11.
//  Copyright 2011 antisip. All rights reserved.
//

#import "Registration.h"


@implementation Registration

@synthesize rid;
@synthesize code;
@synthesize reason;

@end
