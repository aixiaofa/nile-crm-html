//
//  SqliteContactHelper.m
//  vbyantisipgui
//
//  Created by Aymeric Moizard on 4/10/12.
//  Copyright (c) 2012 antisip. All rights reserved.
//

#import "SqliteContactHelper.h"

@implementation SqliteContactHelper

- (int) open_database
{
  NSString *docsDir;
  NSArray *dirPaths;
  
  // Get the documents directory
  dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
  
  docsDir = [dirPaths objectAtIndex:0];
  
  // Build the path to the database file
  databasePath = [[NSString alloc] initWithString: [docsDir stringByAppendingPathComponent: @"contacts.db"]];
  
  NSFileManager *filemgr = [NSFileManager defaultManager];
  
  if ([filemgr fileExistsAtPath: databasePath ] == NO)
  {
    const char *dbpath = [databasePath UTF8String];
    
    if (sqlite3_open(dbpath, &myFavoriteContactDb) != SQLITE_OK)
    {
      NSLog(@"sqlite: database not opened");
      return -1;
    }
      
    char *errMsg;
    const char *sql_stmt = "CREATE TABLE IF NOT EXISTS CONTACTS (ID INTEGER PRIMARY KEY AUTOINCREMENT, FIRSTNAME TEXT, LASTNAME TEXT)";
    
    if (sqlite3_exec(myFavoriteContactDb, sql_stmt, NULL, NULL, &errMsg) != SQLITE_OK)
    {
      //status.text = @"Failed to create table";
      NSLog(@"sqlite: database CONTACTS not created");
      return -1;
    }
      
    
    sql_stmt = "CREATE TABLE IF NOT EXISTS NUMBERS (ID INTEGER PRIMARY KEY AUTOINCREMENT, CONTACTID ID, NUMBER TEXT, PHONETYPE TEXT)";

    if (sqlite3_exec(myFavoriteContactDb, sql_stmt, NULL, NULL, &errMsg) != SQLITE_OK)
    {
      //status.text = @"Failed to create table";
      NSLog(@"sqlite: database NUMBERS not created");
      return -1;
    }
      
    sqlite3_close(myFavoriteContactDb);
  }
  
  [filemgr release];
  return 0;
}

- (int) insert_contact:(ContactEntry *)contact
{
  sqlite3_stmt    *statement;
  
  const char *dbpath = [databasePath UTF8String];
  
  if (sqlite3_open(dbpath, &myFavoriteContactDb) != SQLITE_OK)
  {
    NSLog(@"sqlite: database not opened");
    return -1;
  }
  
  NSString *insertSQL = [NSString stringWithFormat: @"INSERT INTO CONTACTS (lastname, firstname) VALUES (\"%@\", \"%@\")", contact.lastname, contact.firstname];
  
  const char *insert_stmt = [insertSQL UTF8String];
  
  sqlite3_prepare_v2(myFavoriteContactDb, insert_stmt, -1, &statement, NULL);
  if (sqlite3_step(statement) != SQLITE_DONE)
  {
    NSLog(@"Failed to add contact");
    sqlite3_finalize(statement);
    sqlite3_close(myFavoriteContactDb);
    return -1;
  }
  sqlite3_finalize(statement);

  //get contactid
  NSString *querySQL = [NSString stringWithFormat: @"SELECT id FROM CONTACTS WHERE lastname=\"%@\" AND firstname=\"%@\" LIMIT 1", contact.lastname, contact.firstname];
  
  const char *query_stmt = [querySQL UTF8String];
  if (sqlite3_prepare_v2(myFavoriteContactDb, query_stmt, -1, &statement, NULL) != SQLITE_OK)
  {
    NSLog(@"sqlite: database error");
    sqlite3_finalize(statement);
    sqlite3_close(myFavoriteContactDb);
    return -1;
  }
  
  if (sqlite3_step(statement) != SQLITE_ROW)
  {
    NSLog(@"sqlite: database error");
    sqlite3_finalize(statement);
    sqlite3_close(myFavoriteContactDb);
    return -1;
  }

  int contactid = sqlite3_column_int(statement, 0);
  sqlite3_finalize(statement);
  
  for( SipNumber *number in contact.phone_numbers)
  {
    insertSQL = [NSString stringWithFormat: @"INSERT INTO NUMBERS (contactid, number, phonetype) VALUES (%i, \"%@\", \"%@\")", contactid, number.phone_number, number.phone_type];
    insert_stmt = [insertSQL UTF8String];
    sqlite3_prepare_v2(myFavoriteContactDb, insert_stmt, -1, &statement, NULL);
    if (sqlite3_step(statement) != SQLITE_DONE)
    {
      NSLog(@"Failed to add contact");
      sqlite3_finalize(statement);
      sqlite3_close(myFavoriteContactDb);
      return -1;
    }
    sqlite3_finalize(statement);
  }
  
  
  sqlite3_close(myFavoriteContactDb);
  return 0;
}

- (int) remove_contact:(ContactEntry *)contact
{
  sqlite3_stmt    *statement;
  
  const char *dbpath = [databasePath UTF8String];
  
  if (sqlite3_open(dbpath, &myFavoriteContactDb) != SQLITE_OK)
  {
    NSLog(@"sqlite: database not opened");
    return -1;
  }
  
  //get contactid
  NSString *querySQL = [NSString stringWithFormat: @"SELECT id FROM CONTACTS WHERE lastname=\"%@\" AND firstname=\"%@\" LIMIT 1", contact.lastname, contact.firstname];
  
  const char *query_stmt = [querySQL UTF8String];
  if (sqlite3_prepare_v2(myFavoriteContactDb, query_stmt, -1, &statement, NULL) != SQLITE_OK)
  {
    NSLog(@"sqlite: database error");
    sqlite3_finalize(statement);
    sqlite3_close(myFavoriteContactDb);
    return -1;
  }
  
  if (sqlite3_step(statement) != SQLITE_ROW)
  {
    NSLog(@"sqlite: database error");
    sqlite3_finalize(statement);
    sqlite3_close(myFavoriteContactDb);
    return -1;
  }
  
  int contactid = sqlite3_column_int(statement, 0);
  sqlite3_finalize(statement);
 
  
  //remove all numbers:
  querySQL = [NSString stringWithFormat: @"DELETE FROM NUMBERS WHERE contactid = ?"];
  query_stmt = [querySQL UTF8String];
  if (sqlite3_prepare_v2(myFavoriteContactDb, query_stmt, -1, &statement, NULL) != SQLITE_OK)
  {
    NSLog(@"sqlite: database error");
    sqlite3_finalize(statement);
    sqlite3_close(myFavoriteContactDb);
    return -1;
  }

  sqlite3_bind_int(statement, 1, contactid);

  if (sqlite3_step(statement) != SQLITE_DONE)
  {
    NSLog(@"sqlite: failed to remove numbers");
  }
  sqlite3_finalize(statement);

  //remove all numbers:
  querySQL = [NSString stringWithFormat: @"DELETE FROM CONTACTS WHERE id = ?"];
  query_stmt = [querySQL UTF8String];
  if (sqlite3_prepare_v2(myFavoriteContactDb, query_stmt, -1, &statement, NULL) != SQLITE_OK)
  {
    NSLog(@"sqlite: database error");
    sqlite3_finalize(statement);
    sqlite3_close(myFavoriteContactDb);
    return -1;
  }
  
  sqlite3_bind_int(statement, 1, contactid);
  
  if (sqlite3_step(statement) != SQLITE_DONE)
  {
    NSLog(@"sqlite: failed to remove contact");
    sqlite3_finalize(statement);
    sqlite3_close(myFavoriteContactDb);
    return -1;
  }
  sqlite3_finalize(statement);

  sqlite3_close(myFavoriteContactDb);
  return 0;
}

- (int) load_numbers:(ContactEntry*)contact withId:(int)contactid
{
  sqlite3_stmt    *statement;
  NSString *querySQL = [NSString stringWithFormat: @"SELECT number, phonetype FROM NUMBERS WHERE contactid=\"%i\"", contactid];
  
  const char *query_stmt = [querySQL UTF8String];
  
  if (sqlite3_prepare_v2(myFavoriteContactDb, query_stmt, -1, &statement, NULL) != SQLITE_OK)
  {
    NSLog(@"sqlite: database error");
    sqlite3_finalize(statement);
    return -1;
  }
  
  while (sqlite3_step(statement) == SQLITE_ROW)
  {
    SipNumber *sip_number = [SipNumber alloc];
    const char *number = (const char *) sqlite3_column_text(statement, 0);
    const char *phonetype = (const char *) sqlite3_column_text(statement, 1);
    
    [sip_number setPhone_number: [NSString stringWithUTF8String:number]];
    [sip_number setPhone_type: [NSString stringWithUTF8String:phonetype]];
    [contact.phone_numbers addObject:sip_number];
  }
  
  sqlite3_finalize(statement);
  return 0;
}

- (int) load_contacts:(NSMutableArray*)arrayContact
{
  sqlite3_stmt    *statement;
  
  const char *dbpath = [databasePath UTF8String];
  
  if (sqlite3_open(dbpath, &myFavoriteContactDb) != SQLITE_OK)
  {
    NSLog(@"sqlite: database not opened");
    return -1;
  }
  
  NSString *querySQL = [NSString stringWithFormat: @"SELECT id, lastname, firstname FROM CONTACTS"];
  
  const char *query_stmt = [querySQL UTF8String];
  
  if (sqlite3_prepare_v2(myFavoriteContactDb, query_stmt, -1, &statement, NULL) != SQLITE_OK)
  {
    NSLog(@"sqlite: database error");
    sqlite3_finalize(statement);
    sqlite3_close(myFavoriteContactDb);
    return -1;
  }

  while (sqlite3_step(statement) == SQLITE_ROW)
  {
    ContactEntry *contact = [[ContactEntry alloc] init];
    const char *firstname = (const char *) sqlite3_column_text(statement, 2);
    const char *lastname = (const char *) sqlite3_column_text(statement, 1);
    if (firstname)
      [contact setFirstname: [NSString stringWithUTF8String:firstname]];
    if (lastname)
      [contact setLastname: [NSString stringWithUTF8String:lastname]];
    
    [self load_numbers:contact withId:sqlite3_column_int(statement, 0)];
    [arrayContact addObject:contact];
  }
  
  sqlite3_finalize(statement);
  sqlite3_close(myFavoriteContactDb);
  return 0;
}

@end
