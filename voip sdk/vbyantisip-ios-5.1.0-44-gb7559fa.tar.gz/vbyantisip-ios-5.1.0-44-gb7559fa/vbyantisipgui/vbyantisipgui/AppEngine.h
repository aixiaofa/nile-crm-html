//
//  AppEngine.h
//  AppEngine
//
//  Created by Aymeric MOIZARD on 30/10/09.
//  Copyright 2009 antisip. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <AddressBook/AddressBook.h>
#import "iAudioPlayer.h"

#import "FileTransfer.h"
#import "Call.h"
#import "Registration.h"

#import "SqliteHistoryHelper.h"

@interface AppEngine : NSObject {

  @private
  
	NSString *userAgent;
	id engineDelegates;
	id registrationDelegates;

	Registration *registration;
	NSMutableDictionary *call_list;
  NSMutableDictionary *filetransfer_list;

	iAudioPlayer *iAudioPlayerApp;
	
	BOOL thread_start;
	BOOL thread_started;

  SqliteHistoryHelper *myHistoryDb;
}

@property (nonatomic, retain) NSString *userAgent;
@property (nonatomic, assign) id engineDelegates;
@property (nonatomic, assign) id registrationDelegates;

- (void) addCallDelegate:(id)_adelegate;
- (void) removeCallDelegate:(id)_adelegate;

- (void) removeRegistrationDelegate:(id)_adelegate;
- (void) addRegistrationDelegate:(id)_adelegate;

- (int) getNumberOfActiveCalls;

-(int)amsip_start:(NSString*)target_user withReferedby_did:(int)referedby_did;
-(int)amsip_answer:(int)code forCall:(Call*)pCall;
-(int)amsip_stop:(int)code forCall:(Call*)pCall;

-(int)amsip_start_file_transfer:(NSString*)target_user fileName:(NSString*)fileName fileNameShort:(NSString*)fileName_short;
-(int)amsip_answer_file_transfer:(int)code forFileTransfer:(FileTransfer*)pFileTransfer;
-(int)amsip_stop_file_transfer:(int)code forFileTransfer:(FileTransfer*)pFileTransfer;

-(void)initialize;
-(BOOL)isConfigured;
-(BOOL)isStarted;
-(void)stop;
-(void)start;
-(void)refreshRegistration;

@end

extern AppEngine *gAppEngine;


@protocol EngineDelegate
@optional
- (void)onCallNew:(Call *)call;
- (void)onCallRemove:(Call *)call;
- (void)onCallExist:(Call *)call;

- (void)onFileTransferNew:(FileTransfer *)fileTransfer;
- (void)onFileTransferRemove:(FileTransfer *)fileTransfer;
- (void)onFileTransferExist:(FileTransfer *)fileTransfer;


@end
