//
//  ContactEntry.m
//  vbyantisipgui
//
//  Created by Aymeric Moizard on 4/9/12.
//  Copyright (c) 2012 antisip. All rights reserved.
//

#import "ContactEntry.h"

@implementation SipNumber

@synthesize phone_type;
@synthesize phone_number;

@end

@implementation ContactEntry

@synthesize firstname;
@synthesize lastname;
@synthesize phone_numbers;

-(id)init
{
  self = [super init];
  if (self) {
    // Initialization code here.
    phone_numbers = [[NSMutableArray arrayWithObjects:nil] retain];
    firstname = @"";
    lastname = @"";
  }
  
  return self;
}
@end
