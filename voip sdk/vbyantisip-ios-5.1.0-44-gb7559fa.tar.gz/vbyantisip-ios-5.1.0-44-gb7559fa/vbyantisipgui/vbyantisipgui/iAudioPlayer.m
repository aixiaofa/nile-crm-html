//
//  iAudioPlayer.h
//  AppEngine
//
//  Created by Aymeric MOIZARD on 30/10/09.
//  Copyright 2009 antisip. All rights reserved.
//

#import "iAudioPlayer.h"


@implementation iAudioPlayer

@synthesize _player;

- (id)init{
	_player = nil;
	return self;
}

- (void) playOnce:(NSString *)filename {
	if (_player != nil)
	{
		[_player stop];
    _player = nil;
	}
	
	NSURL *fileURL = [[NSURL alloc] initFileURLWithPath: filename];
	_player = [[AVAudioPlayer alloc] initWithContentsOfURL:fileURL error:nil];
	if (_player)
	{
		[_player setNumberOfLoops:1];
		if ([_player play])
		{
			_player.delegate = self;
		}
		else
			NSLog(@"Could not play %@\n", self._player.url);
	}
	[fileURL release];
}

- (void) play:(NSString *)filename {
	if (_player != nil)
	{
		/* already playing? */
    return;
	}
	
	NSURL *fileURL = [[NSURL alloc] initFileURLWithPath: filename];
	_player = [[AVAudioPlayer alloc] initWithContentsOfURL:fileURL error:nil];
	if (_player)
	{
    [self enable_default_audio];

		[_player setNumberOfLoops:-1];
		if ([_player play])
		{
      [_player setDelegate:self];
		}
		else
			NSLog(@"Could not play %@\n", self._player.url);
    //UInt32 audioRouteOverride = kAudioSessionOverrideAudioRoute_Speaker;
    //AudioSessionSetProperty (kAudioSessionProperty_OverrideAudioRoute,
    //                         sizeof (audioRouteOverride),
    //                         &audioRouteOverride);
    NSLog(@"Player started");
	}
	[fileURL release];
}

- (void) stop {
	if (_player != nil)
	{
		[_player stop];
		_player = nil;
  }
  
  NSLog(@"Player stopped (stop)");
}

- (void) stop_and_enable_default_mode {
	if (_player != nil)
	{
		[_player stop];
		_player = nil;
  }
  
  // if called immediately, a red bar notifying about active audio session appears
  dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
      [self enable_default_audio];
      NSLog(@"Player stopped (stop_and_enable_default_mode)");
    });


  NSLog(@"Player stopped (stop_and_enable_default_mode)");
}

- (void) enable_default_audio {
  NSError *setError = nil;
  
  AVAudioSession *audioSession = [AVAudioSession sharedInstance];
  
  if ([[audioSession category] isEqualToString:AVAudioSessionCategoryPlayback]
      && [[audioSession mode] isEqualToString:AVAudioSessionModeDefault]) {
    NSLog(@"Audio Category and mode are correct");
  } else {
    [audioSession setActive: NO error: nil];
    if (![[audioSession category] isEqualToString:AVAudioSessionCategoryPlayback])
      [audioSession setCategory:AVAudioSessionCategoryPlayback error: &setError];
    if (![[audioSession mode] isEqualToString:AVAudioSessionModeDefault])
      if ([AVAudioSession instancesRespondToSelector: @selector (setMode:error:)]) {
        [audioSession setMode:AVAudioSessionModeDefault error:&setError];
      }
    [audioSession setActive: YES error: nil];
  }
}

- (void) enable_voip_audio {
  
  /* if we start audio mode, we don't want any more the ringer */
	if (_player != nil)
	{
		[_player stop];
		_player = nil;
  }
  
  NSLog(@"Player stopped (enable_voip_audio)");
  NSLog(@"Set Audio Category and Audio Mode");
  NSError *setError = nil;
  
  AVAudioSession *audioSession = [AVAudioSession sharedInstance];

  if ([[audioSession category] isEqualToString:AVAudioSessionCategoryPlayAndRecord]
      && [[audioSession mode] isEqualToString:AVAudioSessionModeVoiceChat]) {
    NSLog(@"Audio Category and mode are correct");
  } else {
    [audioSession setActive: NO error: nil];
    if (![[audioSession category] isEqualToString:AVAudioSessionCategoryPlayAndRecord])
      [audioSession setCategory:AVAudioSessionCategoryPlayAndRecord error: &setError];
    if (![[audioSession mode] isEqualToString:AVAudioSessionModeVoiceChat])
      if ([AVAudioSession instancesRespondToSelector: @selector (setMode:error:)]) {
        [audioSession setMode:AVAudioSessionModeVoiceChat error:&setError];
      }
    [audioSession setActive: YES error: nil];
  }
  
  NSLog(@"End of Set Audio Category and Audio Mode");
}

- (void)dealloc
{
	[super dealloc];
}

#pragma mark AVAudioPlayer delegate methods

- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
	if (flag == NO)
		NSLog(@"Playback finished unsuccessfully");
	
	[player setCurrentTime:0.];
}

- (void)playerDecodeErrorDidOccur:(AVAudioPlayer *)player error:(NSError *)error
{
	NSLog(@"ERROR IN DECODE: %@\n", error);
}

// we will only get these notifications if playback was interrupted
- (void)audioPlayerBeginInterruption:(AVAudioPlayer *)player
{
	// the object has already been paused,	we just need to update UI
}

- (void)audioPlayerEndInterruption:(AVAudioPlayer *)player
{
	if ([_player play])
	{
    [_player setDelegate:self];
	}
	else
		NSLog(@"Could not play %@\n", self._player.url);
}

@end
