//  Created by Aymeric MOIZARD on 06/03/11.
//  Copyright 2011 antisip. All rights reserved.
//

#import "FileTransfer.h"
#import "MultiCastDelegate.h"

#import "AppEngine.h"

#include <amsip/am_options.h>

static struct am_bandwidth_stats band_stats;

@implementation FileTransfer

@synthesize filename;
@synthesize filename_short;
@synthesize tid;
@synthesize cid;
@synthesize did;
@synthesize from;
@synthesize to;
@synthesize oppositeNumber;
@synthesize fileTransferState;
@synthesize isIncomingFileTransfer;
@synthesize code;
@synthesize reason;
@synthesize start_date;
@synthesize end_date;
@synthesize callid;


@synthesize fileTransferDelegates;

- (id)init;
{
	memset(&band_stats, 0, sizeof(band_stats));
	
	fileTransferDelegates = [[MulticastDelegate alloc] init];
	
	tid = 0;
	cid = 0;
	did = 0;
	from = nil;
	to = nil;
	oppositeNumber = nil;

  start_date = [[NSDate alloc] init];
	return self;
}

- (int) hangup
{
	return [gAppEngine amsip_stop_file_transfer:486 forFileTransfer:self];
}

- (int) accept:(int)_code
{
	return [gAppEngine amsip_answer_file_transfer:_code forFileTransfer:self];
}

- (int) decline
{
	return [gAppEngine amsip_stop_file_transfer:603 forFileTransfer:self];
}

- (float) getUploadBandwidth
{
	int i;
	if (did<=0)
		return 0;
	memset(&band_stats, 0, sizeof(band_stats));
	i = am_session_get_audio_bandwidth(did, &band_stats);
	if (i>=0)
	{
		return band_stats.upload_rate;
	}
	return 0;
}

- (float) getDownloadBandwidth
{
	return band_stats.download_rate;
}

- (float) getPacketLossIn
{
	return -1;
}

- (float) getPacketLossOut
{
	return -1;
}


- (void) addFileTransferStateChangeListener:(id)_adelegate
{
	[fileTransferDelegates addDelegate:_adelegate];
}

- (void) removeFileTransferStateChangeListener:(id)_adelegate
{
	[fileTransferDelegates removeDelegate:_adelegate];
}

- (void) onFileTransferUpdate
{
	[fileTransferDelegates onFileTransferUpdate:self];
}

@end
