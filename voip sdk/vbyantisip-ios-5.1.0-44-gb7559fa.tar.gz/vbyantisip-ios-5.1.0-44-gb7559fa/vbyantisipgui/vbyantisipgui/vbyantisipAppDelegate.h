//
//  vbyantisipAppDelegate.h
//  AppEngine
//
//  Created by Aymeric MOIZARD on 16/10/09.
//  Copyright antisip 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

//#import "UIViewControllerCallControl.h"
//#import "UIViewControllerStatus.h"
//#import "UIViewControllerDialpad.h"

//#import "AppEngine.h"
//#import "NetworkTrackingDelegate.h"

@class Call;
@class Registration;
@class UIViewControllerVideoCallControl;

@protocol NetworkTrackingDelegate;
@protocol EngineDelegate;

@interface UITabBarController (Autorotate)
@end

@implementation UITabBarController (Autorotate)

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    UIViewController *controller = self.selectedViewController;
    if ([controller isKindOfClass:NSClassFromString(@"UINavigationController")])
        controller = [(UINavigationController *)controller visibleViewController];
  
    if ([controller isKindOfClass:NSClassFromString(@"UIViewControllerVideoCallControl")])
      return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
  return [controller shouldAutorotateToInterfaceOrientation:interfaceOrientation];
}


- (BOOL)shouldAutorotate {
  UIViewController *controller = self.selectedViewController;
  if ([controller isKindOfClass:NSClassFromString(@"UINavigationController")])
    controller = [(UINavigationController *)controller visibleViewController];

  return [controller shouldAutorotate];
}

-(NSUInteger)supportedInterfaceOrientations
{
  UIViewController *controller = self.selectedViewController;
  if ([controller isKindOfClass:NSClassFromString(@"UINavigationController")])
    controller = [(UINavigationController *)controller visibleViewController];
  
  return [controller supportedInterfaceOrientations];
}

@end

@interface vbyantisipAppDelegate : NSObject <UIApplicationDelegate, UITabBarControllerDelegate, NetworkTrackingDelegate, EngineDelegate> {
	IBOutlet UIWindow *window;
	IBOutlet UITabBarController *tabBarController;
@public
	IBOutlet UIViewController *viewControllerDialpad;
	//IBOutlet UIViewControllerCallControl *viewControllerCallControl;
	//IBOutlet UIViewControllerStatus *viewControllerStatus;
	
	
	Registration *registration;

@private
	bool isInBackground;

  long ptime;
  BOOL opus;
  BOOL silknb;
  BOOL silkwb;
	BOOL speex16k;
	BOOL g729;
	BOOL g722;
	BOOL iLBC;
	BOOL speex8k;
	BOOL gsm8k;
	BOOL pcmu;
	BOOL pcma;
	BOOL aec;
	BOOL elimiter;
	long srtp;
	BOOL naptr;
	long reginterval;
    
	BOOL vp8;
	BOOL h264;
	BOOL mp4v;
	BOOL h2631998;
	long uploadbandwidth;
	long downloadbandwidth;
}

+(void)_initialize;

-(void)dokeepAliveHandler;
-(void)stopBackgroundTask;

-(void)showCallControlView;

-(void)restartAll;

-(void)onCallNew:(Call *)call;
-(void)onCallRemove:(Call *)call;

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UITabBarController *tabBarController;
//@property (nonatomic, retain) IBOutlet UIViewControllerCallControl *viewControllerCallControl;
//@property (nonatomic, retain) IBOutlet UIViewControllerStatus *viewControllerStatus;

@property (nonatomic, copy) NSString *proxy;
@property (nonatomic, copy) NSString *login;
@property (nonatomic, copy) NSString *password;
@property (nonatomic, copy) NSString *identity;
@property (nonatomic, copy) NSString *transport;
@property (nonatomic, copy) NSString *outboundproxy;
@property (nonatomic, copy) NSString *stun;

@end
