#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface UIViewControllerAbout : UIViewController {
    IBOutlet UINavigationItem *navigationItem;
    IBOutlet UITabBarItem *tabBarItem;
    IBOutlet UIView *view;

}

+(void)_keepAtLinkTime;

@end
