#import "NetworkTrackingDelegate.h"
#import "AppEngine.h"

#import "UIViewControllerAbout.h"
#import "vbyantisipAppDelegate.h"

#include <amsip/am_options.h>

@implementation UIViewControllerAbout

+(void)_keepAtLinkTime
{
    return;
}

- (void)viewDidUnload {
  [super viewDidUnload];
}


- (void)viewDidLoad {
	[super viewDidLoad];
  self.navigationItem.title = @"Voip By Antisip";
	
	return;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}

- (BOOL)shouldAutorotate {
  
  return YES;
}

-(NSUInteger)supportedInterfaceOrientations
{
  return UIInterfaceOrientationMaskPortrait;
}

- (void)dealloc {
    [super dealloc];
}

@end
