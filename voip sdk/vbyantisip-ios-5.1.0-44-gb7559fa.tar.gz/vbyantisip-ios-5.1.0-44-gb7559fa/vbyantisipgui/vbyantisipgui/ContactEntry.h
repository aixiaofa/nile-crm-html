//
//  ContactEntry.h
//  vbyantisipgui
//
//  Created by Aymeric Moizard on 4/9/12.
//  Copyright (c) 2012 antisip. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SipNumber : NSObject {
	NSString *phone_type;
	NSString *phone_number;
}

@property (nonatomic, retain) NSString *phone_type;
@property (nonatomic, retain) NSString *phone_number;

@end

@interface ContactEntry : NSObject {
	NSString *firstname;
	NSString *lastname;
	NSMutableArray *phone_numbers;
}

@property (nonatomic, retain) NSString *firstname;
@property (nonatomic, retain) NSString *lastname;
@property (nonatomic, retain) NSMutableArray *phone_numbers;

@end
