//
//  SqliteContactHelper.h
//  vbyantisipgui
//
//  Created by Aymeric Moizard on 4/10/12.
//  Copyright (c) 2012 antisip. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ContactEntry.h"
#import "sqlite3.h"

@interface SqliteContactHelper : NSObject  {
  

@private
  sqlite3 *myFavoriteContactDb;
  NSString *databasePath;

}

- (int) open_database;
- (int) load_contacts:(NSMutableArray*)arrayContact;
- (int) insert_contact:(ContactEntry *)contact;
- (int) remove_contact:(ContactEntry *)contact;



@end
