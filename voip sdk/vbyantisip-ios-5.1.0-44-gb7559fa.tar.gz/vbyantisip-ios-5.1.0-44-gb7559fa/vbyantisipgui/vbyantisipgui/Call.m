//  Created by Aymeric MOIZARD on 06/03/11.
//  Copyright 2011 antisip. All rights reserved.
//

#import "Call.h"
#import "MultiCastDelegate.h"

#import "AppEngine.h"

#include <amsip/am_options.h>

static struct am_bandwidth_stats band_stats;

@implementation Call

@synthesize tid;
@synthesize cid;
@synthesize did;
@synthesize referedby_did;
@synthesize from;
@synthesize to;
@synthesize oppositeNumber;
@synthesize isMuted;
@synthesize isOnhold;
@synthesize callState;
@synthesize isIncomingCall;
@synthesize hasMedia;
@synthesize code;
@synthesize reason;
@synthesize start_date;
@synthesize end_date;
@synthesize callid;


@synthesize callDelegates;

- (id)init;
{
	memset(&band_stats, 0, sizeof(band_stats));
	
	callDelegates = [[MulticastDelegate alloc] init];
	
	tid = 0;
	cid = 0;
	did = 0;
	referedby_did = 0;
	from = nil;
	to = nil;
	oppositeNumber = nil;
	isMuted = false;
	isOnhold = false;
	callState = NOTSTARTED;
	isIncomingCall = false;
	hasMedia = false;

  start_date = [[NSDate alloc] init];
	return self;
}

- (int) hangup
{
	return [gAppEngine amsip_stop:486 forCall:self];
}

- (int) accept:(int)_code
{
	return [gAppEngine amsip_answer:_code forCall:self];
}

- (int) decline
{
	return [gAppEngine amsip_answer:603 forCall:self];
}

- (int) hold
{
	NSString *file = [[NSBundle mainBundle] pathForResource:@"holdmusic" ofType:@"wav"];
	if (file==nil)
		file = @"holdmusic.wav"; //cannot happen
	
	int i = am_session_hold(did, [file cStringUsingEncoding:NSUTF8StringEncoding]);

	if (i==0)
	{		
		isOnhold=true;
		isMuted=false;
		[self onCallUpdate];
	}
	
	return i;
}

- (int) unhold
{
	int i = am_session_off_hold([self did]);
	if (i==0)
	{		
		isOnhold=false;
		isMuted=false;
		[self onCallUpdate];
	}
	return i;
}

- (int) playFile:(NSString*)file
{
    int i = am_session_play_file(did, [file cStringUsingEncoding:NSUTF8StringEncoding]);
    if (i==0)
    {
    }
    return i;
}

- (int) record:(NSString*)file
{
	int i = am_session_record(did, [file cStringUsingEncoding:NSUTF8StringEncoding]);
	if (i==0)
	{
	}
	return i;
}

- (int) record_stop
{
	int i = am_session_stop_record(did);
	if (i==0)
	{
	}
	return i;
}


- (int) mute
{
	int i = am_session_mute(did);
	if (i==0)
	{
		isMuted=true;
		[self onCallUpdate];
	}
	return i;
}

- (int) unmute
{
	int i = am_session_unmute(did);
	if (i==0)
	{		
		isMuted=false;
		[self onCallUpdate];
	}
	return i;
}

- (float) getUploadBandwidth
{
	int i;
	if (did<=0)
		return 0;
	memset(&band_stats, 0, sizeof(band_stats));
	i = am_session_get_audio_bandwidth(did, &band_stats);
	if (i>=0)
	{
    OrtpEvent *evt = am_session_get_audio_rtp_events (did);
    while (evt!=NULL) {
      if (ortp_event_get_type(evt)==ORTP_EVENT_ZRTP_SAS){
        OrtpEventData *evd=ortp_event_get_data(evt);
        ms_message("ZRTP audio event: SAS READY (verified=%s) %s",
                   evd->info.zrtp_sas.zrtp_sas_verified==FALSE?"FALSE":"TRUE",
                   evd->info.zrtp_sas.zrtp_sas);
        ms_message("ZRTP audio event: hash_name   = %s", evd->info.zrtp_sas.hash_name);
        ms_message("ZRTP audio event: cipher_name = %s", evd->info.zrtp_sas.cipher_name);
        ms_message("ZRTP audio event: auth_name   = %s", evd->info.zrtp_sas.auth_name);
        ms_message("ZRTP audio event: sas_name    = %s", evd->info.zrtp_sas.sas_name);
        ms_message("ZRTP audio event: pk_name     = %s", evd->info.zrtp_sas.pk_name);
      } else if (ortp_event_get_type(evt)==ORTP_EVENT_RTCP_PACKET_RECEIVED){
        OrtpEventData *evd=ortp_event_get_data(evt);
        
        do{
          if (rtcp_is_SR(evd->packet)){
            const report_block_t *rb;
            ms_message("RTCP audio event: receiving RTCP SR (ssrc=%i)", rtcp_SR_get_ssrc(evd->packet));
            rb=rtcp_SR_get_report_block(evd->packet,0);
            if (rb){
              unsigned int ij;
              float flost;
              ij=report_block_get_interarrival_jitter(rb);
              flost=(float)(100.0*report_block_get_fraction_lost(rb)/256.0);
              
              NSLog(@"RTCP audio event: remote stat: jitter = %fms // loss = %f%%", (float)ij/8, flost);
              if (flost>20)
                am_session_adapt_audio_bitrate (did, 20);
              else if (flost>5)
                am_session_adapt_audio_bitrate (did, 50);
              else if (flost>1)
                am_session_adapt_audio_bitrate (did, 80);
              else if (flost==0)
                am_session_adapt_audio_bitrate (did, 110);
            }
          }
        }while(rtcp_next_packet(evd->packet));
      }

      am_session_release_rtp_events(evt);
      evt=am_session_get_audio_rtp_events(did);
    }
    
		return band_stats.upload_rate;
	}
	return 0;
}

- (float) getDownloadBandwidth
{
	return band_stats.download_rate;
}

- (float) getPacketLossIn
{
	return -1;
}

- (float) getPacketLossOut
{
	return -1;
}

- (int) sendDtmf:(char)dtmf_number
{
	NSString *_dtmf = [[NSUserDefaults standardUserDefaults] stringForKey:@"dtmf_preference"];
	if (_dtmf==nil)
		return am_session_send_rtp_dtmf([self did], dtmf_number);
	else if ([_dtmf isEqualToString:@"telephone-event"]==YES)
		return am_session_send_rtp_dtmf([self did], dtmf_number);
	else if ([_dtmf isEqualToString:@"audio"]==YES)
		return am_session_send_inband_dtmf([self did], dtmf_number);
	else if ([_dtmf isEqualToString:@"sip-info"]==YES)
		return am_session_send_dtmf_with_duration([self did], dtmf_number, 250);
	return -1;
}

- (int) transfer:(NSString*)numberOrsipId
{
	osip_to_t *target_to;
	int i;

  NSString *_proxy = [[NSUserDefaults standardUserDefaults] stringForKey:@"proxy_preference"];
  NSString *_identity = [[NSUserDefaults standardUserDefaults] stringForKey:@"identity_preference"];
  NSString *_login = [[NSUserDefaults standardUserDefaults] stringForKey:@"user_preference"];
  
  if (_identity==nil || [_identity length]==0)
  {
    if (_proxy!=nil && _login!=nil)
    {
      _identity = [NSString stringWithFormat:@"<sip:%@@%@>", _login, _proxy];
    }
  }
  
	i = osip_to_init(&target_to);
	if (i!=0)
	{
		//most probably allocation issue
		return i;
	}
		
	i = osip_to_parse(target_to, [numberOrsipId cStringUsingEncoding:NSUTF8StringEncoding]);
	osip_to_free(target_to);

	if (i==0) {
		i = am_session_refer(did, [numberOrsipId cStringUsingEncoding:NSUTF8StringEncoding], [_identity cStringUsingEncoding:NSUTF8StringEncoding]);
	}
	else {
		char target[256];
		snprintf(target, sizeof(target), "sip:%s@%s", [numberOrsipId cStringUsingEncoding:NSUTF8StringEncoding],
				 [_proxy cStringUsingEncoding:NSUTF8StringEncoding]);
		i = am_session_refer(did, target, [_identity cStringUsingEncoding:NSUTF8StringEncoding]);
	}
	return i;
}

- (int) connect:(Call*)pCall
{
	int i;
	char buf[1024];
	char refer_to[1024];
	
  NSString *_proxy = [[NSUserDefaults standardUserDefaults] stringForKey:@"proxy_preference"];
  NSString *_identity = [[NSUserDefaults standardUserDefaults] stringForKey:@"identity_preference"];
  NSString *_login = [[NSUserDefaults standardUserDefaults] stringForKey:@"user_preference"];
  
  if (_identity==nil || [_identity length]==0)
  {
    if (_proxy!=nil && _login!=nil)
    {
      _identity = [NSString stringWithFormat:@"<sip:%@@%@>", _login, _proxy];
    }
  }
	
	i = am_session_get_referto(did, buf, sizeof(buf));
	if (i!=0)
	{
		return -1;
	}
	snprintf(refer_to, sizeof(refer_to), "<%s>", buf);	
	
	i = am_session_refer([pCall did], refer_to, [_identity cStringUsingEncoding:NSUTF8StringEncoding]);
	return i;
}


- (void) addCallStateChangeListener:(id)_adelegate
{
	[callDelegates addDelegate:_adelegate];
}

- (void) removeCallStateChangeListener:(id)_adelegate
{
	[callDelegates removeDelegate:_adelegate];
}

- (void) onCallUpdate
{
	[callDelegates onCallUpdate:self];
}

@end
