//  Created by Aymeric MOIZARD on 06/03/11.
//  Copyright 2011 antisip. All rights reserved.
//

enum FileTransferState {
	FT_NOTSTARTED,
	FT_TRYING,
	FT_RINGING,
	FT_CONNECTED,
	FT_DISCONNECTED
};

@interface FileTransfer : NSObject {
	
  NSString *filename;
  NSString *filename_short;
	NSString *from;
	NSString *to;
	NSString *oppositeNumber;
	
	enum FileTransferState fileTransferState;
	bool isIncomingFileTransfer;

  //outgoing call reject info
	int code;
	NSString * reason;
	NSString * callid;
  NSDate *start_date;
  NSDate *end_date;
  
	//private members
	id fileTransferDelegates; // A delegate that wants to act on events in this view
	int tid;
	int cid;
	int did;
}

@property (nonatomic, retain) NSString *filename;
@property (nonatomic, retain) NSString *filename_short;
@property (nonatomic, retain) NSString *from;
@property (nonatomic, retain) NSString *to;
@property (nonatomic, retain) NSString *oppositeNumber;
@property(readwrite) enum FileTransferState fileTransferState;
@property(readwrite) bool isIncomingFileTransfer;

@property(readwrite) int code;
@property (nonatomic, retain) NSString *reason;
@property (nonatomic, retain) NSString *callid;
@property (nonatomic, retain) NSDate *start_date;
@property (nonatomic, retain) NSDate *end_date;

- (int) hangup;
- (int) accept:(int)code;
- (int) decline;

- (float) getUploadBandwidth;
- (float) getDownloadBandwidth;
- (float) getPacketLossIn;
- (float) getPacketLossOut;

- (void) addFileTransferStateChangeListener:(id)_adelegate;
- (void) removeFileTransferStateChangeListener:(id)_adelegate;

//private members
@property (nonatomic, assign) id fileTransferDelegates;
@property(readwrite) int tid;
@property(readwrite) int cid;
@property(readwrite) int did;

- (void) onFileTransferUpdate;

@end

@protocol FileTransferDelegate
@optional
- (void)onFileTransferUpdate:(FileTransfer *)fileTransfer;

@end

