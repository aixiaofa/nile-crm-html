//
//  vbyantisipAppDelegate.m
//  AppEngine
//
//  Created by Aymeric MOIZARD on 16/10/09.
//  Copyright antisip 2009. All rights reserved.
//

#import "NetworkTrackingDelegate.h"
#import "AppEngine.h"
#import "Registration.h"

#import "vbyantisipAppDelegate.h"
#import "UIViewControllerDialpad.h"

#import "NetworkTracking.h"


static UIBackgroundTaskIdentifier bgTask = 0;

void (^keepAliveHandler)(void) = ^{
	vbyantisipAppDelegate *appDelegate = (vbyantisipAppDelegate *)[[UIApplication sharedApplication] delegate];
	
	NSLog(@"keepalive handler is running");
	
	[appDelegate dokeepAliveHandler];
};

@implementation vbyantisipAppDelegate

@synthesize window;
@synthesize tabBarController;
//@synthesize viewControllerCallControl;
//@synthesize viewControllerStatus;

@synthesize proxy;
@synthesize login;
@synthesize password;
@synthesize identity;
@synthesize transport;
@synthesize outboundproxy;
@synthesize stun;

+(void)_initialize
{
  [NetworkTracking getInstance];
	gAppEngine = [[AppEngine alloc] init];
  
	[gAppEngine initialize];
  return;
}


- (void)onNetworkTrackingUpdate:(NetworkTracking *)networkTracking
{
  NetworkStatus netStatus = [networkTracking currentReachabilityStatus];
  BOOL connectionRequired= [networkTracking connectionRequired];
  switch (netStatus)
  {
    case NotReachable:
    {
      connectionRequired= NO;
      break;
    }
      
    case ReachableViaWWAN:
    {
			if (connectionRequired==NO)
			{
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"wifimode_preference"];
				vbyantisipAppDelegate *appDelegate = (vbyantisipAppDelegate *)[[UIApplication sharedApplication] delegate];
				[appDelegate performSelectorOnMainThread : @ selector(restartAll) withObject:nil waitUntilDone:NO];
			}
      break;
    }
    case ReachableViaWiFi:
    {
			if (connectionRequired==NO)
			{
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"wifimode_preference"];
				vbyantisipAppDelegate *appDelegate = (vbyantisipAppDelegate *)[[UIApplication sharedApplication] delegate];
				[appDelegate performSelectorOnMainThread : @ selector(restartAll) withObject:nil waitUntilDone:NO];
			}
      break;
		}
  }
}

-(void)showCallControlView
{
	//[UIView beginAnimations:nil context:NULL];
	//[UIView setAnimationDuration:1.0];
	//[UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:window cache:YES];
	//[tabBarController.view removeFromSuperview];
	//[self.window addSubview:[viewControllerCallControl view]];
	//[UIView commitAnimations];
	
}

- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings
{
  //register to receive notifications
  NSLog(@"didRegisterUserNotificationSettings");
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
	NSLog(@"applicationDidFinishLaunchingWithOptions\n");
	
	if ([UIApplication instancesRespondToSelector:@selector(registerUserNotificationSettings:)]){
	  [application registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeAlert|UIUserNotificationTypeBadge|UIUserNotificationTypeSound categories:nil]];
    NSLog(@"applicationDidFinishLaunchingWithOptions\n");
	}

	isInBackground = true;
  
	if ([[NSUserDefaults standardUserDefaults] boolForKey:@"firstRun"] == false){
		
		[[NSUserDefaults standardUserDefaults] setInteger:0 forKey:@"ptime_preference"];
		[[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"opus_preference"];
		[[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"silknb_preference"];
		[[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"silkwb_preference"];
		[[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"g729_preference"];
		[[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"speex16k_preference"];
		[[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"g722_preference"];
		[[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"speex8k_preference"];
		[[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"iLBC_preference"];
		[[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"gsm8k_preference"];
		[[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"pcmu_preference"];
		[[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"pcma_preference"];
		[[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"aec_preference"];
		[[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"elimiter_preference"];
		[[NSUserDefaults standardUserDefaults] setInteger:0 forKey:@"srtp_preference"];
		[[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"naptr_preference"];
		[[NSUserDefaults standardUserDefaults] setInteger:900 forKey:@"reginterval_preference"];
		
		[[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"vp8_preference"];
		[[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"h264_preference"];
		[[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"mp4v_preference"];
		[[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"h2631998_preference"];
		
		[[NSUserDefaults standardUserDefaults] setInteger:128 forKey:@"uploadbandwidth_preference"];
		[[NSUserDefaults standardUserDefaults] setInteger:128 forKey:@"downloadbandwidth_preference"];
		
		[[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"runinbackground_preference"];
    
		[[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"firstRun"];
	}
	
  // Add the tab bar controller's current view as a subview of the window
  [self.window addSubview:tabBarController.view];
  self.window.rootViewController = tabBarController;
  [self.window makeKeyAndVisible];
	
  if ([application applicationIconBadgeNumber]>0)
    [application setApplicationIconBadgeNumber:0];
  
	NetworkTracking *gNetworkTracking = [NetworkTracking getInstance];
	[gNetworkTracking addNetworkTrackingDelegate:self];
	
	NSString *_proxy = [[NSUserDefaults standardUserDefaults] stringForKey:@"proxy_preference"];
	NSString *_login = [[NSUserDefaults standardUserDefaults] stringForKey:@"user_preference"];
	
	if (_proxy != nil
      &&_login != nil)
	{
		if ([[UIApplication sharedApplication] applicationState] == UIApplicationStateBackground)
		{
			if ([[UIDevice currentDevice] isMultitaskingSupported]) {
				if (bgTask!=0)
					[[UIApplication sharedApplication] endBackgroundTask:bgTask];
				
				bgTask = [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:^{
					NSLog(@"didFinishLaunchingWithOptions: endBackgroundTask - end of background task %i\n", bgTask);
					[[UIApplication sharedApplication] endBackgroundTask:bgTask];
					bgTask=0;
				}];
        double duration_left = [[UIApplication sharedApplication] backgroundTimeRemaining];
        if (bgTask!=0)
          NSLog(@"didFinishLaunchingWithOptions: beginBackgroundTaskWithExpirationHandler - start of background task %i %f\n", bgTask, duration_left);
				if ([application setKeepAliveTimeout:600 handler:keepAliveHandler]) {
					NSLog(@"applicationDidEnterBackground: setKeepAliveTimeout worked!");
					isInBackground = true;
				} else {
					NSLog(@"applicationDidEnterBackground: setKeepAliveTimeout failed.");
				}
				//allow initial registration
			}
      [self onNetworkTrackingUpdate:gNetworkTracking];
		}
	}
	
	return true;
}


- (void)applicationDidEnterBackground:(UIApplication *)application
{
	if ([[UIDevice currentDevice] isMultitaskingSupported]) {
		
		NSString *_proxy = [[NSUserDefaults standardUserDefaults] stringForKey:@"proxy_preference"];
		NSString *_login = [[NSUserDefaults standardUserDefaults] stringForKey:@"user_preference"];
		if (_proxy != nil
        &&_login != nil)
		{
			[gAppEngine refreshRegistration];
		}
		
		if (_proxy != nil
        &&_login != nil)
		{
			if (bgTask!=0)
				[[UIApplication sharedApplication] endBackgroundTask:bgTask];
			
			//allow additionnal registration just before being suspended for the next 10 minutes.
			bgTask = [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:^{
				NSLog(@"applicationDidEnterBackground: endBackgroundTask - end of background task %i\n", bgTask);
				[[UIApplication sharedApplication] endBackgroundTask:bgTask];
				bgTask=0;
			}];
      double duration_left = [[UIApplication sharedApplication] backgroundTimeRemaining];
      if (bgTask!=0)
        NSLog(@"applicationDidEnterBackground: beginBackgroundTaskWithExpirationHandler - start of background task %i %f\n", bgTask, duration_left);
      
			if ([application setKeepAliveTimeout:600 handler:keepAliveHandler]) {
				NSLog(@"applicationDidEnterBackground: setKeepAliveTimeout worked!");
				isInBackground = true;
			} else {
				NSLog(@"applicationDidEnterBackground: setKeepAliveTimeout failed.");
			}
		}
		
	}
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
	NSLog(@"applicationDidBecomeActive\n");
	if (bgTask!=0)
		[[UIApplication sharedApplication] endBackgroundTask:bgTask];
	bgTask=0;
	isInBackground = false;
	
	NSString *_proxy = [[NSUserDefaults standardUserDefaults] stringForKey:@"proxy_preference"];
	NSString *_login = [[NSUserDefaults standardUserDefaults] stringForKey:@"user_preference"];
	NSString *_password = [[NSUserDefaults standardUserDefaults] stringForKey:@"password_preference"];
	NSString *_identity = [[NSUserDefaults standardUserDefaults] stringForKey:@"identity_preference"];
	NSString *_transport = [[NSUserDefaults standardUserDefaults] stringForKey:@"transport_preference"];
	NSString *_outboundproxy = [[NSUserDefaults standardUserDefaults] stringForKey:@"outboundproxy_preference"];
	NSString *_stun = [[NSUserDefaults standardUserDefaults] stringForKey:@"stun_preference"];
  
	if (_proxy == nil
      ||_login == nil)
	{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Account Creation", @"Account Creation")
                                                    message:NSLocalizedString(@"Please configure your settings in the iphone preference panel.", @"Please configure your settings in the iphone preference panel.")
                                                   delegate:nil cancelButtonTitle:@"Cancel"
                                          otherButtonTitles:nil];
    [alert show];
    [alert release];
	}
  
	NetworkTracking *gNetworkTracking = [NetworkTracking getInstance];
	NetworkStatus internetStatus =  [gNetworkTracking currentReachabilityStatus];
	BOOL connectionRequired= [gNetworkTracking connectionRequired];
  
	if (connectionRequired==YES || internetStatus==NotReachable)
	{
		return;
	}
  if (internetStatus==ReachableViaWiFi) {
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"wifimode_preference"];
  } else if (internetStatus==ReachableViaWWAN) {
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"wifimode_preference"];
  }
  
	/* check a change in settings */
	if ((proxy!=nil && _proxy==nil)
      || (proxy==nil && _proxy!=nil)
      || (proxy!=nil && [proxy isEqualToString:_proxy]==NO))
	{
		[self performSelectorOnMainThread : @ selector(restartAll) withObject:nil waitUntilDone:NO];
		return;
	}
	if ((login!=nil && _login==nil)
      || (login==nil && _login!=nil)
      || (login!=nil && [login isEqualToString:_login]==NO))
	{
		[self performSelectorOnMainThread : @ selector(restartAll) withObject:nil waitUntilDone:NO];
		return;
	}
	if ((password!=nil && _password==nil)
      || (password==nil && _password!=nil)
      || (password!=nil && [password isEqualToString:_password]==NO))
	{
		[self performSelectorOnMainThread : @ selector(restartAll) withObject:nil waitUntilDone:NO];
		return;
	}
	if ((identity!=nil && _identity==nil)
      || (identity==nil && _identity!=nil)
      || (identity!=nil && [identity isEqualToString:_identity]==NO))
	{
		[self performSelectorOnMainThread : @ selector(restartAll) withObject:nil waitUntilDone:NO];
		return;
	}
	if ((transport!=nil && _transport==nil)
      || (transport==nil && _transport!=nil)
      || (transport!=nil && [transport isEqualToString:_transport]==NO))
	{
		[self performSelectorOnMainThread : @ selector(restartAll) withObject:nil waitUntilDone:NO];
		return;
	}
	if ((outboundproxy!=nil && _outboundproxy==nil)
      || (outboundproxy==nil && _outboundproxy!=nil)
      || (outboundproxy!=nil && [outboundproxy isEqualToString:_outboundproxy]==NO))
	{
		[self performSelectorOnMainThread : @ selector(restartAll) withObject:nil waitUntilDone:NO];
		return;
	}
	if ((stun!=nil && _stun==nil)
      || (stun==nil && _stun!=nil)
      || (stun!=nil && [stun isEqualToString:_stun]==NO))
	{
		[self performSelectorOnMainThread : @ selector(restartAll) withObject:nil waitUntilDone:NO];
		return;
	}
	
	if ([[NSUserDefaults standardUserDefaults] boolForKey:@"g729_preference"]!=g729
			||[[NSUserDefaults standardUserDefaults] boolForKey:@"opus_preference"]!=opus
			||[[NSUserDefaults standardUserDefaults] boolForKey:@"silknb_preference"]!=silknb
			||[[NSUserDefaults standardUserDefaults] boolForKey:@"silkwb_preference"]!=silkwb
			||[[NSUserDefaults standardUserDefaults] boolForKey:@"speex16k_preference"]!=speex16k
			||[[NSUserDefaults standardUserDefaults] boolForKey:@"g722_preference"]!=g722
			||[[NSUserDefaults standardUserDefaults] boolForKey:@"speex8k_preference"]!=speex8k
			||[[NSUserDefaults standardUserDefaults] boolForKey:@"iLBC_preference"]!=iLBC
			||[[NSUserDefaults standardUserDefaults] boolForKey:@"gsm8k_preference"]!=gsm8k
			||[[NSUserDefaults standardUserDefaults] boolForKey:@"pcmu_preference"]!=pcmu
			||[[NSUserDefaults standardUserDefaults] boolForKey:@"pcma_preference"]!=pcma
			
			||[[NSUserDefaults standardUserDefaults] boolForKey:@"aec_preference"]!=aec
			||[[NSUserDefaults standardUserDefaults] boolForKey:@"elimiter_preference"]!=elimiter
			||[[NSUserDefaults standardUserDefaults] integerForKey:@"srtp_preference"]!=srtp
			
			||[[NSUserDefaults standardUserDefaults] boolForKey:@"naptr_preference"]!=naptr
			||[[NSUserDefaults standardUserDefaults] integerForKey:@"reginterval_preference"]!=reginterval
			
			||[[NSUserDefaults standardUserDefaults] integerForKey:@"ptime_preference"]!=ptime
			
			||[[NSUserDefaults standardUserDefaults] boolForKey:@"vp8_preference"]!=vp8
			||[[NSUserDefaults standardUserDefaults] boolForKey:@"h264_preference"]!=h264
			||[[NSUserDefaults standardUserDefaults] boolForKey:@"mp4v_preference"]!=mp4v
			||[[NSUserDefaults standardUserDefaults] boolForKey:@"h2631998_preference"]!=h2631998
			
			||[[NSUserDefaults standardUserDefaults] integerForKey:@"uploadbandwidth_preference"]!=uploadbandwidth
			||[[NSUserDefaults standardUserDefaults] integerForKey:@"downloadbandwidth_preference"]!=downloadbandwidth
      
      )
	{
		[self performSelectorOnMainThread : @ selector(restartAll) withObject:nil waitUntilDone:NO];
		return;
	}
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
	NSLog(@"applicationWillEnterForeground\n");
	if (bgTask!=0)
		[[UIApplication sharedApplication] endBackgroundTask:bgTask];
	bgTask=0;
	isInBackground = false;
}

- (void) stopBackgroundTask
{
	NSLog(@"stopBackgroundTask\n");
	if (bgTask!=0)
		[[UIApplication sharedApplication] endBackgroundTask:bgTask];
	bgTask=0;
}

- (void) dokeepAliveHandler
{
	NSString *_proxy = [[NSUserDefaults standardUserDefaults] stringForKey:@"proxy_preference"];
	NSString *_login = [[NSUserDefaults standardUserDefaults] stringForKey:@"user_preference"];
	if (_proxy != nil
      &&_login != nil)
	{
		[gAppEngine refreshRegistration];
	}
  
  double duration_left = [[UIApplication sharedApplication] backgroundTimeRemaining];
  if (bgTask!=0)
    NSLog(@"dokeepAliveHandler: previous background task %i %f\n", bgTask, duration_left);
  
  //should we check if we are in background?
  if (bgTask!=0)
    [[UIApplication sharedApplication] endBackgroundTask:bgTask];
  
  bgTask = [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:^{
    NSLog(@"dokeepAliveHandler: endBackgroundTask - end of background task %i\n", bgTask);
    [[UIApplication sharedApplication] endBackgroundTask:bgTask];
    bgTask=0;
  }];
  duration_left = [[UIApplication sharedApplication] backgroundTimeRemaining];
  if (bgTask!=0)
    NSLog(@"dokeepAliveHandler: beginBackgroundTaskWithExpirationHandler - start of background task %i %f\n", bgTask, duration_left);
}

- (void)applicationWillTerminate:(UIApplication *)application
{
	[gAppEngine stop];
}

-(void) restartAll {
	NSString *_proxy = [[NSUserDefaults standardUserDefaults] stringForKey:@"proxy_preference"];
	NSString *_login = [[NSUserDefaults standardUserDefaults] stringForKey:@"user_preference"];
	NSString *_password = [[NSUserDefaults standardUserDefaults] stringForKey:@"password_preference"];
	NSString *_identity = [[NSUserDefaults standardUserDefaults] stringForKey:@"identity_preference"];
	NSString *_transport = [[NSUserDefaults standardUserDefaults] stringForKey:@"transport_preference"];
	NSString *_outboundproxy = [[NSUserDefaults standardUserDefaults] stringForKey:@"outboundproxy_preference"];
	NSString *_stun = [[NSUserDefaults standardUserDefaults] stringForKey:@"stun_preference"];
	
	NSLog(@"%@ vs %@", proxy, _proxy);
	NSLog(@"%@ vs %@", login, _login);
	NSLog(@"%@ vs %@", password, _password);
	NSLog(@"%@ vs %@", identity, _identity);
	NSLog(@"%@ vs %@", transport, _transport);
	NSLog(@"%@ vs %@", outboundproxy, _outboundproxy);
	NSLog(@"%@ vs %@", stun, _stun);
	
  [self setProxy:_proxy];
  [self setLogin:_login];
  [self setPassword:_password];
  [self setIdentity:_identity];
  [self setTransport:_transport];
  [self setOutboundproxy:_outboundproxy];
  [self setStun:_stun];
	ptime = [[NSUserDefaults standardUserDefaults] integerForKey:@"ptime_preference"];
	opus = [[NSUserDefaults standardUserDefaults] boolForKey:@"opus_preference"];
	silknb = [[NSUserDefaults standardUserDefaults] boolForKey:@"silknb_preference"];
	silkwb = [[NSUserDefaults standardUserDefaults] boolForKey:@"silkwb_preference"];
	g729 = [[NSUserDefaults standardUserDefaults] boolForKey:@"g729_preference"];
	speex16k = [[NSUserDefaults standardUserDefaults] boolForKey:@"speex16k_preference"];
	g722 = [[NSUserDefaults standardUserDefaults] boolForKey:@"g722_preference"];
	speex8k = [[NSUserDefaults standardUserDefaults] boolForKey:@"speex8k_preference"];
	iLBC = [[NSUserDefaults standardUserDefaults] boolForKey:@"iLBC_preference"];
	gsm8k = [[NSUserDefaults standardUserDefaults] boolForKey:@"gsm8k_preference"];
	pcmu = [[NSUserDefaults standardUserDefaults] boolForKey:@"pcmu_preference"];
	pcma = [[NSUserDefaults standardUserDefaults] boolForKey:@"pcma_preference"];
	aec = [[NSUserDefaults standardUserDefaults] boolForKey:@"aec_preference"];
	elimiter = [[NSUserDefaults standardUserDefaults] boolForKey:@"elimiter_preference"];
	srtp = [[NSUserDefaults standardUserDefaults] integerForKey:@"srtp_preference"];
	naptr = [[NSUserDefaults standardUserDefaults] boolForKey:@"naptr_preference"];
	reginterval = [[NSUserDefaults standardUserDefaults] integerForKey:@"reginterval_preference"];
  
	vp8 = [[NSUserDefaults standardUserDefaults] boolForKey:@"vp8_preference"];
	h264 = [[NSUserDefaults standardUserDefaults] boolForKey:@"h264_preference"];
	mp4v = [[NSUserDefaults standardUserDefaults] boolForKey:@"mp4v_preference"];
	h2631998 = [[NSUserDefaults standardUserDefaults] boolForKey:@"h2631998_preference"];
	
	uploadbandwidth = [[NSUserDefaults standardUserDefaults] integerForKey:@"uploadbandwidth_preference"];
	downloadbandwidth = [[NSUserDefaults standardUserDefaults] integerForKey:@"downloadbandwidth_preference"];
  
	[gAppEngine stop];
	[gAppEngine start];
	[gAppEngine addCallDelegate:self];
	[gAppEngine addRegistrationDelegate:self];
}

-(void)onFileTransferExist:(FileTransfer *)pFileTransfer {
	NSLog(@"UIViewControllerCallList: onFileTransferExist");
}

-(void)onFileTransferNew:(FileTransfer *)pFileTransfer {
	NSLog(@"UIViewControllerCallList: onFileTransferNew");
}

-(void)onFileTransferRemove:(FileTransfer *)pFileTransfer {
	NSLog(@"UIViewControllerCallList: onFileTransferRemove");
}

- (void)onFileTransferUpdate:(FileTransfer *)pFileTransfer {
	NSLog(@"UIViewControllerCallList: onFileTransferUpdate");
}

-(void)onCallExist:(Call *)call {
}

-(void)onCallNew:(Call *)call {
	NSLog(@"vbyantisipAppDelegate: onCallNew");
	
	//if ([call isIncomingCall]==false)
	//{
	//	vbyantisipAppDelegate *appDelegate = (vbyantisipAppDelegate *)[[UIApplication sharedApplication] delegate];
	//	if ([appDelegate.tabBarController selectedIndex]!=1)
	//	{
	//		[appDelegate.tabBarController setSelectedIndex: 1];
  //      UIViewControllerDialpad *lViewControllerDialpad = (UIViewControllerDialpad*)viewControllerDialpad;
	//		[lViewControllerDialpad pushCallControlList];
	//		return;
	//	}
	//}
	
	if ([gAppEngine getNumberOfActiveCalls]>3)
	{
		[call decline];
		return;
	}
  
#ifdef MULTITASKING_ENABLED
  if ([[UIApplication sharedApplication] applicationState] == UIApplicationStateBackground)
  {
    if ([[UIDevice currentDevice] isMultitaskingSupported]) {
      
      if (bgTask==0) {
        bgTask = [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:^{
          NSLog(@"onCallNew: endBackgroundTask - end of background task %i\n", bgTask);
          [[UIApplication sharedApplication] endBackgroundTask:bgTask];
          bgTask=0;
        }];
      }
      double duration_left = [[UIApplication sharedApplication] backgroundTimeRemaining];
      if (bgTask!=0)
        NSLog(@"onCallNew: beginBackgroundTaskWithExpirationHandler - start of background task %i %f\n", bgTask, duration_left);
      
      // Create a new notification
      UIApplication* app = [UIApplication sharedApplication];
      UILocalNotification* alarm = [[[UILocalNotification alloc] init] autorelease];
      if (alarm)
      {
        alarm.fireDate = [[NSDate date] dateByAddingTimeInterval:0];;
        alarm.timeZone = [NSTimeZone defaultTimeZone];
        alarm.repeatInterval = 0;
        alarm.soundName = @"alarmsound.caf";
        NSString *body = [NSString stringWithFormat:@"Call from %@",
                          [call oppositeNumber]];
        alarm.alertBody = body;
        alarm.alertAction = @"Answer";
        
        [app presentLocalNotificationNow:alarm];
      }
    }
  }
  
	//To be called later if call is not answered:
	//[[UIApplication sharedApplication] cancelAllLocalNotifications];
#endif
  
	if ([call isIncomingCall]==true)
	{
    vbyantisipAppDelegate *appDelegate = (vbyantisipAppDelegate *)[[UIApplication sharedApplication] delegate];
    if ([appDelegate.tabBarController selectedIndex]!=1)
    {
      [appDelegate.tabBarController setSelectedIndex: 1];
    }
    UIViewControllerDialpad *_viewControllerDialpad = (UIViewControllerDialpad *)viewControllerDialpad;
    [_viewControllerDialpad pushCallControlList];
  }
}

-(void)onCallRemove:(Call *)call {
	NSLog(@"vbyantisipAppDelegate: onCallRemove");
	//[self performSelectorOnMainThread : @ selector(showIncomingCallView) withObject:nil waitUntilDone:NO];
  
	if ([gAppEngine getNumberOfActiveCalls]<=0)
	{
    UInt32 audioRouteOverride = kAudioSessionOverrideAudioRoute_None;
    AudioSessionSetProperty (kAudioSessionProperty_OverrideAudioRoute,
                             sizeof (audioRouteOverride),
                             &audioRouteOverride);
  }
}

- (void)onRegistrationNew:(Registration*)_registration;
{
	registration = _registration;
}

- (void)onRegistrationRemove:(Registration*)_registration;
{
	registration = nil;
}

- (void)onRegistrationUpdate:(Registration*)_registration;
{
	if (_registration.rid!=_registration.rid)
	{
		NSLog(@"onRegistrationUpdate: <bug> 2 active registration with different rid pending");
	}
	registration = _registration;
  
	bool _runinbackground = [[NSUserDefaults standardUserDefaults] boolForKey:@"runinbackground_preference"];
  
  if ([[UIApplication sharedApplication] applicationState] == UIApplicationStateBackground)
  {
    if ([[UIDevice currentDevice] isMultitaskingSupported]) {
      NSString *cur_transport = [[NSUserDefaults standardUserDefaults] stringForKey:@"transport_preference"];
      
      if (cur_transport == nil
          || [cur_transport caseInsensitiveCompare:@"auto"]==0
          || [cur_transport caseInsensitiveCompare:@"TCP"]==0
          || [cur_transport caseInsensitiveCompare:@"TLS"]==0)
        _runinbackground=NO;
      
      //if _runinbackground is NO, then we will go in FOREGROUND, but in TCP we will
      //be woken-up by the socket
      
      if (_runinbackground==NO && [registration code]>=200 && [registration code]<299) {
        
        // Create a dispatch queue
        dispatch_queue_t log_queue = dispatch_queue_create("com.antisip.delay4background", NULL);
        // Add dispatch queue to GCD
        dispatch_async(log_queue, ^{
          NSLog(@"onRegistrationUpdate: go to background in 10sec");
          sleep(10);
          NSLog(@"onRegistrationUpdate: go to background now");
          if (bgTask!=0)
            [[UIApplication sharedApplication] endBackgroundTask:bgTask];
          bgTask=0;
        });
        // Release the queue for memory management
        dispatch_release(log_queue);
      }
    }
  }
  
}


- (void)dealloc {
  [tabBarController release];
  [window release];
  [super dealloc];
}

@end

