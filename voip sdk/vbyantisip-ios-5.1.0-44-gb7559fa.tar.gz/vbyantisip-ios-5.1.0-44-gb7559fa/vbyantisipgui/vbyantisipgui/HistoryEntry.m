//
//  HistoryEntry.m
//  vbyantisipgui
//
//  Created by Aymeric Moizard on 4/10/12.
//  Copyright (c) 2012 antisip. All rights reserved.
//

#import "HistoryEntry.h"

@implementation HistoryEntry

@synthesize callid;
@synthesize remoteuri;

@end
