//
//  UINavigationBar_vbyantisip.h
//  vbyantisipgui
//
//  Created by Aymeric MOIZARD on 9/23/11.
//  Copyright 2011 antisip. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationBar_vbyantisip : UINavigationBar <UINavigationBarDelegate>  {
    
}


@end
