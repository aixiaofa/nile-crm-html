#!/bin/bash
 
###########################################################################
#  Choose your ffmpeg version and your currently-installed iOS SDK version:
#
SDKVERSION="7.1"
MINSDKVERSION="5.0"
#
#
###########################################################################
#
# Don't change anything under this line!
#
###########################################################################
 
# No need to change this since xcode build will only compile in the
# necessary bits from the libraries we create
ARCHS="x86_64 armv7 armv7s i386 arm64"

DEVELOPER=`xcode-select -print-path`

REPOROOT=$(pwd)

########################################
 
 
# Exit the script if an error happens
set -e

 
set +e # don't bail out of bash script if ccache doesn't exist
CCACHE=`which ccache`
if [ $? == "0" ]; then
    echo "Building with ccache: $CCACHE"
    CCACHE="${CCACHE} "
else
    echo "Building without ccache"
    CCACHE=""
fi
set -e # back to regular "bail out on error" mode
 
for ARCH in ${ARCHS}
do
    FFMPEG_OPTS="--enable-static --disable-shared --disable-iconv --disable-network --disable-ffmpeg --disable-ffplay --disable-ffprobe --disable-ffserver --disable-avdevice --disable-swresample --disable-doc --disable-everything --disable-filters --enable-decoder=h263 --enable-decoder=h263i --enable-decoder=mpeg4 --enable-decoder=h264 --enable-decoder=mjpeg --enable-decoder=ffv1 --enable-decoder=snow --enable-encoder=h263 --enable-encoder=h263p --enable-encoder=mpeg4 --enable-encoder=mjpeg --enable-encoder=h263 --enable-encoder=ffv1 --enable-encoder=snow"

    if [ "${ARCH}" == "i386" ];
    then
	PLATFORM="iPhoneSimulator"
        EXTRA_CONFIG="--arch=i386 --disable-asm --enable-cross-compile --target-os=darwin --cpu=i386"
        EXTRA_CFLAGS="-arch i386"
        EXTRA_LDFLAGS="-I${DEVELOPER}/Platforms/${PLATFORM}.platform/Developer/SDKs/${PLATFORM}${SDKVERSION}.sdk/usr/lib"
    fi
    if [ "${ARCH}" == "x86_64" ];
    then
	PLATFORM="iPhoneSimulator"
        EXTRA_CONFIG="--arch=x86_64 --disable-asm --enable-cross-compile --target-os=darwin --cpu=x86_64"
        EXTRA_CFLAGS="-arch x86_64"
        EXTRA_LDFLAGS="-I${DEVELOPER}/Platforms/${PLATFORM}.platform/Developer/SDKs/${PLATFORM}${SDKVERSION}.sdk/usr/lib"
    fi
    if [ "${ARCH}" == "armv7" ];
    then
	PLATFORM="iPhoneOS"
        EXTRA_CONFIG="--arch=arm --target-os=darwin --enable-cross-compile --cpu=cortex-a8 --disable-armv5te"
        EXTRA_CFLAGS="-w -arch ${ARCH} -mfpu=neon"
        EXTRA_LDFLAGS="-mfpu=neon"
    fi
    if [ "${ARCH}" == "armv7s" ];
    then
	PLATFORM="iPhoneOS"
        EXTRA_CONFIG="--arch=arm --target-os=darwin --enable-cross-compile --cpu=cortex-a9 --disable-armv5te"
        EXTRA_CFLAGS="-w -arch ${ARCH} -mfpu=neon"
        EXTRA_LDFLAGS="-mfpu=neon"
    fi
    if [ "${ARCH}" == "arm64" ];
    then
	PLATFORM="iPhoneOS"
        EXTRA_CONFIG="--arch=arm64 --target-os=darwin --enable-cross-compile --disable-armv5te"
        EXTRA_CFLAGS="-w -arch ${ARCH}"
        EXTRA_LDFLAGS=""
	FFMPEG_OPTS="${FFMPEG_OPTS} --disable-neon"
    fi


INSTALLDIR="${REPOROOT}/ffmpeg-${ARCH}"

mkdir -p "build-${ARCH}"
cd "build-${ARCH}"

../ffmpeg/configure --prefix="${INSTALLDIR}" ${FFMPEG_OPTS} --sysroot="${DEVELOPER}/Platforms/${PLATFORM}.platform/Developer/SDKs/${PLATFORM}${SDKVERSION}.sdk" --cc="${DEVELOPER}/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang" --as="/usr/bin/gas-preprocessor.pl ${DEVELOPER}/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang" --extra-cflags="${EXTRA_CFLAGS} -miphoneos-version-min=${MINSDKVERSION}" --extra-ldflags="-arch ${ARCH} ${EXTRA_LDFLAGS} -isysroot /Applications/Xcode.app/Contents/Developer/Platforms/${PLATFORM}.platform/Developer/SDKs/${PLATFORM}${SDKVERSION}.sdk -miphoneos-version-min=${MINSDKVERSION}" ${EXTRA_CONFIG} --enable-pic --extra-cxxflags="$CPPFLAGS -isysroot ${DEVELOPER}/Platforms/${PLATFORM}.platform/Developer/SDKs/${PLATFORM}${SDKVERSION}.sdk"
 
make && make install

cd ..

done

rm -rf "ffmpeg-uarch/lib"
rm -rf "ffmpeg-uarch/include"

 
mkdir -p "ffmpeg-uarch"
mkdir -p "ffmpeg-uarch/lib"

cp -r ffmpeg-armv7/include ffmpeg-uarch/include

cd "ffmpeg-armv7/lib"
for file in *.a
do
 
xcrun -sdk iphoneos lipo -output ../../ffmpeg-uarch/lib/$file  -create -arch armv7 $file -arch armv7s ../../ffmpeg-armv7s/lib/$file -arch i386 ../../ffmpeg-i386/lib/$file -arch arm64 ../../ffmpeg-arm64/lib/$file -arch x86_64 ../../ffmpeg-x86_64/lib/$file
echo "Universal $file created."
 
done
cd ../..

echo "Done."
