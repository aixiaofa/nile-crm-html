//
//  amsip.m
//  amsip
//
//  Created by Aymeric MOIZARD on 9/14/11.
//  Copyright 2011 antisip. All rights reserved.
//

#import "amsip.h"

@implementation amsip

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

@end
