//
//  amsip.h
//  amsip
//
//  Created by Aymeric MOIZARD on 9/14/11.
//  Copyright 2011 antisip. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface amsip : NSObject

@end
