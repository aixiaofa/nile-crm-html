//
//  speex.m
//  speex
//
//  Created by Aymeric MOIZARD on 9/14/11.
//  Copyright 2011 antisip. All rights reserved.
//

#import "speex.h"

@implementation speex

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

@end
