#!/bin/sh

mkdir -p armv7_build 
cd armv7_build/ 
../libvpx/configure --target=armv7-darwin-gcc --disable-examples
make 
cd .. 
mkdir -p armv7s_build 
cd armv7s_build/ 
../libvpx/configure --target=armv7s-darwin-gcc --disable-examples
make 
cd .. 
mkdir -p arm64_build 
cd arm64_build/ 
../libvpx/configure --target=arm64-darwin-gcc --disable-examples
make 
cd .. 

lipo armv7_build/libvpx.a -arch armv7s armv7s_build/libvpx.a -arch arm64 arm64_build/libvpx.a -create -output libvpx.a 
mkdir -p ../mediastreamer2/vpx
cp libvpx/vpx/*.h ../mediastreamer2/vpx/
for f in ../mediastreamer2/vpx/*.h; do sed -i '' 's/\#include "vpx\//\#include "/' $f; done
