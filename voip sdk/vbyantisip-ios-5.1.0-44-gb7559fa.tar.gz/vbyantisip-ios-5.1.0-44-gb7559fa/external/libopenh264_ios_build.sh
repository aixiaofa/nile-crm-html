#!/bin/sh

cd openh264

make OS=ios LIBPREFIX=liboh264 ARCH=armv7
mkdir -p armv7
cp *.a armv7
make OS=ios LIBPREFIX=liboh264 ARCH=armv7 clean

make OS=ios LIBPREFIX=liboh264 ARCH=armv7s
mkdir -p armv7s
cp *.a armv7s
make OS=ios LIBPREFIX=liboh264 ARCH=armv7s clean

make OS=ios LIBPREFIX=liboh264 ARCH=arm64
mkdir -p arm64
cp *.a arm64
make OS=ios LIBPREFIX=liboh264 ARCH=arm64 clean

lipo armv7/liboh264processing.a -arch armv7s armv7s/liboh264processing.a -arch arm64 arm64/liboh264processing.a -create -output ../liboh264processing.a 
lipo armv7/liboh264common.a -arch armv7s armv7s/liboh264common.a -arch arm64 arm64/liboh264common.a -create -output ../liboh264common.a 
lipo armv7/liboh264encoder.a -arch armv7s armv7s/liboh264encoder.a -arch arm64 arm64/liboh264encoder.a -create -output ../liboh264encoder.a 
lipo armv7/liboh264decoder.a -arch armv7s armv7s/liboh264decoder.a -arch arm64 arm64/liboh264decoder.a -create -output ../liboh264decoder.a 
lipo armv7/liboh264wels.a -arch armv7s armv7s/liboh264wels.a -arch arm64 arm64/liboh264wels.a -create -output ../liboh264wels.a 
