
/**
 * 小程序配置文件
 */
var config = {
  // 后台请求域名
  url: 'https://api.nilecom.cn',
  domain: '/cloudunicomm/video.do?func='
}


module.exports = config;